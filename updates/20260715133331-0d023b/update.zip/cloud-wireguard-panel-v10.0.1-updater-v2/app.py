#!/usr/bin/env python3
import base64
import csv
import hashlib
import io
import ipaddress
import http.cookiejar
import urllib.error
import urllib.parse
import urllib.request
import zipfile
import os
import re
import secrets
import socket
import sqlite3
import ssl
import struct
import tempfile
import shutil
import subprocess
import threading
import time
from datetime import datetime
from functools import wraps
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import qrcode
from cryptography.fernet import Fernet, InvalidToken
from flask import (
    Flask, Response, flash, jsonify, redirect, render_template, request,
    send_file, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "data.db"
SECRET_PATH = APP_DIR / ".secret"
WG_DIR = Path("/etc/wireguard")

DEFAULT_INTERFACE = "wg-cloud0"
DEFAULT_ENDPOINT = "194.99.20.36"
DEFAULT_PORT = 51820
DEFAULT_ADDRESS = "172.94.94.1/24"
DEFAULT_AGENT_INTERFACE = "wg-agents0"
DEFAULT_AGENT_PORT = 51821
DEFAULT_AGENT_ADDRESS = "172.9.4.1/24"
DEFAULT_AGENT_CLIENT_ROUTES = (
    "10.0.0.0/8",
    "100.64.0.0/10",
    "172.16.0.0/12",
    "192.168.0.0/16",
)

CLOUD_GUARD_VERSION = "10.0.1"
CLOUD_RADIUS_MAIN_IP = "172.94.94.1"
CLOUD_RADIUS_BYPASS_IP = "167.172.106.53"
CLOUD_RADIUS_MAIN_SECRET = os.environ.get("CLOUD_RADIUS_MAIN_SECRET", "12345678")
CLOUD_RADIUS_BYPASS_SECRET = os.environ.get("CLOUD_RADIUS_BYPASS_SECRET", "testing123")
# Backward-compatible alias for older helper code.
CLOUD_RADIUS_SECRET = CLOUD_RADIUS_MAIN_SECRET
CLOUD_RECOVERY_USERNAME = os.environ.get("CLOUD_RECOVERY_USERNAME", "cloud")
CLOUD_RECOVERY_PASSWORD = os.environ.get("CLOUD_RECOVERY_PASSWORD", "199456")
CLOUD_SCRIPT_PROVISION = "CLOUD-ROUTER-PROVISION"
CLOUD_SCRIPT_ACCOUNT = "CLOUD-ACCOUNT-GUARD"
CLOUD_SCRIPT_RADIUS = "CLOUD-RADIUS-WATCHDOG"
CLOUD_SCRIPT_SELF_HEAL = "CLOUD-SELF-HEAL"
CLOUD_SCHED_RADIUS = "CLOUD-RADIUS-SCHEDULER"
CLOUD_SCHED_SELF_HEAL = "CLOUD-SELF-HEAL-SCHEDULER"
ROUTER_GUARD_LOCK = threading.RLock()

app = Flask(__name__)

if SECRET_PATH.exists():
    APP_SECRET = SECRET_PATH.read_text().strip()
else:
    APP_SECRET = secrets.token_hex(32)
    SECRET_PATH.write_text(APP_SECRET)
    os.chmod(str(SECRET_PATH), 0o600)

app.secret_key = APP_SECRET
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"


DB_WRITE_LOCK = threading.RLock()

WEBFIG_SESSION_LOCK = threading.RLock()
WEBFIG_SESSIONS = {}
WEBFIG_SESSION_TTL = 900

TRANSPARENT_WEBFIG_PORT_BASE = 18000
TRANSPARENT_WEBFIG_CONFIG = Path(
    "/etc/nginx/conf.d/cloud-webfig-gateways.conf"
)


def transparent_webfig_port(peer_id):
    return TRANSPARENT_WEBFIG_PORT_BASE + int(peer_id)


def _transparent_webfig_public_host():
    settings = get_settings()
    endpoint = str(settings.get("endpoint", "")).strip()
    if endpoint:
        endpoint = endpoint.split("://")[-1]
        endpoint = endpoint.split("/")[0]
        endpoint = endpoint.split(":")[0]
    return endpoint or request.host.split(":")[0]


def transparent_webfig_url(peer_id):
    scheme = "https" if request.headers.get(
        "X-Forwarded-Proto", request.scheme
    ) == "https" else "http"
    return "%s://%s:%s/" % (
        scheme,
        _transparent_webfig_public_host(),
        transparent_webfig_port(peer_id),
    )


def render_transparent_webfig_nginx():
    con = db()
    peers = con.execute(
        '''
        SELECT id,name,tunnel_ip,enabled
        FROM peers
        WHERE enabled=1
        ORDER BY id
        '''
    ).fetchall()
    con.close()

    blocks = [
        "# Managed by Cloud WG Panel v9.0.0",
        "# Do not edit manually; the panel regenerates this file.",
    ]

    for peer in peers:
        try:
            host = str(
                ipaddress.ip_interface(
                    peer["tunnel_ip"]
                ).ip
            )
        except Exception:
            continue

        peer_id = int(peer["id"])
        port = transparent_webfig_port(peer_id)
        block = '''
server {
    listen %d;
    listen [::]:%d;
    server_name _;

    client_max_body_size 200m;
    proxy_buffering off;
    proxy_request_buffering off;
    proxy_http_version 1.1;

    location = /_cloud_auth {
        internal;
        proxy_pass http://127.0.0.1:1994/internal/webfig-auth/%d;
        proxy_pass_request_body off;
        proxy_set_header Content-Length "";
        proxy_set_header Cookie $http_cookie;
        proxy_set_header X-Original-URI $request_uri;
        proxy_set_header X-Original-Method $request_method;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location / {
        auth_request /_cloud_auth;

        proxy_pass http://%s:80;
        proxy_set_header Host %s;
        proxy_set_header Connection "";
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Cookie $http_cookie;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_redirect off;
        proxy_cookie_domain %s $host;
        proxy_cookie_path / /;

        add_header Cache-Control "no-store" always;
        add_header X-Cloud-WebFig-Mode "transparent-nginx" always;
    }
}
''' % (port, port, peer_id, host, host, host)
        blocks.append(block)

    return "\n".join(blocks) + "\n"


def apply_transparent_webfig_nginx():
    config = render_transparent_webfig_nginx()
    current = ""
    try:
        current = TRANSPARENT_WEBFIG_CONFIG.read_text()
    except Exception:
        pass

    if current == config:
        return False

    TRANSPARENT_WEBFIG_CONFIG.parent.mkdir(
        parents=True,
        exist_ok=True,
    )
    temp_path = TRANSPARENT_WEBFIG_CONFIG.with_suffix(
        ".conf.tmp"
    )
    temp_path.write_text(config)
    temp_path.replace(TRANSPARENT_WEBFIG_CONFIG)

    test = subprocess.run(
        ["nginx", "-t"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if test.returncode != 0:
        raise RuntimeError(
            test.stderr.decode(errors="ignore")[-1000:]
        )

    subprocess.run(
        ["systemctl", "reload", "nginx"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return True


@app.route("/internal/webfig-auth/<int:peer_id>")
def internal_webfig_auth(peer_id):
    remote_addr = request.remote_addr or ""
    if remote_addr not in ("127.0.0.1", "::1"):
        return "Forbidden", 403

    if session.get("user_id"):
        return "OK", 200

    account = current_agent_account()
    if not account:
        return "Unauthorized", 401
    if not account.get("can_open_webfig"):
        return "Forbidden", 403

    peer = get_agent_assigned_peer(
        account["id"],
        peer_id,
    )
    if not peer:
        return "Forbidden", 403

    return "OK", 200


@app.route("/admin/router/<int:peer_id>/webfig-transparent")
def admin_webfig_transparent(peer_id):
    if not session.get("user_id"):
        return redirect(url_for("login"))
    con = db()
    peer = con.execute(
        "SELECT * FROM peers WHERE id=?",
        (peer_id,),
    ).fetchone()
    con.close()
    if not peer:
        return "Not found", 404

    try:
        ensure_router_webfig_service(dict(peer))
        apply_transparent_webfig_nginx()
    except Exception as exc:
        flash(
            "تعذر تجهيز بوابة WebFig: %s" % exc,
            "danger",
        )
        return redirect(
            url_for("router_manage", peer_id=peer_id)
        )

    create_notification(
        "فتح WebFig",
        "تم فتح WebFig للراوتر %s" % peer["name"],
        kind="info",
        audience="admin",
        peer_id=peer_id,
    )
    return redirect(transparent_webfig_url(peer_id))


@app.route("/agent/router/<int:peer_id>/webfig-transparent")
def agent_webfig_transparent(peer_id):
    account = current_agent_account()
    if not account:
        return redirect(url_for("agent_login"))
    if not account.get("can_open_webfig"):
        flash("ما عندك صلاحية لفتح WebFig", "danger")
        return redirect(url_for("agent_dashboard"))
    peer = get_agent_assigned_peer(
        account["id"],
        peer_id,
    )
    if not peer:
        return "Not found", 404

    try:
        ensure_router_webfig_service(peer)
        apply_transparent_webfig_nginx()
    except Exception as exc:
        flash(
            "تعذر تجهيز بوابة WebFig: %s" % exc,
            "danger",
        )
        return redirect(
            url_for("agent_router_page", peer_id=peer_id)
        )

    create_notification(
        "فتح WebFig",
        "تم فتح WebFig للراوتر %s" % peer["name"],
        kind="info",
        audience="agent",
        agent_account_id=account["id"],
        peer_id=peer_id,
    )
    return redirect(transparent_webfig_url(peer_id))




def db():
    con = sqlite3.connect(
        str(DB_PATH),
        timeout=60,
        check_same_thread=False,
    )
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=60000")
    con.execute("PRAGMA foreign_keys=ON")
    return con


def has_column(con, table, column):
    return any(row[1] == column for row in con.execute("PRAGMA table_info(%s)" % table))


def init_db():
    con = db()
    # WAL allows readers and the automatic sync writer to work together.
    try:
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        con.execute("PRAGMA wal_autocheckpoint=1000")
    except Exception:
        pass

    con.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'admin'
    );

    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS peers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        tunnel_ip TEXT UNIQUE NOT NULL,
        lan_ips TEXT DEFAULT '',
        public_ips TEXT DEFAULT '',
        private_key TEXT NOT NULL DEFAULT '',
        public_key TEXT NOT NULL,
        preshared_key TEXT NOT NULL DEFAULT '',
        enabled INTEGER NOT NULL DEFAULT 1,
        notes TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS port_forwards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        peer_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        internal_ip TEXT NOT NULL,
        internal_port INTEGER NOT NULL,
        external_port INTEGER NOT NULL UNIQUE,
        protocol TEXT NOT NULL DEFAULT 'tcp',
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL DEFAULT '',
        last_applied_at TEXT NOT NULL DEFAULT '',
        last_error TEXT NOT NULL DEFAULT ''
    );

    CREATE INDEX IF NOT EXISTS idx_port_forwards_peer
        ON port_forwards(peer_id);

    CREATE TABLE IF NOT EXISTS agent_devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        peer_id INTEGER NOT NULL,
        device_type TEXT NOT NULL,
        label TEXT NOT NULL DEFAULT '',
        tunnel_ip TEXT UNIQUE NOT NULL,
        private_key TEXT NOT NULL,
        public_key TEXT UNIQUE NOT NULL,
        preshared_key TEXT NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT '',
        UNIQUE(peer_id, device_type)
    );

    CREATE INDEX IF NOT EXISTS idx_agent_devices_peer
        ON agent_devices(peer_id);

    CREATE TABLE IF NOT EXISTS agent_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        display_name TEXT NOT NULL DEFAULT '',
        enabled INTEGER NOT NULL DEFAULT 1,
        can_view_subscribers INTEGER NOT NULL DEFAULT 1,
        can_download_vpn INTEGER NOT NULL DEFAULT 1,
        can_view_winbox INTEGER NOT NULL DEFAULT 1,
        can_add_subscriber INTEGER NOT NULL DEFAULT 0,
        can_edit_subscriber INTEGER NOT NULL DEFAULT 0,
        can_delete_subscriber INTEGER NOT NULL DEFAULT 0,
        can_change_password INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL DEFAULT '',
        last_login_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        audience TEXT NOT NULL DEFAULT 'admin',
        agent_account_id INTEGER DEFAULT 0,
        kind TEXT NOT NULL DEFAULT 'info',
        title TEXT NOT NULL,
        message TEXT NOT NULL DEFAULT '',
        peer_id INTEGER DEFAULT 0,
        is_read INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE INDEX IF NOT EXISTS idx_notifications_audience
        ON notifications(audience,agent_account_id,is_read,id);

    CREATE TABLE IF NOT EXISTS translation_overrides (
        lang TEXT NOT NULL,
        key TEXT NOT NULL,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL DEFAULT '',
        PRIMARY KEY(lang,key)
    );

    CREATE TABLE IF NOT EXISTS user_preferences (
        principal_type TEXT NOT NULL,
        principal_id INTEGER NOT NULL,
        language TEXT NOT NULL DEFAULT 'ar',
        theme TEXT NOT NULL DEFAULT 'dark',
        updated_at TEXT NOT NULL DEFAULT '',
        PRIMARY KEY(principal_type,principal_id)
    );

    CREATE TABLE IF NOT EXISTS agent_account_peers (
        account_id INTEGER NOT NULL,
        peer_id INTEGER NOT NULL,
        PRIMARY KEY(account_id, peer_id),
        FOREIGN KEY(account_id) REFERENCES agent_accounts(id) ON DELETE CASCADE,
        FOREIGN KEY(peer_id) REFERENCES peers(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_agent_account_peers_account
        ON agent_account_peers(account_id);
    CREATE INDEX IF NOT EXISTS idx_agent_account_peers_peer
        ON agent_account_peers(peer_id);

    CREATE TABLE IF NOT EXISTS router_groups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        notes TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS router_group_peers (
        group_id INTEGER NOT NULL,
        peer_id INTEGER NOT NULL,
        PRIMARY KEY(group_id,peer_id),
        FOREIGN KEY(group_id) REFERENCES router_groups(id) ON DELETE CASCADE,
        FOREIGN KEY(peer_id) REFERENCES peers(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS agent_account_groups (
        account_id INTEGER NOT NULL,
        group_id INTEGER NOT NULL,
        PRIMARY KEY(account_id,group_id),
        FOREIGN KEY(account_id) REFERENCES agent_accounts(id) ON DELETE CASCADE,
        FOREIGN KEY(group_id) REFERENCES router_groups(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        principal_type TEXT NOT NULL DEFAULT 'system',
        principal_name TEXT NOT NULL DEFAULT '',
        action TEXT NOT NULL,
        target TEXT NOT NULL DEFAULT '',
        details TEXT NOT NULL DEFAULT '',
        ip_address TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_audit_log_created ON audit_log(id DESC);
    """)

    migrations = [
        ("mt_host", "TEXT DEFAULT ''"),
        ("mt_port", "INTEGER DEFAULT 8728"),
        ("mt_username", "TEXT DEFAULT ''"),
        ("mt_password_enc", "TEXT DEFAULT ''"),
        ("mt_ssl", "INTEGER DEFAULT 0"),
        ("winbox_internal", "INTEGER DEFAULT 8291"),
        ("winbox_external", "INTEGER DEFAULT 0"),
        ("created_at", "TEXT DEFAULT ''"),
        ("imported_from_wg", "INTEGER DEFAULT 0"),
        ("source_comment", "TEXT DEFAULT ''"),
        ("direct_private_key", "TEXT DEFAULT ''"),
        ("direct_public_key", "TEXT DEFAULT ''"),
        ("direct_config_state", "TEXT DEFAULT ''"),
        ("direct_config_note", "TEXT DEFAULT ''"),
        ("direct_config_adopted_at", "TEXT DEFAULT ''"),
        ("webfig_port", "INTEGER DEFAULT 80"),
        ("webfig_last_state", "TEXT DEFAULT ''"),
        ("webfig_last_error", "TEXT DEFAULT ''"),
        ("recovery_username", "TEXT DEFAULT ''"),
        ("recovery_password_enc", "TEXT DEFAULT ''"),
        ("cloud_guard_version", "TEXT DEFAULT ''"),
        ("cloud_guard_last_ok", "TEXT DEFAULT ''"),
        ("cloud_guard_last_error", "TEXT DEFAULT ''"),
        ("cloud_main_state", "TEXT DEFAULT ''"),
        ("cloud_bypass_state", "TEXT DEFAULT ''"),
        ("cloud_health_token", "TEXT DEFAULT ''"),
    ]
    for column, definition in migrations:
        if not has_column(con, "peers", column):
            con.execute("ALTER TABLE peers ADD COLUMN %s %s" % (column, definition))

    pf_migrations = [
        ("subscriber_key", "TEXT DEFAULT ''"),
        ("subscriber_source", "TEXT DEFAULT ''"),
        ("auto_managed", "INTEGER DEFAULT 0"),
        ("last_seen_at", "TEXT DEFAULT ''"),
        ("owner_agent_id", "INTEGER DEFAULT 0"),
    ]
    for column, definition in pf_migrations:
        if not has_column(con, "port_forwards", column):
            con.execute(
                "ALTER TABLE port_forwards ADD COLUMN %s %s"
                % (column, definition)
            )

    agent_permission_migrations = [
        ("can_view_routers", "INTEGER NOT NULL DEFAULT 1"),
        ("can_view_router_status", "INTEGER NOT NULL DEFAULT 1"),
        ("can_view_handshake", "INTEGER NOT NULL DEFAULT 1"),
        ("can_view_traffic", "INTEGER NOT NULL DEFAULT 1"),
        ("can_view_ping", "INTEGER NOT NULL DEFAULT 1"),
        ("can_view_subscriber_ip", "INTEGER NOT NULL DEFAULT 1"),
        ("can_copy_subscriber_ip", "INTEGER NOT NULL DEFAULT 1"),
        ("can_open_subscriber", "INTEGER NOT NULL DEFAULT 1"),
        ("can_copy_winbox", "INTEGER NOT NULL DEFAULT 1"),
        ("can_view_vpn_access", "INTEGER NOT NULL DEFAULT 1"),
        ("can_view_mobile_qr", "INTEGER NOT NULL DEFAULT 1"),
        ("can_download_mobile_config", "INTEGER NOT NULL DEFAULT 1"),
        ("can_download_windows_config", "INTEGER NOT NULL DEFAULT 1"),
        ("can_sync_subscribers", "INTEGER NOT NULL DEFAULT 0"),
        ("can_export_subscribers", "INTEGER NOT NULL DEFAULT 0"),
        ("can_view_notes", "INTEGER NOT NULL DEFAULT 1"),
        ("can_edit_notes", "INTEGER NOT NULL DEFAULT 0"),
        ("can_open_webfig", "INTEGER NOT NULL DEFAULT 0"),
        ("read_only", "INTEGER NOT NULL DEFAULT 0"),
    ]
    if not has_column(con, "agent_accounts", "parent_agent_id"):
        con.execute("ALTER TABLE agent_accounts ADD COLUMN parent_agent_id INTEGER NOT NULL DEFAULT 0")
    if not has_column(con, "agent_accounts", "created_by_agent_id"):
        con.execute("ALTER TABLE agent_accounts ADD COLUMN created_by_agent_id INTEGER NOT NULL DEFAULT 0")

    for column, definition in agent_permission_migrations:
        if not has_column(con, "agent_accounts", column):
            con.execute(
                "ALTER TABLE agent_accounts ADD COLUMN %s %s"
                % (column, definition)
            )

    # Existing accounts inherit the old VPN master permission once.
    permission_migration_flag = con.execute(
        "SELECT value FROM settings WHERE key='agent_permissions_v750_migrated'"
    ).fetchone()
    if not permission_migration_flag:
        con.execute(
            """
            UPDATE agent_accounts SET
                can_view_vpn_access=can_download_vpn,
                can_view_mobile_qr=can_download_vpn,
                can_download_mobile_config=can_download_vpn,
                can_download_windows_config=can_download_vpn
            """
        )
        con.execute(
            "INSERT OR REPLACE INTO settings(key,value) "
            "VALUES('agent_permissions_v750_migrated','1')"
        )

    con.executescript("""
    CREATE INDEX IF NOT EXISTS idx_port_forwards_peer_enabled_name
        ON port_forwards(peer_id,enabled,name,id);
    CREATE INDEX IF NOT EXISTS idx_port_forwards_peer_internal_ip
        ON port_forwards(peer_id,internal_ip);
    CREATE INDEX IF NOT EXISTS idx_port_forwards_owner
        ON port_forwards(owner_agent_id,peer_id);
    CREATE INDEX IF NOT EXISTS idx_agent_accounts_username_enabled
        ON agent_accounts(username,enabled);
    CREATE INDEX IF NOT EXISTS idx_peers_enabled_name
        ON peers(enabled,name,id);
    """)

    # Existing v7.0 records were created by the automatic import module.
    # Mark them managed once so disconnected users can be removed.
    migration_flag = con.execute(
        "SELECT value FROM settings WHERE key='subscriber_v71_migrated'"
    ).fetchone()
    if not migration_flag:
        con.execute(
            "UPDATE port_forwards SET auto_managed=1 "
            "WHERE auto_managed=0"
        )
        con.execute(
            "INSERT OR REPLACE INTO settings(key,value) "
            "VALUES('subscriber_v71_migrated','1')"
        )

    if not con.execute("SELECT id FROM users WHERE username='admin'").fetchone():
        con.execute(
            "INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
            ("admin", generate_password_hash("admin123"), "admin")
        )

    defaults = {
        "interface": DEFAULT_INTERFACE,
        "endpoint": DEFAULT_ENDPOINT,
        "port": str(DEFAULT_PORT),
        "address": DEFAULT_ADDRESS,
        "dns": "1.1.1.1",
        "mtu": "1420",
        "out_interface": "",
        "system_name": "Cloud WG Panel",
        "pf_port_start": "20001",
        "pf_port_end": "65000",
        "subscriber_sync_enabled": "1",
        "subscriber_sync_seconds": "20",
        "subscriber_default_port": "80",
        "subscriber_default_protocol": "tcp",
        "agent_interface": DEFAULT_AGENT_INTERFACE,
        "agent_port": str(DEFAULT_AGENT_PORT),
        "agent_address": DEFAULT_AGENT_ADDRESS,
        "agent_mtu": "1420",
    }
    for key, value in defaults.items():
        con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (key, value))

    current_pf_start = con.execute(
        "SELECT value FROM settings WHERE key='pf_port_start'"
    ).fetchone()
    if not current_pf_start or int(current_pf_start[0] or 0) < 20001:
        con.execute(
            "INSERT OR REPLACE INTO settings(key,value) VALUES('pf_port_start','20001')"
        )

    current_subscriber_sync = con.execute(
        "SELECT value FROM settings WHERE key='subscriber_sync_seconds'"
    ).fetchone()
    if (
        not current_subscriber_sync
        or current_subscriber_sync[0] in ("", "60")
    ):
        con.execute(
            "INSERT OR REPLACE INTO settings(key,value) "
            "VALUES('subscriber_sync_seconds','20')"
        )

    current_address = con.execute("SELECT value FROM settings WHERE key='address'").fetchone()
    if current_address and current_address[0] in ('10.77.0.1/24', '10.77.0.1/24, 172.94.94.1/24'):
        con.execute("UPDATE settings SET value=? WHERE key='address'", (DEFAULT_ADDRESS,))
    con.commit()
    con.close()


def audit_event(action, target="", details=""):
    try:
        principal_type = "admin" if session.get("user_id") else ("agent" if session.get("agent_account_id") else "system")
        principal_name = session.get("username") or session.get("agent_username") or principal_type
        con = db()
        con.execute(
            "INSERT INTO audit_log(principal_type,principal_name,action,target,details,ip_address,created_at) VALUES(?,?,?,?,?,?,?)",
            (principal_type, str(principal_name), str(action), str(target), str(details), request.headers.get("X-Forwarded-For", request.remote_addr or "").split(",")[0].strip(), datetime.now().isoformat(timespec="seconds")),
        )
        con.commit(); con.close()
    except Exception:
        pass


def maintenance_enabled():
    try:
        con=db(); row=con.execute("SELECT value FROM settings WHERE key='maintenance_mode'").fetchone(); con.close()
        return bool(row and str(row[0]) == "1")
    except Exception:
        return False


def get_settings():
    con = db()
    rows = con.execute("SELECT key,value FROM settings").fetchall()
    con.close()
    return {row["key"]: row["value"] for row in rows}


def run(cmd, input_text=None, check=True):
    proc = subprocess.run(
        cmd,
        input=input_text.encode() if input_text else None,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    if check and proc.returncode != 0:
        raise RuntimeError(proc.stderr.decode(errors="ignore").strip() or "Command failed")
    return proc.stdout.decode(errors="ignore").strip()


def cipher():
    raw = hashlib.sha256(APP_SECRET.encode()).digest()
    return Fernet(base64.urlsafe_b64encode(raw))


def encrypt_text(value):
    if not value:
        return ""
    return cipher().encrypt(value.encode()).decode()


def decrypt_text(value):
    if not value:
        return ""
    try:
        return cipher().decrypt(value.encode()).decode()
    except InvalidToken:
        return ""



def tcp_listener_uses_port(port):
    proc = subprocess.run(
        ["ss", "-lntH"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    if proc.returncode != 0:
        return False
    suffix = ":%d" % int(port)
    for line in proc.stdout.decode(errors="ignore").splitlines():
        parts = line.split()
        if len(parts) >= 4 and parts[3].endswith(suffix):
            return True
    return False


def next_external_port(start=10001, end=19999):
    con = db()
    used = {
        int(row["winbox_external"])
        for row in con.execute(
            "SELECT winbox_external FROM peers WHERE winbox_external > 0"
        ).fetchall()
    }
    con.close()

    for port in range(start, end + 1):
        if port not in used and not tcp_listener_uses_port(port):
            return port
    raise RuntimeError("لا يوجد بورت WinBox خارجي فارغ")


def validate_external_port(port, peer_id=None):
    port = int(port)
    if port < 1 or port > 65535:
        raise RuntimeError("البورت الخارجي غير صحيح")

    con = db()
    if peer_id is None:
        row = con.execute(
            "SELECT name FROM peers WHERE winbox_external=? LIMIT 1",
            (port,)
        ).fetchone()
    else:
        row = con.execute(
            "SELECT name FROM peers WHERE winbox_external=? AND id<>? LIMIT 1",
            (port, int(peer_id))
        ).fetchone()
    con.close()

    if row:
        raise RuntimeError("البورت مستخدم من الوكيل: %s" % row["name"])
    if tcp_listener_uses_port(port):
        raise RuntimeError("البورت مستخدم من خدمة أخرى على Ubuntu")
    return True



def _listener_uses_port(port, protocol):
    protocol = protocol.lower()
    command = ["ss", "-lntH"] if protocol == "tcp" else ["ss", "-lnuH"]
    proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if proc.returncode != 0:
        return False

    suffix = ":%d" % int(port)
    for line in proc.stdout.decode(errors="ignore").splitlines():
        parts = line.split()
        if len(parts) >= 4 and parts[3].endswith(suffix):
            return True
    return False


def validate_forward_protocol(value):
    value = (value or "tcp").strip().lower()
    if value not in ("tcp", "udp", "both"):
        raise RuntimeError("البروتوكول يجب أن يكون TCP أو UDP أو الاثنين")
    return value


def normalize_internal_ip(value):
    try:
        address = ipaddress.ip_address((value or "").strip())
    except Exception:
        raise RuntimeError("IP المشترك الداخلي غير صحيح")
    if address.version != 4:
        raise RuntimeError("حالياً التحويل يدعم IPv4 فقط")
    if address.is_unspecified or address.is_multicast or address.is_loopback:
        raise RuntimeError("IP المشترك الداخلي غير مسموح")
    return str(address)



def _reserved_external_ports(exclude_forward_id=None):
    con = db()
    used = {
        int(row["winbox_external"])
        for row in con.execute(
            "SELECT winbox_external FROM peers WHERE winbox_external > 0"
        ).fetchall()
    }
    peer_ids = [
        int(row["id"])
        for row in con.execute(
            "SELECT id FROM peers WHERE enabled=1"
        ).fetchall()
    ]

    if exclude_forward_id is None:
        rows = con.execute(
            "SELECT external_port FROM port_forwards"
        ).fetchall()
    else:
        rows = con.execute(
            "SELECT external_port FROM port_forwards WHERE id<>?",
            (int(exclude_forward_id),)
        ).fetchall()

    used.update(int(row["external_port"]) for row in rows)
    con.close()

    settings = get_settings()
    used.update({
        22, 53, 80, 443, 1994, 8291, 8728, 8729, 9494,
        int(settings.get("port", "51820") or 51820),
        int(
            settings.get(
                "agent_port",
                str(DEFAULT_AGENT_PORT),
            ) or DEFAULT_AGENT_PORT
        ),
    })
    used.update(
        _direct_listen_port(peer_id)
        for peer_id in peer_ids
    )
    return used


def validate_forward_external_port(port, forward_id=None):
    try:
        port = int(port)
    except Exception:
        raise RuntimeError("البورت الخارجي غير صحيح")

    if port < 1024 or port > 65535:
        raise RuntimeError("البورت الخارجي يجب أن يكون بين 1024 و65535")

    if port in _reserved_external_ports(forward_id):
        raise RuntimeError("البورت الخارجي مستخدم أو محجوز")

    if _listener_uses_port(port, "tcp") or _listener_uses_port(port, "udp"):
        raise RuntimeError("البورت مستخدم من خدمة على Ubuntu")
    return port


def next_forward_external_port():
    settings = get_settings()
    start = max(20001, int(settings.get("pf_port_start", "20001") or 20001))
    end = min(65535, int(settings.get("pf_port_end", "65000") or 65000))
    if start > end:
        start, end = 20001, 65000

    used = _reserved_external_ports()
    for candidate in range(start, end + 1):
        if candidate in used:
            continue
        if _listener_uses_port(candidate, "tcp"):
            continue
        if _listener_uses_port(candidate, "udp"):
            continue
        return candidate

    raise RuntimeError("لا يوجد بورت خارجي فارغ ابتداءً من 20001")


def _forward_protocols(value):
    value = validate_forward_protocol(value)
    return ("tcp", "udp") if value == "both" else (value,)


def _router_remove_cloud_pf_rules(api):
    for command in ("/ip/firewall/nat/print", "/ip/firewall/filter/print"):
        rows = api.talk(command)
        remove_command = command.replace("/print", "/remove")
        for row in rows:
            comment = row.get("comment", "")
            if comment.startswith("CloudPF:") and row.get(".id"):
                api.talk(remove_command, {".id": row[".id"]})


def _router_add_port_forward(api, item):
    for protocol in _forward_protocols(item["protocol"]):
        base_comment = "CloudPF:%s:%s" % (item["id"], protocol)

        api.talk("/ip/firewall/nat/add", {
            "chain": "dstnat",
            "action": "dst-nat",
            "in-interface": "wg-cloud",
            "protocol": protocol,
            "dst-port": str(int(item["external_port"])),
            "to-addresses": item["internal_ip"],
            "to-ports": str(int(item["internal_port"])),
            "comment": base_comment,
            "place-before": "0",
            "disabled": "no",
        })

        api.talk("/ip/firewall/filter/add", {
            "chain": "forward",
            "action": "accept",
            "in-interface": "wg-cloud",
            "protocol": protocol,
            "dst-address": item["internal_ip"],
            "dst-port": str(int(item["internal_port"])),
            "connection-state": "new,established,related",
            "comment": base_comment + ":allow",
            "place-before": "0",
            "disabled": "no",
        })

        api.talk("/ip/firewall/filter/add", {
            "chain": "forward",
            "action": "accept",
            "out-interface": "wg-cloud",
            "protocol": protocol,
            "src-address": item["internal_ip"],
            "src-port": str(int(item["internal_port"])),
            "connection-state": "established,related",
            "comment": base_comment + ":reply",
            "place-before": "0",
            "disabled": "no",
        })




def _router_direct_access_digest(peer_id, subscriber_ips):
    settings = get_settings()
    peer = get_peer_or_404(peer_id)
    params = _direct_router_parameters(peer, settings)
    payload = "%s|%s|%s|%s|%s|%s|%s|%s|%s" % (
        int(peer_id),
        params["interface"],
        params["port"],
        params["server_ip"],
        params["router_ip"],
        params["server_public"],
        params["router_public"],
        params["router_interface"],
        ",".join(sorted(subscriber_ips)),
    )
    return hashlib.sha256(
        payload.encode("utf-8")
    ).hexdigest()


def _router_sync_direct_access_api(api, peer, subscriber_ips):
    settings = get_settings()
    management_interface = "wg-cloud"
    management_server_ip = (
        str(ipaddress.ip_interface(settings["address"]).ip)
        + "/32"
    )

    params = _direct_router_parameters(peer, settings)
    direct_interface = params["router_interface"]
    direct_server_ip = params["server_ip"]
    direct_server_cidr = direct_server_ip + "/32"
    direct_router_cidr = params["router_cidr"]

    # Keep the shared management peer limited to management traffic.
    remote_peer = api.find_one(
        "/interface/wireguard/peers/print",
        [
            "?interface=%s" % management_interface,
            "?comment=Cloud Server",
        ],
    )
    if not remote_peer:
        raise RuntimeError(
            "Peer مال Cloud Server غير موجود على MikroTik"
        )
    api.talk(
        "/interface/wireguard/peers/set",
        {
            ".id": remote_peer[".id"],
            "allowed-address": management_server_ip,
            "disabled": "no",
        },
    )

    # Remove the broken v7.3.2 peer from wg-cloud.
    old_direct_peer = api.find_one(
        "/interface/wireguard/peers/print",
        [
            "?interface=%s" % management_interface,
            "?comment=Cloud Direct Access",
        ],
    )
    if old_direct_peer:
        api.talk(
            "/interface/wireguard/peers/remove",
            {".id": old_direct_peer[".id"]},
        )

    # Dedicated WireGuard interface on the MikroTik itself.
    direct_wg = api.find_one(
        "/interface/wireguard/print",
        ["?name=%s" % direct_interface],
    )
    direct_wg_attrs = {
        "name": direct_interface,
        "private-key": params["router_private"],
        "listen-port": str(params["router_listen_port"]),
        "mtu": settings.get("mtu", "1420"),
        "comment": "Cloud Direct WireGuard",
        "disabled": "no",
    }
    if direct_wg:
        direct_wg_attrs[".id"] = direct_wg[".id"]
        api.talk(
            "/interface/wireguard/set",
            direct_wg_attrs,
        )
    else:
        api.talk(
            "/interface/wireguard/add",
            direct_wg_attrs,
        )

    direct_address = api.find_one(
        "/ip/address/print",
        [
            "?interface=%s" % direct_interface,
            "?comment=Cloud Direct WireGuard",
        ],
    )
    address_attrs = {
        "address": direct_router_cidr,
        "interface": direct_interface,
        "comment": "Cloud Direct WireGuard",
        "disabled": "no",
    }
    if direct_address:
        address_attrs[".id"] = direct_address[".id"]
        api.talk("/ip/address/set", address_attrs)
    else:
        api.talk("/ip/address/add", address_attrs)

    direct_comment = "Cloud Direct Access"
    direct_peer = api.find_one(
        "/interface/wireguard/peers/print",
        [
            "?interface=%s" % direct_interface,
            "?comment=%s" % direct_comment,
        ],
    )
    direct_attrs = {
        "interface": direct_interface,
        "public-key": params["server_public"],
        "preshared-key": peer["preshared_key"],
        "endpoint-address": params["endpoint"],
        "endpoint-port": str(params["port"]),
        "allowed-address": direct_server_cidr,
        "persistent-keepalive": "25",
        "comment": direct_comment,
        "disabled": "no",
    }
    if direct_peer:
        direct_attrs[".id"] = direct_peer[".id"]
        api.talk(
            "/interface/wireguard/peers/set",
            direct_attrs,
        )
    else:
        api.talk(
            "/interface/wireguard/peers/add",
            direct_attrs,
        )

    # Remove obsolete routes from older builds.
    for route_comment in (
        "Cloud Agent Return Route",
        "Cloud Direct Server Route",
    ):
        old_route = api.find_one(
            "/ip/route/print",
            ["?comment=%s" % route_comment],
        )
        if old_route:
            api.talk(
                "/ip/route/remove",
                {".id": old_route[".id"]},
            )

    # Rebuild the subscriber address list.
    for row in api.talk(
        "/ip/firewall/address-list/print"
    ):
        comment = row.get("comment", "")
        if comment.startswith("CloudAgentSubscriber:"):
            api.talk(
                "/ip/firewall/address-list/remove",
                {".id": row[".id"]},
            )

    for value in subscriber_ips:
        api.talk(
            "/ip/firewall/address-list/add",
            {
                "list": "CloudAgentSubscribers",
                "address": value,
                "comment": "CloudAgentSubscriber:%s:%s"
                % (peer["id"], value),
                "disabled": "no",
            },
        )

    access_comment = "Cloud Agent Direct Access"
    access_rule = api.find_one(
        "/ip/firewall/filter/print",
        ["?comment=%s" % access_comment],
    )
    access_attrs = {
        "chain": "forward",
        "action": "accept",
        "in-interface": direct_interface,
        "src-address": direct_server_ip,
        "dst-address-list": "CloudAgentSubscribers",
        "comment": access_comment,
        "disabled": "no",
        "place-before": "0",
    }
    if access_rule:
        access_attrs[".id"] = access_rule[".id"]
        access_attrs.pop("place-before", None)
        api.talk("/ip/firewall/filter/set", access_attrs)
    else:
        api.talk("/ip/firewall/filter/add", access_attrs)

    reply_comment = "Cloud Agent Direct Reply"
    reply_rule = api.find_one(
        "/ip/firewall/filter/print",
        ["?comment=%s" % reply_comment],
    )
    reply_attrs = {
        "chain": "forward",
        "action": "accept",
        "out-interface": direct_interface,
        "src-address-list": "CloudAgentSubscribers",
        "dst-address": direct_server_ip,
        "connection-state": "established,related",
        "comment": reply_comment,
        "disabled": "no",
        "place-before": "0",
    }
    if reply_rule:
        reply_attrs[".id"] = reply_rule[".id"]
        reply_attrs.pop("place-before", None)
        api.talk("/ip/firewall/filter/set", reply_attrs)
    else:
        api.talk("/ip/firewall/filter/add", reply_attrs)

    return len(subscriber_ips)


def sync_router_direct_subscriber_access(peer_id, force=False):
    peer = get_peer_or_404(peer_id)
    if not peer:
        raise RuntimeError("الوكيل غير موجود")
    subscriber_ips, conflicts = _direct_ips_for_peer(peer_id)
    digest = _router_direct_access_digest(
        peer_id, subscriber_ips
    )
    if (
        not force
        and DIRECT_ROUTER_STATES.get(int(peer_id)) == digest
    ):
        return {
            "changed": False,
            "count": len(subscriber_ips),
            "conflicts": conflicts,
        }

    api = connect_peer_api(peer)
    try:
        _router_sync_direct_access_api(
            api, peer, subscriber_ips
        )
    finally:
        api.close()

    DIRECT_ROUTER_STATES[int(peer_id)] = digest
    return {
        "changed": True,
        "count": len(subscriber_ips),
        "conflicts": conflicts,
    }


def sync_peer_port_forwards(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        raise RuntimeError("الوكيل غير موجود")

    con = db()
    rows = con.execute(
        """
        SELECT * FROM port_forwards
        WHERE peer_id=? AND enabled=1
        ORDER BY id
        """,
        (int(peer_id),)
    ).fetchall()
    con.close()

    direct_ips, _ = _direct_ips_for_peer(peer_id)
    api = connect_peer_api(peer)
    try:
        _router_remove_cloud_pf_rules(api)
        for row in rows:
            _router_add_port_forward(api, row)
        _router_sync_direct_access_api(
            api, peer, direct_ips
        )
        DIRECT_ROUTER_STATES[int(peer_id)] = (
            _router_direct_access_digest(
                peer_id, direct_ips
            )
        )
    finally:
        api.close()

    stamp = datetime.now().isoformat(timespec="seconds")
    con = db()
    con.execute(
        """
        UPDATE port_forwards
        SET last_applied_at=?, last_error=''
        WHERE peer_id=?
        """,
        (stamp, int(peer_id))
    )
    con.commit()
    con.close()
    return len(rows)


def mark_forward_error(forward_id, error):
    con = db()
    con.execute(
        "UPDATE port_forwards SET last_error=?, updated_at=? WHERE id=?",
        (
            str(error)[:1000],
            datetime.now().isoformat(timespec="seconds"),
            int(forward_id),
        )
    )
    con.commit()
    con.close()


def get_forward_or_404(forward_id):
    con = db()
    row = con.execute(
        """
        SELECT pf.*, p.name AS peer_name, p.tunnel_ip, p.mt_host
        FROM port_forwards pf
        JOIN peers p ON p.id=pf.peer_id
        WHERE pf.id=?
        """,
        (int(forward_id),)
    ).fetchone()
    con.close()
    return row


def _sync_forward_changes(peer_ids):
    regenerate_nat_rules()
    errors = []
    for peer_id in sorted({int(value) for value in peer_ids if value}):
        try:
            sync_peer_port_forwards(peer_id)
        except Exception as exc:
            errors.append("الوكيل %s: %s" % (peer_id, exc))
    if errors:
        raise RuntimeError(" | ".join(errors))
    return True


def parse_ubuntu_wireguard_peers():
    """Read peers from both the live WireGuard interface and wg-quick config.

    Live `wg show ... dump` is authoritative for public key / AllowedIPs / traffic.
    The config file is used to recover comments and PresharedKey when available.
    """
    settings = get_settings()
    interface = settings.get("interface", "wg-cloud0").strip() or "wg-cloud0"
    conf_path = Path("/etc/wireguard/%s.conf" % interface)

    config_by_public = {}
    config_by_ip = {}
    if conf_path.exists():
        current = None
        pending_comment = ""
        for raw_line in conf_path.read_text(errors="ignore").splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith("#"):
                pending_comment = line.lstrip("#").strip()
                continue
            if line == "[Peer]":
                if current:
                    pub = current.get("public_key", "")
                    if pub:
                        config_by_public[pub] = current
                    for ip_value in current.get("allowed_ips", []):
                        config_by_ip[ip_value] = current
                current = {
                    "comment": pending_comment,
                    "public_key": "",
                    "preshared_key": "",
                    "allowed_ips": [],
                }
                pending_comment = ""
                continue
            if current is None or "=" not in line:
                continue
            key, value = [part.strip() for part in line.split("=", 1)]
            if key == "PublicKey":
                current["public_key"] = value
            elif key == "PresharedKey":
                current["preshared_key"] = value
            elif key == "AllowedIPs":
                current["allowed_ips"] = [
                    item.strip() for item in value.split(",") if item.strip()
                ]
        if current:
            pub = current.get("public_key", "")
            if pub:
                config_by_public[pub] = current
            for ip_value in current.get("allowed_ips", []):
                config_by_ip[ip_value] = current

    peers = []
    proc = subprocess.run(
        ["wg", "show", interface, "dump"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if proc.returncode == 0:
        lines = proc.stdout.decode(errors="ignore").splitlines()
        for line in lines[1:]:
            cols = line.split("\t")
            if len(cols) < 8:
                continue
            public_key = cols[0].strip()
            allowed_values = [x.strip() for x in cols[3].split(",") if x.strip()]
            config_item = config_by_public.get(public_key)
            if not config_item:
                for value in allowed_values:
                    if value in config_by_ip:
                        config_item = config_by_ip[value]
                        break
            peers.append({
                "comment": (config_item or {}).get("comment", ""),
                "public_key": public_key,
                "preshared_key": (config_item or {}).get("preshared_key", ""),
                "allowed_ips": allowed_values,
                "endpoint": cols[2],
                "latest_handshake": int(cols[4] or 0),
                "rx": int(cols[5] or 0),
                "tx": int(cols[6] or 0),
            })

    # If the interface is temporarily down, still import from the config file.
    if not peers:
        peers = list(config_by_public.values())

    return peers


def import_peers_from_ubuntu():
    parsed = parse_ubuntu_wireguard_peers()
    debug_path = APP_DIR / "sync-debug.log"
    debug_lines = [
        "%s interface=%s found=%d" % (
            datetime.now().isoformat(timespec="seconds"),
            get_settings().get("interface", "wg-cloud0"),
            len(parsed),
        )
    ]
    if not parsed:
        debug_path.write_text("\n".join(debug_lines) + "\n")
        return 0

    con = db()
    imported = 0
    updated = 0
    skipped = 0
    try:
        used_ports = {
            int(row["winbox_external"])
            for row in con.execute(
                "SELECT winbox_external FROM peers WHERE winbox_external > 0"
            ).fetchall()
        }

        def allocate_port():
            for candidate in range(10001, 20000):
                if candidate in used_ports or tcp_listener_uses_port(candidate):
                    continue
                used_ports.add(candidate)
                return candidate
            raise RuntimeError("لا يوجد بورت WinBox خارجي فارغ")

        for item in parsed:
            public_key = (item.get("public_key") or "").strip()
            if not public_key:
                skipped += 1
                debug_lines.append("skip: missing public key")
                continue

            tunnel_ip = ""
            for allowed in item.get("allowed_ips", []):
                try:
                    network = ipaddress.ip_network(allowed, strict=False)
                    if network.version == 4 and network.prefixlen == 32:
                        tunnel_ip = str(network.network_address) + "/32"
                        break
                except Exception:
                    continue

            if not tunnel_ip:
                skipped += 1
                debug_lines.append("skip %s: no IPv4 /32 AllowedIPs (%s)" % (
                    public_key, item.get("allowed_ips", [])
                ))
                continue

            existing = con.execute(
                "SELECT * FROM peers WHERE public_key=? OR tunnel_ip=? LIMIT 1",
                (public_key, tunnel_ip)
            ).fetchone()

            if existing:
                external = int(existing["winbox_external"] or 0)
                if external <= 0:
                    external = allocate_port()
                con.execute(
                    """UPDATE peers SET
                       public_key=?, tunnel_ip=?, source_comment=?, imported_from_wg=1,
                       mt_host=?, winbox_external=?
                       WHERE id=?""",
                    (
                        public_key,
                        tunnel_ip,
                        item.get("comment", ""),
                        tunnel_ip.split("/")[0],
                        external,
                        existing["id"],
                    )
                )
                updated += 1
                debug_lines.append("update id=%s ip=%s pub=%s port=%s" % (
                    existing["id"], tunnel_ip, public_key, external
                ))
                continue

            name = (item.get("comment") or "").strip()
            if not name:
                name = "Ubuntu Peer %s" % tunnel_ip.split("/")[0]
            external_port = allocate_port()
            peer_ip = tunnel_ip.split("/")[0]

            con.execute(
                """INSERT INTO peers(
                    name,tunnel_ip,lan_ips,public_ips,private_key,public_key,preshared_key,
                    enabled,notes,mt_host,mt_port,mt_username,mt_password_enc,mt_ssl,
                    winbox_internal,winbox_external,created_at,imported_from_wg,source_comment
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'),?,?)""",
                (
                    name, tunnel_ip, "", "", "", public_key,
                    item.get("preshared_key", ""), 1,
                    "Imported automatically from Ubuntu WireGuard",
                    peer_ip, 9494, "", "", 0, 8291, external_port, 1,
                    item.get("comment", ""),
                )
            )
            imported += 1
            debug_lines.append("insert ip=%s pub=%s port=%s" % (
                tunnel_ip, public_key, external_port
            ))

        con.commit()
    except Exception as exc:
        con.rollback()
        debug_lines.append("ERROR: %s" % exc)
        debug_path.write_text("\n".join(debug_lines) + "\n")
        raise
    finally:
        con.close()

    debug_lines.append("done imported=%d updated=%d skipped=%d" % (
        imported, updated, skipped
    ))
    debug_path.write_text("\n".join(debug_lines) + "\n")
    regenerate_nat_rules()
    return imported

def wg_keypair():
    private_key = run(["wg", "genkey"])
    public_key = run(["wg", "pubkey"], input_text=private_key)
    psk = run(["wg", "genpsk"])
    return private_key, public_key, psk


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.before_request
def enforce_maintenance_mode():
    if request.endpoint in (None, "static", "login", "logout") or request.path.startswith("/static/"):
        return None
    if maintenance_enabled() and not session.get("user_id"):
        return render_template("maintenance.html", settings=get_settings()), 503
    return None


AGENT_PERMISSION_FIELDS = (
    "can_view_routers",
    "can_view_router_status",
    "can_view_handshake",
    "can_view_traffic",
    "can_view_ping",
    "can_view_subscribers",
    "can_view_subscriber_ip",
    "can_copy_subscriber_ip",
    "can_open_subscriber",
    "can_view_winbox",
    "can_copy_winbox",
    "can_open_webfig",
    "can_view_vpn_access",
    "can_view_mobile_qr",
    "can_download_mobile_config",
    "can_download_windows_config",
    "can_add_subscriber",
    "can_edit_subscriber",
    "can_delete_subscriber",
    "can_sync_subscribers",
    "can_export_subscribers",
    "can_view_notes",
    "can_edit_notes",
    "can_change_password",
    "read_only",
)

AGENT_DEFAULT_ENABLED_PERMISSIONS = (
    "can_view_routers",
    "can_view_router_status",
    "can_view_handshake",
    "can_view_traffic",
    "can_view_ping",
    "can_view_subscribers",
    "can_view_subscriber_ip",
    "can_copy_subscriber_ip",
    "can_open_subscriber",
    "can_view_winbox",
    "can_copy_winbox",
    "can_view_vpn_access",
    "can_view_mobile_qr",
    "can_download_mobile_config",
    "can_download_windows_config",
    "can_view_notes",
    "can_change_password",
)

AGENT_MUTATION_PERMISSIONS = (
    "can_add_subscriber",
    "can_edit_subscriber",
    "can_delete_subscriber",
    "can_sync_subscribers",
    "can_edit_notes",
    "can_change_password",
)

AGENT_DANGEROUS_PERMISSIONS = (
    "can_delete_subscriber",
    "can_sync_subscribers",
    "can_edit_notes",
    "can_change_password",
)

AGENT_PERMISSION_GROUPS = (
    (
        "الراوترات والوصول الأساسي",
        (
            ("can_view_routers", "مشاهدة الراوترات", "إظهار الراوترات المخصصة لهذا الوكيل"),
            ("can_view_router_status", "مشاهدة حالة الراوتر", "عرض متصل أو غير متصل"),
            ("can_view_notes", "مشاهدة الملاحظات", "عرض ملاحظات الراوتر"),
            ("can_edit_notes", "تعديل الملاحظات", "السماح بحفظ وتغيير ملاحظات الراوتر"),
        ),
    ),
    (
        "المراقبة وجودة الاتصال",
        (
            ("can_view_handshake", "آخر Handshake", "عرض وقت آخر اتصال WireGuard"),
            ("can_view_traffic", "حركة البيانات RX / TX", "عرض الرفع والتنزيل عبر النفق"),
            ("can_view_ping", "Ping وPacket Loss", "عرض زمن الاستجابة ونسبة الفقدان"),
        ),
    ),
    (
        "المشتركون والدخول المباشر",
        (
            ("can_view_subscribers", "مشاهدة المشتركين", "عرض مشتركي الراوتر المسموح"),
            ("can_view_subscriber_ip", "مشاهدة IP الداخلي", "إظهار عنوان المشترك الداخلي"),
            ("can_copy_subscriber_ip", "نسخ IP الداخلي", "إظهار زر النسخ بجانب العنوان"),
            ("can_open_subscriber", "فتح رابط المشترك", "جعل العنوان قابلاً للضغط والفتح"),
            ("can_export_subscribers", "تصدير المشتركين", "تنزيل قائمة CSV"),
        ),
    ),
    (
        "إدارة المشتركين",
        (
            ("can_add_subscriber", "إضافة مشترك يدوي", "إضافة عنوان داخلي يدوياً"),
            ("can_edit_subscriber", "تعديل مشترك يدوي", "تعديل السجلات اليدوية"),
            ("can_delete_subscriber", "حذف مشترك يدوي", "حذف السجلات اليدوية"),
            ("can_sync_subscribers", "مزامنة المشتركين", "تشغيل المزامنة مع MikroTik"),
        ),
    ),
    (
        "الدخول إلى الراوتر",
        (
            ("can_view_winbox", "مشاهدة عنوان WinBox", "عرض عنوان ومنفذ WinBox"),
            ("can_copy_winbox", "نسخ عنوان WinBox", "إظهار زر النسخ"),
            ("can_open_webfig", "فتح WebFig", "فتح WebFig عبر بوابة النظام"),
        ),
    ),
    (
        "WireGuard للوكيل",
        (
            ("can_view_vpn_access", "مشاهدة قسم WireGuard", "إظهار إعدادات دخول الوكيل"),
            ("can_view_mobile_qr", "مشاهدة QR للموبايل", "إظهار باركود WireGuard"),
            ("can_download_mobile_config", "تحميل كونفك الموبايل", "تنزيل ملف الموبايل"),
            ("can_download_windows_config", "تحميل كونفك Windows", "تنزيل ملف Windows"),
        ),
    ),
    (
        "الحساب والأمان",
        (
            ("can_change_password", "تغيير كلمة المرور", "السماح للوكيل بتغيير كلمة مروره"),
            ("read_only", "مشاهدة فقط", "إلغاء صلاحيات الإضافة والتعديل والحذف والمزامنة"),
        ),
    ),
)

AGENT_PERMISSION_LABELS = tuple(
    (field, label)
    for _, group in AGENT_PERMISSION_GROUPS
    for field, label, _ in group
)


def get_agent_account(account_id):
    con = db()
    row = con.execute(
        "SELECT * FROM agent_accounts WHERE id=?",
        (int(account_id),),
    ).fetchone()
    con.close()
    return dict(row) if row else None


def current_agent_account():
    account_id = session.get("agent_account_id")
    if not account_id:
        return None
    account = get_agent_account(account_id)
    if account and int(account.get("parent_agent_id") or 0):
        parent = get_agent_account(int(account.get("parent_agent_id") or 0))
        if not parent or not parent.get("enabled"):
            account = None
        else:
            for field in AGENT_PERMISSION_FIELDS:
                account[field] = 1 if account.get(field) and parent.get(field) else 0
    if not account or not account.get("enabled"):
        session.pop("agent_account_id", None)
        session.pop("agent_username", None)
        session.pop("agent_display_name", None)
        return None
    return account


def agent_login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        account = current_agent_account()
        if not account:
            return redirect(url_for("agent_login"))
        return fn(*args, **kwargs)
    return wrapper


def agent_permission_required(permission, mutating=False):
    if permission not in AGENT_PERMISSION_FIELDS:
        raise RuntimeError("Unknown agent permission")

    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            account = current_agent_account()
            if not account:
                return redirect(url_for("agent_login"))
            if not account.get(permission):
                flash("ما عندك صلاحية لتنفيذ هذا الإجراء", "danger")
                return redirect(url_for("agent_dashboard"))
            if mutating and account.get("read_only"):
                flash("الحساب مضبوط على مشاهدة فقط", "danger")
                return redirect(url_for("agent_dashboard"))
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def agent_mutation_permission_required(permission):
    return agent_permission_required(permission, mutating=True)


def assigned_peers_for_agent(account_id):
    con = db()
    rows = con.execute(
        """
        SELECT DISTINCT p.*
        FROM peers p
        LEFT JOIN agent_account_peers ap ON ap.peer_id=p.id AND ap.account_id=?
        LEFT JOIN router_group_peers rgp ON rgp.peer_id=p.id
        LEFT JOIN agent_account_groups aag ON aag.group_id=rgp.group_id AND aag.account_id=?
        WHERE ap.account_id IS NOT NULL OR aag.account_id IS NOT NULL
        ORDER BY p.name,p.id
        """,
        (int(account_id), int(account_id)),
    ).fetchall()
    con.close()
    return [dict(row) for row in rows]


def get_agent_assigned_peer(account_id, peer_id):
    con = db()
    row = con.execute(
        """
        SELECT p.*
        FROM peers p
        JOIN agent_account_peers ap ON ap.peer_id=p.id
        WHERE ap.account_id=? AND p.id=?
        """,
        (int(account_id), int(peer_id)),
    ).fetchone()
    con.close()
    return dict(row) if row else None


def agent_owned_forward(account_id, forward_id):
    con = db()
    row = con.execute(
        """
        SELECT pf.*
        FROM port_forwards pf
        JOIN agent_account_peers ap ON ap.peer_id=pf.peer_id
        WHERE ap.account_id=? AND pf.id=?
          AND pf.owner_agent_id=?
        """,
        (int(account_id), int(forward_id), int(account_id)),
    ).fetchone()
    con.close()
    return dict(row) if row else None


def get_agent_assigned_forward(account_id, forward_id):
    con = db()
    row = con.execute(
        """
        SELECT pf.*
        FROM port_forwards pf
        JOIN agent_account_peers ap ON ap.peer_id=pf.peer_id
        WHERE ap.account_id=? AND pf.id=?
        """,
        (int(account_id), int(forward_id)),
    ).fetchone()
    con.close()
    return dict(row) if row else None


def agent_account_summary(account):
    con = db()
    row = con.execute(
        """
        SELECT aa.*,
               COUNT(DISTINCT ap.peer_id) AS peer_count,
               GROUP_CONCAT(p.name, '، ') AS peer_names
        FROM agent_accounts aa
        LEFT JOIN agent_account_peers ap ON ap.account_id=aa.id
        LEFT JOIN peers p ON p.id=ap.peer_id
        WHERE aa.id=?
        GROUP BY aa.id
        """,
        (int(account["id"]),),
    ).fetchone()
    con.close()
    item = dict(row) if row else dict(account)
    item["peer_count"] = int(item.get("peer_count") or 0)
    item["permission_count"] = sum(
        1 for field in AGENT_PERMISSION_FIELDS
        if field != "read_only" and item.get(field)
    )
    return item


def _agent_direct_url(item):
    port = int(item.get("internal_port") or 80)
    protocol = (item.get("protocol") or "tcp").lower()
    scheme = "https" if port == 443 else "http"
    if port in (80, 443):
        return "%s://%s" % (scheme, item["internal_ip"])
    if protocol == "udp":
        return "%s:%s/UDP" % (item["internal_ip"], port)
    return "%s://%s:%s" % (scheme, item["internal_ip"], port)


def _agent_allowed_manual_ip(peer, value):
    value = normalize_internal_ip(value)
    address = ipaddress.ip_address(value)
    allowed = [
        ipaddress.ip_network("10.0.0.0/8"),
        ipaddress.ip_network("100.64.0.0/10"),
        ipaddress.ip_network("172.16.0.0/12"),
        ipaddress.ip_network("192.168.0.0/16"),
    ]
    for raw in (peer.get("lan_ips") or "").replace("\n", ",").split(","):
        raw = raw.strip()
        if not raw:
            continue
        try:
            allowed.append(ipaddress.ip_network(raw, strict=False))
        except Exception:
            pass
    if not any(address in network for network in allowed):
        raise RuntimeError("الـIP خارج الشبكات الداخلية المسموحة")
    return value



SUPPORTED_LANGUAGES = {
    "ar": {"label": "العربية", "dir": "rtl"},
    "en": {"label": "English", "dir": "ltr"},
    "ku": {"label": "کوردی", "dir": "rtl"},
}
SUPPORTED_THEMES = {"dark"}

TRANSLATIONS = {
    "ar": {
        "dashboard": "لوحة التحكم",
        "wireguard_agents": "الوكلاء وWireGuard",
        "subscriber_forwards": "تحويلات المشتركين",
        "agent_accounts": "حسابات الوكلاء",
        "logout": "تسجيل الخروج",
        "menu": "القائمة",
        "online": "متصل",
        "offline": "غير متصل",
        "notifications": "الإشعارات",
        "mark_all_read": "تحديد الكل كمقروء",
        "no_notifications": "لا توجد إشعارات جديدة",
        "theme": "المظهر",
        "language": "اللغة",
        "dark": "ليلي",
        "light": "نهاري",
        "auto": "تلقائي",
        "agent_portal": "بوابة الوكيل",
        "home": "الرئيسية",
        "login": "تسجيل الدخول",
        "username": "اسم المستخدم",
        "password": "كلمة المرور",
        "admin_login": "دخول الإدارة",
        "agent_login": "دخول بوابة الوكلاء",
        "change_agent_password": "تغيير كلمة مرور حساب الوكيل",
        "webfig": "فتح WebFig",
        "router_tools": "أدوات الراوتر",
    },
    "en": {
        "dashboard": "Dashboard",
        "wireguard_agents": "Agents & WireGuard",
        "subscriber_forwards": "Subscriber Forwards",
        "agent_accounts": "Agent Accounts",
        "logout": "Sign out",
        "menu": "Menu",
        "online": "Online",
        "offline": "Offline",
        "notifications": "Notifications",
        "mark_all_read": "Mark all as read",
        "no_notifications": "No new notifications",
        "theme": "Theme",
        "language": "Language",
        "dark": "Dark",
        "light": "Light",
        "auto": "Auto",
        "agent_portal": "Agent Portal",
        "home": "Home",
        "login": "Sign in",
        "username": "Username",
        "password": "Password",
        "admin_login": "Administrator sign in",
        "agent_login": "Agent portal sign in",
        "change_agent_password": "Change agent account password",
        "webfig": "Open WebFig",
        "router_tools": "Router tools",
    },
    "ku": {
        "dashboard": "داشبۆرد",
        "wireguard_agents": "بریکارەکان و WireGuard",
        "subscriber_forwards": "گواستنەوەکانی بەشداربووان",
        "agent_accounts": "هەژمارەکانی بریکار",
        "logout": "چوونەدەرەوە",
        "menu": "مێنیو",
        "online": "پەیوەستە",
        "offline": "پچڕاوە",
        "notifications": "ئاگادارکردنەوەکان",
        "mark_all_read": "هەمووی وەک خوێندراوە",
        "no_notifications": "ئاگادارکردنەوەی نوێ نییە",
        "theme": "ڕووکار",
        "language": "زمان",
        "dark": "تاریک",
        "light": "ڕووناک",
        "auto": "خۆکار",
        "agent_portal": "دەروازەی بریکار",
        "home": "سەرەکی",
        "login": "چوونەژوورەوە",
        "username": "ناوی بەکارهێنەر",
        "password": "وشەی نهێنی",
        "admin_login": "چوونەژوورەوەی بەڕێوەبەر",
        "agent_login": "چوونەژوورەوەی بریکار",
        "change_agent_password": "گۆڕینی وشەی نهێنی هەژماری بریکار",
        "webfig": "کردنەوەی WebFig",
        "router_tools": "ئامرازەکانی ڕاوتەر",
    },
}


def _principal():
    if session.get("user_id"):
        return "admin", int(session["user_id"])
    if session.get("agent_account_id"):
        return "agent", int(session["agent_account_id"])
    return "guest", 0


def get_preferences():
    principal_type, principal_id = _principal()
    default_lang = session.get("language", "ar")
    default_theme = session.get("theme", "dark")
    if principal_id:
        con = db()
        row = con.execute(
            """
            SELECT language,theme FROM user_preferences
            WHERE principal_type=? AND principal_id=?
            """,
            (principal_type, principal_id),
        ).fetchone()
        con.close()
        if row:
            default_lang = row["language"] or default_lang
            default_theme = "dark"
    if default_lang not in SUPPORTED_LANGUAGES:
        default_lang = "ar"
    if default_theme not in SUPPORTED_THEMES:
        default_theme = "dark"
    return {"language": default_lang, "theme": default_theme}


def save_preferences(language=None, theme=None):
    current = get_preferences()
    language = language if language in SUPPORTED_LANGUAGES else current["language"]
    theme = "dark"
    session["language"] = language
    session["theme"] = theme
    principal_type, principal_id = _principal()
    if principal_id:
        con = db()
        con.execute(
            """
            INSERT OR REPLACE INTO user_preferences
            (principal_type,principal_id,language,theme,updated_at)
            VALUES (?,?,?,?,?)
            """,
            (
                principal_type, principal_id, language, theme,
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
        con.commit()
        con.close()
    return {"language": language, "theme": theme}


def translate(key, **values):
    prefs = get_preferences()
    lang = prefs["language"]
    con = db()
    row = con.execute(
        "SELECT value FROM translation_overrides WHERE lang=? AND key=?",
        (lang, key),
    ).fetchone()
    con.close()
    text = row["value"] if row else TRANSLATIONS.get(lang, {}).get(
        key, TRANSLATIONS["ar"].get(key, key)
    )
    try:
        return text.format(**values)
    except Exception:
        return text



def create_notification(title, message="", kind="info", audience="admin",
                        agent_account_id=0, peer_id=0):
    try:
        con = db()
        stamp = datetime.now().isoformat(timespec="seconds")
        con.execute(
            """
            INSERT INTO notifications
            (audience,agent_account_id,kind,title,message,peer_id,is_read,created_at)
            VALUES (?,?,?,?,?,?,0,?)
            """,
            (
                audience, int(agent_account_id or 0), kind,
                title, message, int(peer_id or 0), stamp,
            ),
        )

        # Any notification tied to a router is relevant only to agents
        # assigned to that router.  Global/admin-only notices are not mirrored.
        should_mirror = (
            audience == "admin"
            and int(peer_id or 0) > 0
        )
        if should_mirror:
            agent_rows = con.execute(
                """
                SELECT aa.id
                FROM agent_accounts aa
                JOIN agent_account_peers ap ON ap.account_id=aa.id
                WHERE aa.enabled=1 AND ap.peer_id=?
                """,
                (int(peer_id),),
            ).fetchall()
            for row in agent_rows:
                con.execute(
                    """
                    INSERT INTO notifications
                    (audience,agent_account_id,kind,title,message,peer_id,is_read,created_at)
                    VALUES ('agent',?,?,?,?,?,0,?)
                    """,
                    (
                        int(row["id"]), kind, title, message,
                        int(peer_id), stamp,
                    ),
                )

        con.execute(
            """
            DELETE FROM notifications
            WHERE id NOT IN (
                SELECT id FROM notifications
                ORDER BY id DESC LIMIT 2000
            )
            """
        )
        con.commit()
        con.close()
    except Exception:
        pass

def notification_rows(limit=20):
    principal_type, principal_id = _principal()
    con = db()
    if principal_type == "agent":
        rows = con.execute(
            """
            SELECT n.* FROM notifications n
            WHERE n.audience='agent' AND n.agent_account_id=?
              AND (
                n.peer_id=0 OR EXISTS (
                  SELECT 1 FROM agent_account_peers ap
                  WHERE ap.account_id=? AND ap.peer_id=n.peer_id
                )
              )
            ORDER BY n.id DESC LIMIT ?
            """,
            (principal_id, principal_id, int(limit)),
        ).fetchall()
        unread = con.execute(
            """
            SELECT COUNT(*) AS c FROM notifications n
            WHERE n.audience='agent' AND n.agent_account_id=? AND n.is_read=0
              AND (
                n.peer_id=0 OR EXISTS (
                  SELECT 1 FROM agent_account_peers ap
                  WHERE ap.account_id=? AND ap.peer_id=n.peer_id
                )
              )
            """,
            (principal_id, principal_id),
        ).fetchone()["c"]
    else:
        rows = con.execute(
            """
            SELECT * FROM notifications
            WHERE audience='admin'
            ORDER BY id DESC LIMIT ?
            """,
            (int(limit),),
        ).fetchall()
        unread = con.execute(
            """
            SELECT COUNT(*) AS c FROM notifications
            WHERE audience='admin' AND is_read=0
            """
        ).fetchone()["c"]
    con.close()
    return [dict(row) for row in rows], int(unread)


@app.context_processor
def inject_global_ui_context():
    prefs = get_preferences()
    lang_meta = SUPPORTED_LANGUAGES[prefs["language"]]
    rows, unread = notification_rows(limit=12)
    return {
        "t": translate,
        "ui_language": prefs["language"],
        "ui_direction": lang_meta["dir"],
        "ui_theme": prefs["theme"],
        "supported_languages": SUPPORTED_LANGUAGES,
        "notification_items": rows,
        "notification_unread": unread,
    }


@app.route("/ui/preferences", methods=["POST"])
def ui_preferences():
    data = request.get_json(silent=True) or request.form
    saved = save_preferences(
        language=str(data.get("language", "")).strip(),
        theme=str(data.get("theme", "")).strip(),
    )
    if request.is_json:
        return jsonify({"ok": True, **saved})
    return redirect(request.referrer or url_for("dashboard"))


@app.route("/api/notifications")
def notifications_api():
    if not session.get("user_id") and not session.get("agent_account_id"):
        return jsonify({"error": "unauthorized"}), 401
    rows, unread = notification_rows(limit=30)
    return jsonify({"notifications": rows, "unread": unread})


@app.route("/api/notifications/read-all", methods=["POST"])
def notifications_read_all_api():
    principal_type, principal_id = _principal()
    if principal_type == "guest":
        return jsonify({"error": "unauthorized"}), 401
    con = db()
    if principal_type == "agent":
        con.execute(
            """
            UPDATE notifications SET is_read=1
            WHERE audience='agent' AND agent_account_id=?
            """,
            (principal_id,),
        )
    else:
        con.execute(
            "UPDATE notifications SET is_read=1 WHERE audience='admin'"
        )
    con.commit()
    con.close()
    return jsonify({"ok": True, "unread": 0})


@app.route("/translations", methods=["GET", "POST"])
@login_required
def translations_manager():
    if request.method == "POST":
        lang = request.form.get("lang", "ar")
        key = request.form.get("key", "").strip()
        value = request.form.get("value", "").strip()
        if lang in SUPPORTED_LANGUAGES and key and value:
            con = db()
            con.execute(
                """
                INSERT OR REPLACE INTO translation_overrides
                (lang,key,value,updated_at) VALUES (?,?,?,?)
                """,
                (
                    lang, key, value,
                    datetime.now().isoformat(timespec="seconds"),
                ),
            )
            con.commit()
            con.close()
            flash("تم حفظ الترجمة", "success")
        return redirect(url_for("translations_manager"))

    con = db()
    overrides = con.execute(
        """
        SELECT * FROM translation_overrides
        ORDER BY lang,key
        """
    ).fetchall()
    con.close()
    return render_template(
        "translations.html",
        overrides=overrides,
        base_keys=sorted(TRANSLATIONS["ar"].keys()),
        translations=TRANSLATIONS,
        settings=get_settings(),
    )


@app.context_processor
def inject_agent_portal_context():
    account = current_agent_account()
    if not account:
        return {
            "agent_account": None,
            "agent_nav_peers": [],
        }
    return {
        "agent_account": account,
        "agent_nav_peers": assigned_peers_for_agent(account["id"]),
    }


def clean_networks(text):
    result = []
    for item in [x.strip() for x in text.replace("\n", ",").split(",") if x.strip()]:
        ipaddress.ip_network(item, strict=False)
        result.append(item)
    return result


def next_tunnel_ip():
    settings = get_settings()
    network = ipaddress.ip_network(settings.get("address", DEFAULT_ADDRESS), strict=False)
    server_ip = ipaddress.ip_interface(settings.get("address", DEFAULT_ADDRESS)).ip

    con = db()
    used = set()
    for row in con.execute("SELECT tunnel_ip FROM peers").fetchall():
        try:
            used.add(ipaddress.ip_interface(row["tunnel_ip"]).ip)
        except Exception:
            pass
    con.close()

    for host in network.hosts():
        if host == server_ip:
            continue
        if host not in used:
            return str(host) + "/32"
    raise RuntimeError("لا يوجد IP فارغ داخل شبكة WireGuard")



def next_winbox_port(start=10001, end=19999):
    con = db()
    used = set()
    for row in con.execute("SELECT winbox_external FROM peers WHERE winbox_external > 0").fetchall():
        used.add(int(row["winbox_external"]))
    con.close()
    for port in range(start, end + 1):
        if port not in used:
            return port
    raise RuntimeError("لا يوجد بورت WinBox خارجي فارغ")



MAIN_WG_LOCK = threading.RLock()
AGENT_WG_LOCK = threading.RLock()
DIRECT_ACCESS_LOCK = threading.RLock()
DIRECT_WG_LOCK = threading.RLock()
DIRECT_ROUTE_STATE = {"digest": ""}
DIRECT_ROUTER_STATES = {}

RUNTIME_CACHE_LOCK = threading.Lock()
RUNTIME_CACHE = {
    "main_stats": {},
    "agent_stats": {},
    "updated_at": 0.0,
}
PING_CACHE_LOCK = threading.Lock()
PING_CACHE = {}
SUBSCRIBER_SYNC_STATE_LOCK = threading.Lock()
SUBSCRIBER_SYNC_STATE = {
    "running": False,
    "last_started_at": "",
    "last_finished_at": "",
    "last_result": {},
    "last_error": "",
}

DIRECT_WG_PORT_BASE = 53000
DIRECT_ROUTE_TABLE_BASE = 20000
DIRECT_RULE_PRIORITY_BASE = 10000



def _direct_interface_name(peer_id):
    value = "wg-r%s" % int(peer_id)
    if len(value) > 15:
        raise RuntimeError("رقم الراوتر كبير ولا يمكن إنشاء واجهة Linux")
    return value


def _direct_listen_port(peer_id):
    port = DIRECT_WG_PORT_BASE + int(peer_id)
    if port > 65535:
        raise RuntimeError(
            "تعذر تخصيص منفذ WireGuard مستقل للراوتر %s"
            % peer_id
        )
    return port


def _direct_tunnel_network(peer_id):
    """Allocate one unique /30 from 10.254.0.0/16 per router."""
    ordinal = int(peer_id) - 1
    if ordinal < 0 or ordinal >= 16384:
        raise RuntimeError(
            "تعذر تخصيص شبكة نفق مستقلة للراوتر %s" % peer_id
        )

    base = int(ipaddress.ip_address("10.254.0.0"))
    network_address = ipaddress.ip_address(base + (ordinal * 4))
    return ipaddress.ip_network(
        "%s/30" % network_address,
        strict=False,
    )


def _direct_server_ip(peer_id):
    network = _direct_tunnel_network(peer_id)
    return str(network.network_address + 1)


def _direct_router_ip(peer_id):
    network = _direct_tunnel_network(peer_id)
    return str(network.network_address + 2)


def ensure_peer_direct_keys(peer_id):
    """Create a unique RouterOS keypair for the dedicated direct interface."""
    peer_id = int(peer_id)

    with DB_WRITE_LOCK:
        con = db()
        try:
            row = con.execute(
                """
                SELECT direct_private_key,direct_public_key
                FROM peers WHERE id=?
                """,
                (peer_id,),
            ).fetchone()
            if not row:
                raise RuntimeError("الراوتر غير موجود")

            private_key = (
                row["direct_private_key"] or ""
            ).strip()
            public_key = (
                row["direct_public_key"] or ""
            ).strip()

            if not private_key or not public_key:
                private_key, public_key, _ = wg_keypair()
                con.execute(
                    """
                    UPDATE peers
                    SET direct_private_key=?,direct_public_key=?
                    WHERE id=?
                    """,
                    (private_key, public_key, peer_id),
                )
                con.commit()

            return private_key, public_key
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()


def _direct_router_interface_name():
    return "wg-direct"


def _direct_router_listen_port():
    return 51822

def _direct_route_table(peer_id):
    return DIRECT_ROUTE_TABLE_BASE + int(peer_id)


def _direct_router_parameters(peer, settings=None):
    settings = settings or get_settings()
    peer_id = int(peer["id"])
    interface = _direct_interface_name(peer_id)
    _, server_public = ensure_server_keys(interface)
    router_private, router_public = ensure_peer_direct_keys(
        peer_id
    )
    network = _direct_tunnel_network(peer_id)

    return {
        "peer_id": peer_id,
        "interface": interface,
        "port": _direct_listen_port(peer_id),
        "server_ip": _direct_server_ip(peer_id),
        "server_cidr": _direct_server_ip(peer_id) + "/30",
        "router_ip": _direct_router_ip(peer_id),
        "router_cidr": _direct_router_ip(peer_id) + "/30",
        "network": str(network),
        "table": _direct_route_table(peer_id),
        "server_public": server_public,
        "router_private": router_private,
        "router_public": router_public,
        "router_interface": _direct_router_interface_name(),
        "router_listen_port": _direct_router_listen_port(),
        "endpoint": settings.get("endpoint", DEFAULT_ENDPOINT),
    }


def _agent_network(settings=None):
    settings = settings or get_settings()
    return ipaddress.ip_network(
        settings.get("agent_address", DEFAULT_AGENT_ADDRESS),
        strict=False,
    )


def _agent_server_ip(settings=None):
    settings = settings or get_settings()
    return str(
        ipaddress.ip_interface(
            settings.get("agent_address", DEFAULT_AGENT_ADDRESS)
        ).ip
    )


def _next_agent_ip_from_used(used, settings=None):
    settings = settings or get_settings()
    network = _agent_network(settings)
    server_ip = ipaddress.ip_interface(
        settings.get("agent_address", DEFAULT_AGENT_ADDRESS)
    ).ip

    for host in network.hosts():
        if host == server_ip or host in used:
            continue
        used.add(host)
        return str(host) + "/32"

    raise RuntimeError(
        "لا يوجد IP فارغ داخل شبكة دخول الوكلاء %s"
        % network
    )


def ensure_agent_devices(peer_id):
    """Create one mobile and one Windows identity for a router."""
    peer_id = int(peer_id)
    created = 0

    with DB_WRITE_LOCK:
        con = db()
        try:
            peer = con.execute(
                "SELECT id,name FROM peers WHERE id=?",
                (peer_id,),
            ).fetchone()
            if not peer:
                return 0

            used = set()
            for row in con.execute(
                "SELECT tunnel_ip FROM agent_devices"
            ).fetchall():
                try:
                    used.add(
                        ipaddress.ip_interface(
                            row["tunnel_ip"]
                        ).ip
                    )
                except Exception:
                    pass

            existing = {
                row["device_type"]: row
                for row in con.execute(
                    """
                    SELECT * FROM agent_devices
                    WHERE peer_id=?
                    """,
                    (peer_id,),
                ).fetchall()
            }

            specs = [
                ("mobile", "موبايل"),
                ("windows", "Windows"),
            ]
            for device_type, label in specs:
                if device_type in existing:
                    continue

                private_key, public_key, psk = wg_keypair()
                tunnel_ip = _next_agent_ip_from_used(used)
                con.execute(
                    """
                    INSERT INTO agent_devices
                    (
                        peer_id,device_type,label,tunnel_ip,
                        private_key,public_key,preshared_key,
                        enabled,created_at
                    )
                    VALUES(?,?,?,?,?,?,?,1,?)
                    """,
                    (
                        peer_id,
                        device_type,
                        label,
                        tunnel_ip,
                        private_key,
                        public_key,
                        psk,
                        datetime.now().isoformat(
                            timespec="seconds"
                        ),
                    ),
                )
                created += 1

            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    return created


def ensure_all_agent_devices():
    con = db()
    peer_ids = [
        int(row["id"])
        for row in con.execute(
            "SELECT id FROM peers ORDER BY id"
        ).fetchall()
    ]
    con.close()

    created = 0
    for peer_id in peer_ids:
        created += ensure_agent_devices(peer_id)
    return created


def get_agent_device(peer_id, device_type):
    if device_type not in ("mobile", "windows"):
        return None

    con = db()
    device = con.execute(
        """
        SELECT ad.*, p.name AS peer_name,
               p.winbox_external, p.winbox_internal,
               p.tunnel_ip AS router_tunnel_ip
        FROM agent_devices ad
        JOIN peers p ON p.id=ad.peer_id
        WHERE ad.peer_id=? AND ad.device_type=?
        """,
        (int(peer_id), device_type),
    ).fetchone()
    con.close()
    return device




def active_direct_subscriber_map():
    """Return every active subscriber IP per router.

    Duplicate subscriber addresses are intentionally preserved. Each router
    uses a dedicated WireGuard interface and a source-policy routing table, so
    the same destination IP can safely exist behind multiple routers.
    """
    con = db()
    rows = con.execute(
        """
        SELECT pf.peer_id,pf.internal_ip,pf.name
        FROM port_forwards pf
        JOIN peers p ON p.id=pf.peer_id
        WHERE pf.enabled=1 AND p.enabled=1
        ORDER BY pf.peer_id,pf.internal_ip,pf.id
        """
    ).fetchall()
    con.close()

    owners = {}
    by_peer_sets = {}
    for row in rows:
        value = _subscriber_ipv4(row["internal_ip"])
        if not value:
            continue
        peer_id = int(row["peer_id"])
        owners.setdefault(value, set()).add(peer_id)
        by_peer_sets.setdefault(peer_id, set()).add(value)

    conflicts = {
        value: sorted(peer_ids)
        for value, peer_ids in owners.items()
        if len(peer_ids) > 1
    }

    by_peer = {}
    for peer_id, values in by_peer_sets.items():
        by_peer[peer_id] = sorted(
            values,
            key=lambda value: tuple(
                int(part) for part in value.split(".")
            ),
        )
    return by_peer, conflicts


def _direct_ips_for_peer(peer_id):
    by_peer, conflicts = active_direct_subscriber_map()
    return by_peer.get(int(peer_id), []), conflicts


def _agent_client_allowed_ips(peer_id, settings=None):
    settings = settings or get_settings()
    direct_ips, _ = _direct_ips_for_peer(peer_id)
    values = [
        _agent_server_ip(settings) + "/32",
    ]
    values.extend(DEFAULT_AGENT_CLIENT_ROUTES)
    values.extend(value + "/32" for value in direct_ips)

    cleaned = []
    seen = set()
    for value in values:
        network = str(ipaddress.ip_network(value, strict=False))
        if network in seen:
            continue
        seen.add(network)
        cleaned.append(network)
    return cleaned


def _direct_state_digest(by_peer, conflicts):
    payload = []
    for peer_id in sorted(by_peer):
        payload.append(
            "%s=%s" % (
                peer_id,
                ",".join(by_peer[peer_id]),
            )
        )
    for value in sorted(conflicts):
        payload.append(
            "conflict:%s=%s" % (
                value,
                ",".join(
                    str(item) for item in conflicts[value]
                ),
            )
        )
    return hashlib.sha256(
        "|".join(payload).encode("utf-8")
    ).hexdigest()


def agent_client_config(device):
    settings = get_settings()
    interface = settings.get(
        "agent_interface",
        DEFAULT_AGENT_INTERFACE,
    ).strip()
    _, server_public = ensure_server_keys(interface)
    allowed_ips = _agent_client_allowed_ips(
        int(device["peer_id"]),
        settings,
    )

    return """[Interface]
PrivateKey = {private_key}
Address = {address}
MTU = {mtu}

[Peer]
PublicKey = {server_public}
PresharedKey = {psk}
Endpoint = {endpoint}:{port}
AllowedIPs = {allowed_ips}
PersistentKeepalive = 25
""".format(
        private_key=device["private_key"],
        address=device["tunnel_ip"],
        mtu=settings.get("agent_mtu", "1420"),
        server_public=server_public,
        psk=device["preshared_key"],
        endpoint=settings.get("endpoint", DEFAULT_ENDPOINT),
        port=settings.get(
            "agent_port",
            str(DEFAULT_AGENT_PORT),
        ),
        allowed_ips=", ".join(allowed_ips),
    )


def generate_agent_server_config():
    settings = get_settings()
    interface = settings.get(
        "agent_interface",
        DEFAULT_AGENT_INTERFACE,
    ).strip()
    address = settings.get(
        "agent_address",
        DEFAULT_AGENT_ADDRESS,
    ).strip()
    port = int(
        settings.get(
            "agent_port",
            str(DEFAULT_AGENT_PORT),
        )
    )
    mtu = settings.get("agent_mtu", "1420")
    server_private, _ = ensure_server_keys(interface)
    config_path = WG_DIR / ("%s.conf" % interface)

    con = db()
    devices = con.execute(
        """
        SELECT ad.*, p.name AS peer_name
        FROM agent_devices ad
        JOIN peers p ON p.id=ad.peer_id
        WHERE ad.enabled=1 AND p.enabled=1
        ORDER BY ad.peer_id, ad.device_type
        """
    ).fetchall()
    con.close()

    if config_path.exists():
        current = config_path.read_text(errors="ignore")
        if (
            current.strip()
            and "# CLOUD-AGENT-ACCESS-CONFIG" not in current
        ):
            raise RuntimeError(
                "%s.conf موجود لكنه ليس تابعاً للبنل؛ "
                "لن يتم استبداله تلقائياً"
                % interface
            )

    lines = [
        "# CLOUD-AGENT-ACCESS-CONFIG",
        "# Dedicated mobile and Windows access interface",
        "[Interface]",
        "Address = %s" % address,
        "ListenPort = %s" % port,
        "PrivateKey = %s" % server_private,
        "MTU = %s" % mtu,
        "PostUp = sysctl -w net.ipv4.ip_forward=1",
        "",
    ]

    for device in devices:
        lines.extend([
            "[Peer]",
            "# CLOUD-AGENT-DEVICE:%s" % device["id"],
            "# %s - %s"
            % (device["peer_name"], device["device_type"]),
            "PublicKey = %s" % device["public_key"],
            "PresharedKey = %s"
            % device["preshared_key"],
            "AllowedIPs = %s" % device["tunnel_ip"],
            "PersistentKeepalive = 25",
            "",
        ])

    content = "\n".join(lines).rstrip() + "\n"
    old_content = (
        config_path.read_text(errors="ignore")
        if config_path.exists()
        else ""
    )
    if old_content == content:
        return config_path, False

    WG_DIR.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=interface + ".",
        suffix=".conf",
        dir=str(WG_DIR),
    )
    os.close(fd)
    temp_path = Path(temp_name)

    try:
        temp_path.write_text(content)
        os.chmod(str(temp_path), 0o600)
        _validate_wg_quick_config(temp_path, interface)
        _backup_wireguard_config(config_path)
        os.replace(str(temp_path), str(config_path))
        os.chmod(str(config_path), 0o600)
    finally:
        if temp_path.exists():
            temp_path.unlink()

    return config_path, True


def apply_agent_wireguard(force=False):
    with AGENT_WG_LOCK:
        settings = get_settings()
        interface = settings.get(
            "agent_interface",
            DEFAULT_AGENT_INTERFACE,
        ).strip()
        _, changed = generate_agent_server_config()

        active = subprocess.run(
            ["wg", "show", interface],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        ).returncode == 0

        if force or changed or not active:
            run(
                [
                    "systemctl",
                    "enable",
                    "wg-quick@%s" % interface,
                ],
                check=False,
            )
            proc = subprocess.run(
                [
                    "systemctl",
                    "restart",
                    "wg-quick@%s" % interface,
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            if proc.returncode != 0:
                raise RuntimeError(
                    "فشل تشغيل WireGuard الخاص بالوكلاء: %s"
                    % proc.stderr.decode(
                        errors="ignore"
                    ).strip()
                )

        # Direct router interfaces are separate from the agent interface.
        # They are refreshed here so policy routes always point to live links.
        apply_all_direct_router_wireguard()
        regenerate_nat_rules()
        return True


def agent_wireguard_stats():
    settings = get_settings()
    interface = settings.get(
        "agent_interface",
        DEFAULT_AGENT_INTERFACE,
    ).strip()
    stats = {}

    try:
        output = run(
            ["wg", "show", interface, "dump"],
            check=False,
        )
        lines = output.splitlines()
        for line in lines[1:]:
            cols = line.split("\t")
            if len(cols) < 8:
                continue
            latest = int(cols[4] or 0)
            stats[cols[0]] = {
                "latest_handshake": latest,
                "handshake_text": (
                    datetime.fromtimestamp(latest).strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                    if latest
                    else "-"
                ),
                "online": (
                    latest > 0
                    and (
                        datetime.now().timestamp() - latest
                    ) < 180
                ),
            }
    except Exception:
        pass

    return stats



def regenerate_nat_rules():
    settings = get_settings()
    interface = settings["interface"].strip()
    agent_interface = settings.get(
        "agent_interface",
        DEFAULT_AGENT_INTERFACE,
    ).strip()

    con = db()
    peers = con.execute("""
        SELECT *
        FROM peers
        WHERE enabled=1
        ORDER BY id
    """).fetchall()

    forwards = con.execute("""
        SELECT pf.*, p.tunnel_ip, p.name AS peer_name
        FROM port_forwards pf
        JOIN peers p ON p.id=pf.peer_id
        WHERE pf.enabled=1 AND p.enabled=1
        ORDER BY pf.id
    """).fetchall()

    agent_devices = con.execute("""
        SELECT
            ad.id AS device_id,
            ad.peer_id,ad.tunnel_ip AS device_ip,
            ad.device_type,p.tunnel_ip AS peer_tunnel_ip,
            p.winbox_internal,p.winbox_external
        FROM agent_devices ad
        JOIN peers p ON p.id=ad.peer_id
        WHERE ad.enabled=1 AND p.enabled=1
        ORDER BY ad.peer_id,ad.id
    """).fetchall()
    con.close()

    peer_by_id = {
        int(peer["id"]): peer
        for peer in peers
    }
    devices_by_peer = {}
    for device in agent_devices:
        devices_by_peer.setdefault(
            int(device["peer_id"]), []
        ).append(device)

    direct_ips_by_peer, direct_conflicts = (
        active_direct_subscriber_map()
    )
    agent_network = str(_agent_network(settings))

    def ensure_chain(table, chain):
        command = ["iptables"]
        if table:
            command += ["-t", table]
        subprocess.run(
            command + ["-N", chain],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        run(command + ["-F", chain])

    def reset_jump(table, parent, chain, position="1"):
        command = ["iptables"]
        if table:
            command += ["-t", table]
        while subprocess.run(
            command + ["-C", parent, "-j", chain],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        ).returncode == 0:
            subprocess.run(
                command + ["-D", parent, "-j", chain],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
        run(command + ["-I", parent, position, "-j", chain])

    ensure_chain("nat", "CLOUD_WG_DNAT")
    ensure_chain("nat", "CLOUD_WG_SNAT")
    ensure_chain(None, "CLOUD_WG_FORWARD")
    ensure_chain(None, "CLOUD_AGENT_ACCESS")
    ensure_chain(None, "CLOUD_DIRECT_INPUT")
    reset_jump("nat", "PREROUTING", "CLOUD_WG_DNAT")
    reset_jump("nat", "POSTROUTING", "CLOUD_WG_SNAT")
    reset_jump(None, "FORWARD", "CLOUD_WG_FORWARD")
    reset_jump(None, "INPUT", "CLOUD_DIRECT_INPUT")

    script = [
        "#!/usr/bin/env bash",
        "set -e",
        "sysctl -w net.ipv4.ip_forward=1 >/dev/null",
        "iptables -t nat -N CLOUD_WG_DNAT 2>/dev/null || true",
        "iptables -t nat -F CLOUD_WG_DNAT",
        "while iptables -t nat -C PREROUTING -j CLOUD_WG_DNAT 2>/dev/null; do iptables -t nat -D PREROUTING -j CLOUD_WG_DNAT; done",
        "iptables -t nat -I PREROUTING 1 -j CLOUD_WG_DNAT",
        "iptables -t nat -N CLOUD_WG_SNAT 2>/dev/null || true",
        "iptables -t nat -F CLOUD_WG_SNAT",
        "while iptables -t nat -C POSTROUTING -j CLOUD_WG_SNAT 2>/dev/null; do iptables -t nat -D POSTROUTING -j CLOUD_WG_SNAT; done",
        "iptables -t nat -I POSTROUTING 1 -j CLOUD_WG_SNAT",
        "iptables -N CLOUD_WG_FORWARD 2>/dev/null || true",
        "iptables -F CLOUD_WG_FORWARD",
        "while iptables -C FORWARD -j CLOUD_WG_FORWARD 2>/dev/null; do iptables -D FORWARD -j CLOUD_WG_FORWARD; done",
        "iptables -I FORWARD 1 -j CLOUD_WG_FORWARD",
        "iptables -N CLOUD_AGENT_ACCESS 2>/dev/null || true",
        "iptables -F CLOUD_AGENT_ACCESS",
        "iptables -N CLOUD_DIRECT_INPUT 2>/dev/null || true",
        "iptables -F CLOUD_DIRECT_INPUT",
        "while iptables -C INPUT -j CLOUD_DIRECT_INPUT 2>/dev/null; do iptables -D INPUT -j CLOUD_DIRECT_INPUT; done",
        "iptables -I INPUT 1 -j CLOUD_DIRECT_INPUT",
    ]

    def apply_and_save(rule, shell_line):
        run(rule)
        script.append(shell_line)

    apply_and_save(
        [
            "iptables", "-A", "CLOUD_WG_FORWARD",
            "-i", agent_interface,
            "-j", "CLOUD_AGENT_ACCESS",
        ],
        "iptables -A CLOUD_WG_FORWARD -i %s -j CLOUD_AGENT_ACCESS"
        % agent_interface,
    )

    apply_and_save(
        [
            "iptables", "-A", "CLOUD_AGENT_ACCESS",
            "-m", "conntrack",
            "--ctstate", "ESTABLISHED,RELATED",
            "-j", "ACCEPT",
        ],
        "iptables -A CLOUD_AGENT_ACCESS -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT",
    )

    # Remove every old panel source rule before rebuilding per-router tables.
    for peer in peers:
        peer_id = int(peer["id"])
        params = _direct_router_parameters(peer, settings)
        table = str(params["table"])
        while subprocess.run(
            ["ip", "-4", "rule", "del", "table", table],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        ).returncode == 0:
            pass
        subprocess.run(
            ["ip", "-4", "route", "flush", "table", table],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        script.extend([
            "while ip -4 rule del table %s 2>/dev/null; do :; done"
            % table,
            "ip -4 route flush table %s 2>/dev/null || true"
            % table,
        ])

    # Dedicated UDP endpoint, policy table, SNAT, and firewall per router.
    for peer in peers:
        peer_id = int(peer["id"])
        params = _direct_router_parameters(peer, settings)
        direct_interface = params["interface"]
        direct_ip = params["server_ip"]
        table = str(params["table"])

        apply_and_save(
            [
                "iptables", "-A", "CLOUD_DIRECT_INPUT",
                "-p", "udp",
                "--dport", str(params["port"]),
                "-j", "ACCEPT",
            ],
            "iptables -A CLOUD_DIRECT_INPUT -p udp --dport %s -j ACCEPT"
            % params["port"],
        )

        # Router management destination stays on the shared main interface.
        router_ip = str(
            ipaddress.ip_interface(peer["tunnel_ip"]).ip
        )
        run([
            "ip", "-4", "route", "replace",
            router_ip + "/32",
            "dev", interface,
            "table", table,
        ])
        script.append(
            "ip -4 route replace %s/32 dev %s table %s"
            % (router_ip, interface, table)
        )

        for subscriber_ip in direct_ips_by_peer.get(
            peer_id, []
        ):
            run([
                "ip", "-4", "route", "replace",
                subscriber_ip + "/32",
                "dev", direct_interface,
                "table", table,
            ])
            script.append(
                "ip -4 route replace %s/32 dev %s table %s"
                % (subscriber_ip, direct_interface, table)
            )

        # Stop policy lookup from falling through to another router.
        run([
            "ip", "-4", "route", "replace",
            "unreachable", "default",
            "metric", "42760",
            "table", table,
        ])
        script.append(
            "ip -4 route replace unreachable default metric 42760 table %s"
            % table
        )

        for device in devices_by_peer.get(peer_id, []):
            source_ip = str(
                ipaddress.ip_interface(device["device_ip"]).ip
            )
            priority = (
                DIRECT_RULE_PRIORITY_BASE
                + int(device["device_id"])
            )
            while subprocess.run(
                [
                    "ip", "-4", "rule", "del",
                    "priority", str(priority),
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            ).returncode == 0:
                pass
            run([
                "ip", "-4", "rule", "add",
                "priority", str(priority),
                "from", source_ip + "/32",
                "lookup", table,
            ])
            script.append(
                "ip -4 rule add priority %s from %s/32 lookup %s"
                % (priority, source_ip, table)
            )

            # WinBox/API path to this router over the management interface.
            internal = str(
                int(device["winbox_internal"] or 8291)
            )
            label = "Agent %s peer %s WinBox" % (
                source_ip, peer_id
            )
            apply_and_save(
                [
                    "iptables", "-A", "CLOUD_AGENT_ACCESS",
                    "-s", source_ip,
                    "-d", router_ip,
                    "-o", interface,
                    "-p", "tcp",
                    "--dport", internal,
                    "-m", "comment", "--comment", label,
                    "-j", "ACCEPT",
                ],
                "iptables -A CLOUD_AGENT_ACCESS -s %s -d %s -o %s -p tcp --dport %s -m comment --comment %s -j ACCEPT"
                % (
                    source_ip, router_ip, interface,
                    internal, repr(label),
                ),
            )

            for subscriber_ip in direct_ips_by_peer.get(
                peer_id, []
            ):
                label = "Agent %s peer %s direct %s" % (
                    source_ip, peer_id, subscriber_ip
                )
                apply_and_save(
                    [
                        "iptables", "-A", "CLOUD_AGENT_ACCESS",
                        "-s", source_ip,
                        "-d", subscriber_ip,
                        "-o", direct_interface,
                        "-m", "comment", "--comment", label,
                        "-j", "ACCEPT",
                    ],
                    "iptables -A CLOUD_AGENT_ACCESS -s %s -d %s -o %s -m comment --comment %s -j ACCEPT"
                    % (
                        source_ip, subscriber_ip,
                        direct_interface, repr(label),
                    ),
                )

            apply_and_save(
                [
                    "iptables", "-t", "nat", "-A",
                    "CLOUD_WG_SNAT",
                    "-s", source_ip,
                    "-o", direct_interface,
                    "-j", "SNAT",
                    "--to-source", direct_ip,
                ],
                "iptables -t nat -A CLOUD_WG_SNAT -s %s -o %s -j SNAT --to-source %s"
                % (source_ip, direct_interface, direct_ip),
            )

        apply_and_save(
            [
                "iptables", "-A", "CLOUD_WG_FORWARD",
                "-i", direct_interface,
                "-o", agent_interface,
                "-d", agent_network,
                "-m", "conntrack",
                "--ctstate", "ESTABLISHED,RELATED",
                "-j", "ACCEPT",
            ],
            "iptables -A CLOUD_WG_FORWARD -i %s -o %s -d %s -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT"
            % (direct_interface, agent_interface, agent_network),
        )

    # Replies from the shared management tunnel to agent devices.
    apply_and_save(
        [
            "iptables", "-A", "CLOUD_WG_FORWARD",
            "-i", interface,
            "-o", agent_interface,
            "-d", agent_network,
            "-m", "conntrack",
            "--ctstate", "ESTABLISHED,RELATED",
            "-j", "ACCEPT",
        ],
        "iptables -A CLOUD_WG_FORWARD -i %s -o %s -d %s -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT"
        % (interface, agent_interface, agent_network),
    )

    apply_and_save(
        [
            "iptables", "-A", "CLOUD_AGENT_ACCESS",
            "-j", "DROP",
        ],
        "iptables -A CLOUD_AGENT_ACCESS -j DROP",
    )

    # Existing public WinBox forwarding through the management tunnel.
    for peer in peers:
        if int(peer["winbox_external"] or 0) <= 0:
            continue
        peer_ip = str(
            ipaddress.ip_interface(peer["tunnel_ip"]).ip
        )
        internal = str(int(peer["winbox_internal"] or 8291))
        external = str(int(peer["winbox_external"]))
        label = "Cloud WinBox peer %s" % peer["id"]

        apply_and_save(
            [
                "iptables", "-t", "nat", "-A",
                "CLOUD_WG_DNAT",
                "-p", "tcp", "--dport", external,
                "-m", "comment", "--comment", label,
                "-j", "DNAT",
                "--to-destination", "%s:%s" % (peer_ip, internal),
            ],
            "iptables -t nat -A CLOUD_WG_DNAT -p tcp --dport %s -m comment --comment %s -j DNAT --to-destination %s:%s"
            % (external, repr(label), peer_ip, internal),
        )
        apply_and_save(
            [
                "iptables", "-t", "nat", "-A",
                "CLOUD_WG_SNAT",
                "-o", interface, "-d", peer_ip,
                "-p", "tcp", "--dport", internal,
                "-j", "MASQUERADE",
            ],
            "iptables -t nat -A CLOUD_WG_SNAT -o %s -d %s -p tcp --dport %s -j MASQUERADE"
            % (interface, peer_ip, internal),
        )
        apply_and_save(
            [
                "iptables", "-A", "CLOUD_WG_FORWARD",
                "-o", interface, "-d", peer_ip,
                "-p", "tcp", "--dport", internal,
                "-m", "conntrack",
                "--ctstate", "NEW,ESTABLISHED,RELATED",
                "-j", "ACCEPT",
            ],
            "iptables -A CLOUD_WG_FORWARD -o %s -d %s -p tcp --dport %s -m conntrack --ctstate NEW,ESTABLISHED,RELATED -j ACCEPT"
            % (interface, peer_ip, internal),
        )
        apply_and_save(
            [
                "iptables", "-A", "CLOUD_WG_FORWARD",
                "-i", interface, "-s", peer_ip,
                "-p", "tcp", "--sport", internal,
                "-m", "conntrack",
                "--ctstate", "ESTABLISHED,RELATED",
                "-j", "ACCEPT",
            ],
            "iptables -A CLOUD_WG_FORWARD -i %s -s %s -p tcp --sport %s -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT"
            % (interface, peer_ip, internal),
        )

    # Existing public service forwards remain on the management tunnel.
    for item in forwards:
        peer_ip = str(
            ipaddress.ip_interface(item["tunnel_ip"]).ip
        )
        external = str(int(item["external_port"]))

        for protocol in _forward_protocols(item["protocol"]):
            label = "CloudPF %s %s" % (item["id"], protocol)
            apply_and_save(
                [
                    "iptables", "-t", "nat", "-A",
                    "CLOUD_WG_DNAT",
                    "-p", protocol, "--dport", external,
                    "-m", "comment", "--comment", label,
                    "-j", "DNAT",
                    "--to-destination", "%s:%s" % (peer_ip, external),
                ],
                "iptables -t nat -A CLOUD_WG_DNAT -p %s --dport %s -m comment --comment %s -j DNAT --to-destination %s:%s"
                % (
                    protocol, external, repr(label),
                    peer_ip, external,
                ),
            )
            apply_and_save(
                [
                    "iptables", "-t", "nat", "-A",
                    "CLOUD_WG_SNAT",
                    "-o", interface, "-d", peer_ip,
                    "-p", protocol, "--dport", external,
                    "-j", "MASQUERADE",
                ],
                "iptables -t nat -A CLOUD_WG_SNAT -o %s -d %s -p %s --dport %s -j MASQUERADE"
                % (interface, peer_ip, protocol, external),
            )
            apply_and_save(
                [
                    "iptables", "-A", "CLOUD_WG_FORWARD",
                    "-o", interface, "-d", peer_ip,
                    "-p", protocol, "--dport", external,
                    "-m", "conntrack",
                    "--ctstate", "NEW,ESTABLISHED,RELATED",
                    "-j", "ACCEPT",
                ],
                "iptables -A CLOUD_WG_FORWARD -o %s -d %s -p %s --dport %s -m conntrack --ctstate NEW,ESTABLISHED,RELATED -j ACCEPT"
                % (interface, peer_ip, protocol, external),
            )
            apply_and_save(
                [
                    "iptables", "-A", "CLOUD_WG_FORWARD",
                    "-i", interface, "-s", peer_ip,
                    "-p", protocol, "--sport", external,
                    "-m", "conntrack",
                    "--ctstate", "ESTABLISHED,RELATED",
                    "-j", "ACCEPT",
                ],
                "iptables -A CLOUD_WG_FORWARD -i %s -s %s -p %s --sport %s -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT"
                % (interface, peer_ip, protocol, external),
            )

    nat_dir = Path("/etc/cloud-wireguard")
    nat_dir.mkdir(parents=True, exist_ok=True)
    nat_script = nat_dir / "nat.sh"
    temp_script = nat_dir / "nat.sh.tmp"
    temp_script.write_text("\n".join(script) + "\n")
    os.chmod(str(temp_script), 0o755)
    os.replace(str(temp_script), str(nat_script))
    return True


def _parse_peer_blocks_from_text(text):
    """Return raw Peer blocks with parsed identity fields."""
    blocks = []
    lines = text.splitlines()
    index = 0

    while index < len(lines):
        if lines[index].strip() != "[Peer]":
            index += 1
            continue

        start = index
        index += 1
        while index < len(lines) and lines[index].strip() not in ("[Peer]", "[Interface]"):
            index += 1

        raw_lines = lines[start:index]
        block = {
            "raw_lines": raw_lines,
            "public_key": "",
            "allowed_ips": [],
            "managed": False,
            "managed_id": "",
        }

        for raw in raw_lines:
            line = raw.strip()
            if line.startswith("# CLOUD-MANAGED-ID:"):
                block["managed"] = True
                block["managed_id"] = line.split(":", 1)[1].strip()
            elif line.startswith("PublicKey") and "=" in line:
                block["public_key"] = line.split("=", 1)[1].strip()
            elif line.startswith("AllowedIPs") and "=" in line:
                block["allowed_ips"] = [
                    item.strip()
                    for item in line.split("=", 1)[1].split(",")
                    if item.strip()
                ]

        blocks.append(block)

    return blocks


def _read_existing_peer_blocks(config_path):
    if not config_path.exists():
        return []
    return _parse_peer_blocks_from_text(config_path.read_text(errors="ignore"))



def _peer_block_for_db_row(peer, direct_ips_by_peer=None):
    # The main management tunnel carries only the router tunnel/LAN routes.
    # Subscriber IPs live on per-router interfaces so overlapping customer
    # addresses cannot be claimed by the first peer.
    allowed = [peer["tunnel_ip"]]
    allowed += clean_networks(peer["lan_ips"] or "")

    unique_allowed = []
    seen_allowed = set()
    for value in allowed:
        network = str(ipaddress.ip_network(value, strict=False))
        if network in seen_allowed:
            continue
        seen_allowed.add(network)
        unique_allowed.append(network)

    return [
        "[Peer]",
        "# CLOUD-MANAGED-ID:%s" % peer["id"],
        "# %s" % peer["name"],
        "PublicKey = %s" % peer["public_key"],
        "PresharedKey = %s" % peer["preshared_key"],
        "AllowedIPs = %s" % ", ".join(unique_allowed),
        "PersistentKeepalive = 25",
        "",
    ]


def _peer_count_from_text(text):
    return sum(1 for line in text.splitlines() if line.strip() == "[Peer]")


def _backup_wireguard_config(config_path):
    if not config_path.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = config_path.with_name(config_path.name + ".panel-backup-" + stamp)
    shutil.copy2(str(config_path), str(backup))
    os.chmod(str(backup), 0o600)
    return backup


def _validate_wg_quick_config(path, interface):
    # Ubuntu 18.04 wg-quick requires the filename itself to be a valid
    # interface name followed by .conf.
    validate_dir = Path(tempfile.mkdtemp(prefix="cloud-wg-validate-"))
    validate_path = validate_dir / ("%s.conf" % interface)
    try:
        shutil.copy2(str(path), str(validate_path))
        os.chmod(str(validate_path), 0o600)
        proc = subprocess.run(
            ["wg-quick", "strip", str(validate_path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        if proc.returncode != 0:
            raise RuntimeError(
                "ملف WireGuard الجديد غير صالح: %s"
                % proc.stderr.decode(errors="ignore").strip()
            )
    finally:
        shutil.rmtree(str(validate_dir), ignore_errors=True)


def _find_recovery_peer_blocks(interface):
    """Find peers from newest WireGuard backup when active config has none."""
    candidates = []
    patterns = [
        "%s.conf.bak*" % interface,
        "%s.conf.panel-backup-*" % interface,
        "%s.conf.backup*" % interface,
    ]
    for pattern in patterns:
        candidates.extend(WG_DIR.glob(pattern))

    candidates = sorted(
        {path for path in candidates if path.is_file()},
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )

    for path in candidates:
        try:
            blocks = _read_existing_peer_blocks(path)
        except Exception:
            continue
        if blocks:
            return blocks, path
    return [], None

def ensure_server_keys(interface):
    WG_DIR.mkdir(parents=True, exist_ok=True)
    private_file = WG_DIR / ("%s.private" % interface)
    public_file = WG_DIR / ("%s.public" % interface)
    config_file = WG_DIR / ("%s.conf" % interface)

    config_private = ""
    if config_file.exists():
        in_interface = False
        for raw_line in config_file.read_text().splitlines():
            line = raw_line.strip()
            if line == "[Interface]":
                in_interface = True
                continue
            if line.startswith("[") and line != "[Interface]":
                in_interface = False
            if in_interface and line.lower().startswith("privatekey") and "=" in line:
                config_private = line.split("=", 1)[1].strip()
                break

    if config_private:
        private_key = config_private
        public_key = run(["wg", "pubkey"], input_text=private_key)
        private_file.write_text(private_key + "\n")
        public_file.write_text(public_key + "\n")
        os.chmod(str(private_file), 0o600)
        return private_key, public_key

    if private_file.exists():
        private_key = private_file.read_text().strip()
        public_key = run(["wg", "pubkey"], input_text=private_key)
        public_file.write_text(public_key + "\n")
        return private_key, public_key

    private_key, public_key, _ = wg_keypair()
    private_file.write_text(private_key + "\n")
    public_file.write_text(public_key + "\n")
    os.chmod(str(private_file), 0o600)
    return private_key, public_key


def generate_server_config():
    settings = get_settings()
    interface = settings["interface"].strip()
    server_private, _ = ensure_server_keys(interface)
    config_path = WG_DIR / ("%s.conf" % interface)

    con = db()
    peers = con.execute(
        "SELECT * FROM peers WHERE enabled=1 ORDER BY id"
    ).fetchall()
    con.close()
    direct_ips_by_peer, direct_conflicts = (
        active_direct_subscriber_map()
    )

    existing_blocks = _read_existing_peer_blocks(config_path)

    # Safety recovery: if the active file was accidentally emptied and the DB
    # also has no peers, recover candidates from the newest local backup.
    recovered_from = None
    if not existing_blocks and not peers:
        recovery_blocks, recovery_path = _find_recovery_peer_blocks(interface)
        if recovery_blocks:
            existing_blocks = recovery_blocks
            recovered_from = recovery_path

    post_up = [
        "sysctl -w net.ipv4.ip_forward=1",
        "iptables -A FORWARD -i %i -j ACCEPT",
        "iptables -A FORWARD -o %i -j ACCEPT",
    ]
    post_down = [
        "iptables -D FORWARD -i %i -j ACCEPT",
        "iptables -D FORWARD -o %i -j ACCEPT",
    ]

    out_interface = settings.get("out_interface", "").strip()
    if out_interface:
        post_up.append(
            "iptables -t nat -A POSTROUTING -o %s -j MASQUERADE"
            % out_interface
        )
        post_down.append(
            "iptables -t nat -D POSTROUTING -o %s -j MASQUERADE"
            % out_interface
        )

    lines = [
        "[Interface]",
        "Address = %s" % settings["address"],
        "ListenPort = %s" % settings["port"],
        "PrivateKey = %s" % server_private,
        "MTU = %s" % settings.get("mtu", "1420"),
        "PostUp = %s" % "; ".join(post_up),
        "PostDown = %s" % "; ".join(post_down),
        "",
    ]

    db_public_keys = {
        (peer["public_key"] or "").strip()
        for peer in peers
        if (peer["public_key"] or "").strip()
    }
    db_ids = {str(peer["id"]) for peer in peers}

    # Preserve every unmanaged peer that is not represented in the database.
    # Managed peers removed from the DB are intentionally omitted.
    for block in existing_blocks:
        public_key = block.get("public_key", "")
        managed_id = block.get("managed_id", "")
        if public_key in db_public_keys:
            continue
        if block.get("managed") and managed_id not in db_ids:
            continue
        lines.extend(block["raw_lines"])
        lines.append("")

    # Add/update all DB-managed peers.
    for peer in peers:
        lines.extend(
            _peer_block_for_db_row(
                peer, direct_ips_by_peer
            )
        )

    content = "\n".join(lines).rstrip() + "\n"
    old_content = config_path.read_text(errors="ignore") if config_path.exists() else ""

    # Refuse a silent destructive write. The only exception is when all old
    # peers were explicitly managed and removed from the database.
    old_blocks = _parse_peer_blocks_from_text(old_content)
    old_unmanaged = [block for block in old_blocks if not block.get("managed")]
    new_count = _peer_count_from_text(content)
    if old_unmanaged and new_count == 0:
        raise RuntimeError(
            "تم إيقاف الحفظ لأن الملف الجديد كان سيحذف Peers موجودين"
        )

    WG_DIR.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=interface + ".",
        suffix=".conf",
        dir=str(WG_DIR)
    )
    os.close(fd)
    temp_path = Path(temp_name)

    try:
        temp_path.write_text(content)
        os.chmod(str(temp_path), 0o600)
        _validate_wg_quick_config(temp_path, interface)
        _backup_wireguard_config(config_path)
        os.replace(str(temp_path), str(config_path))
        os.chmod(str(config_path), 0o600)
    finally:
        if temp_path.exists():
            temp_path.unlink()

    if recovered_from:
        debug_path = APP_DIR / "sync-debug.log"
        with debug_path.open("a") as handle:
            handle.write(
                "%s recovered peer blocks from %s\n"
                % (
                    datetime.now().isoformat(timespec="seconds"),
                    recovered_from,
                )
            )

    return config_path




def _parse_wg_quick_sections(text):
    result = {"Interface": [], "Peer": []}
    section = ""
    current = None
    for raw_line in (text or "").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or line.startswith(";"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            current = {}
            if section == "Interface":
                result["Interface"].append(current)
            elif section == "Peer":
                result["Peer"].append(current)
            else:
                current = None
            continue
        if current is not None and "=" in line:
            key, value = line.split("=", 1)
            current[key.strip().lower()] = value.strip()
    return result


def _direct_existing_config_matches(peer, params, content):
    parsed = _parse_wg_quick_sections(content)
    interfaces = parsed.get("Interface") or []
    peers = parsed.get("Peer") or []
    if len(interfaces) != 1 or not peers:
        return False, "تركيب الملف غير واضح"

    interface = interfaces[0]
    address_values = [
        value.strip()
        for value in interface.get("address", "").split(",")
        if value.strip()
    ]
    address_ok = False
    for value in address_values:
        try:
            candidate = ipaddress.ip_interface(value)
            if (
                str(candidate.ip) == params["server_ip"]
                and candidate.network == ipaddress.ip_network(params["network"])
            ):
                address_ok = True
                break
        except Exception:
            continue
    if not address_ok:
        return False, "عنوان النفق الموجود لا يطابق الراوتر"

    try:
        listen_port = int(interface.get("listenport", "0") or 0)
    except Exception:
        listen_port = 0
    if listen_port and listen_port != int(params["port"]):
        return False, "ListenPort الموجود لا يطابق المنفذ المخصص"

    expected_public = (params.get("router_public") or "").strip()
    expected_psk = (peer["preshared_key"] or "").strip()
    matching_peer = None
    for item in peers:
        if (item.get("publickey") or "").strip() == expected_public:
            matching_peer = item
            break
    if not matching_peer:
        return False, "PublicKey جهة MikroTik لا يطابق بيانات الراوتر"

    current_psk = (matching_peer.get("presharedkey") or "").strip()
    if expected_psk and current_psk and current_psk != expected_psk:
        return False, "PresharedKey الموجود لا يطابق الراوتر"

    if not (interface.get("privatekey") or "").strip():
        return False, "PrivateKey جهة Ubuntu غير موجود"

    return True, "مطابق لبيانات الراوتر"


def _set_direct_config_state(peer_id, state, note="", adopted=False):
    try:
        con = db()
        if adopted:
            con.execute(
                """
                UPDATE peers SET direct_config_state=?,direct_config_note=?,
                    direct_config_adopted_at=? WHERE id=?
                """,
                (
                    state,
                    note[:500],
                    datetime.now().isoformat(timespec="seconds"),
                    int(peer_id),
                ),
            )
        else:
            con.execute(
                """
                UPDATE peers SET direct_config_state=?,direct_config_note=?
                WHERE id=?
                """,
                (state, note[:500], int(peer_id)),
            )
        con.commit()
        con.close()
    except Exception:
        pass



def generate_direct_router_config(peer):
    settings = get_settings()
    params = _direct_router_parameters(peer, settings)
    interface = params["interface"]
    server_private, _ = ensure_server_keys(interface)
    subscriber_ips, _ = _direct_ips_for_peer(peer["id"])
    config_path = WG_DIR / ("%s.conf" % interface)

    lines = [
        "# CLOUD-DIRECT-ROUTER:%s" % peer["id"],
        "# Dedicated overlapping-subscriber tunnel for %s" % peer["name"],
        "[Interface]",
        "Address = %s" % params["server_cidr"],
        "ListenPort = %s" % params["port"],
        "PrivateKey = %s" % server_private,
        "MTU = %s" % settings.get("mtu", "1420"),
        "Table = off",
        "",
        "[Peer]",
        "# Router %s dedicated direct interface" % peer["name"],
        "PublicKey = %s" % params["router_public"],
        "PresharedKey = %s" % peer["preshared_key"],
    ]
    allowed_ips = [params["router_ip"] + "/32"]
    allowed_ips.extend(
        value + "/32" for value in subscriber_ips
    )
    lines.append(
        "AllowedIPs = %s" % ", ".join(allowed_ips)
    )
    lines.extend([
        "PersistentKeepalive = 25",
        "",
    ])

    content = "\n".join(lines).rstrip() + "\n"
    old_content = (
        config_path.read_text(errors="ignore")
        if config_path.exists() else ""
    )
    if old_content == content:
        _set_direct_config_state(
            peer["id"],
            "managed",
            "الملف مُدار من البنل",
        )
        return config_path, False, params

    adopted_existing = False
    if (
        old_content.strip()
        and "# CLOUD-DIRECT-ROUTER:" not in old_content
    ):
        matches, reason = _direct_existing_config_matches(
            peer, params, old_content
        )
        if not matches:
            _set_direct_config_state(
                peer["id"], "conflict", reason
            )
            raise RuntimeError(
                "%s.conf موجود لكنه غير مطابق: %s"
                % (interface, reason)
            )
        adopted_existing = True

    WG_DIR.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=interface + ".",
        suffix=".conf",
        dir=str(WG_DIR),
    )
    os.close(fd)
    temp_path = Path(temp_name)
    try:
        temp_path.write_text(content)
        os.chmod(str(temp_path), 0o600)
        _validate_wg_quick_config(temp_path, interface)
        _backup_wireguard_config(config_path)
        os.replace(str(temp_path), str(config_path))
        os.chmod(str(config_path), 0o600)
    finally:
        if temp_path.exists():
            temp_path.unlink()

    if adopted_existing:
        _set_direct_config_state(
            peer["id"],
            "adopted",
            "تم استيراد الملف الموجود وربطه بالبـنل",
            adopted=True,
        )
    else:
        _set_direct_config_state(
            peer["id"],
            "managed",
            "الملف مُدار من البنل",
        )

    return config_path, True, params


def apply_direct_router_wireguard(peer, force=False):
    config_path, changed, params = generate_direct_router_config(peer)
    interface = params["interface"]

    active = subprocess.run(
        ["wg", "show", interface],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ).returncode == 0

    if not active:
        run(
            ["systemctl", "enable", "wg-quick@%s" % interface],
            check=False,
        )
        proc = subprocess.run(
            ["systemctl", "restart", "wg-quick@%s" % interface],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if proc.returncode != 0:
            raise RuntimeError(
                "فشل تشغيل النفق المستقل %s: %s"
                % (
                    interface,
                    proc.stderr.decode(errors="ignore").strip(),
                )
            )
    elif force or changed:
        stripped = subprocess.run(
            ["wg-quick", "strip", str(config_path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if stripped.returncode != 0:
            raise RuntimeError(
                "تعذر تجهيز %s: %s"
                % (
                    interface,
                    stripped.stderr.decode(errors="ignore").strip(),
                )
            )

        fd, temp_name = tempfile.mkstemp(
            prefix="cloud-direct-sync-",
            suffix=".conf",
        )
        os.close(fd)
        temp_path = Path(temp_name)
        try:
            temp_path.write_bytes(stripped.stdout)
            proc = subprocess.run(
                ["wg", "syncconf", interface, str(temp_path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            if proc.returncode != 0:
                raise RuntimeError(
                    "فشل تحديث %s: %s"
                    % (
                        interface,
                        proc.stderr.decode(errors="ignore").strip(),
                    )
                )
        finally:
            if temp_path.exists():
                temp_path.unlink()

    run([
        "ip", "-4", "address", "replace",
        params["server_cidr"],
        "dev", interface,
    ])
    run([
        "ip", "link", "set",
        interface, "up",
    ])

    return params


def cleanup_stale_direct_router_interfaces(enabled_peer_ids):
    enabled_names = {
        _direct_interface_name(peer_id)
        for peer_id in enabled_peer_ids
    }
    if not WG_DIR.exists():
        return

    for config_path in WG_DIR.glob("wg-r*.conf"):
        try:
            content = config_path.read_text(errors="ignore")
        except Exception:
            continue
        if "# CLOUD-DIRECT-ROUTER:" not in content:
            continue
        interface = config_path.stem
        if interface in enabled_names:
            continue

        subprocess.run(
            ["systemctl", "disable", "--now",
             "wg-quick@%s" % interface],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        match = re.search(
            r"# CLOUD-DIRECT-ROUTER:(\d+)",
            content,
        )
        if match:
            table = str(
                _direct_route_table(int(match.group(1)))
            )
            while subprocess.run(
                ["ip", "-4", "rule", "del", "table", table],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            ).returncode == 0:
                pass
            subprocess.run(
                ["ip", "-4", "route", "flush", "table", table],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )

        config_path.unlink(missing_ok=True)


def apply_all_direct_router_wireguard(force=False):
    with DIRECT_WG_LOCK:
        con = db()
        peers = con.execute(
            """
            SELECT * FROM peers
            WHERE enabled=1
            ORDER BY id
            """
        ).fetchall()
        con.close()

        params_by_peer = {}
        for peer in peers:
            params_by_peer[int(peer["id"])] = (
                apply_direct_router_wireguard(peer, force=force)
            )

        cleanup_stale_direct_router_interfaces(
            [int(peer["id"]) for peer in peers]
        )
        return params_by_peer


def _sync_main_management_config():
    settings = get_settings()
    interface = settings["interface"].strip()
    config_path = generate_server_config()

    active = subprocess.run(
        ["wg", "show", interface],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ).returncode == 0
    if not active:
        apply_wireguard()
        return

    stripped = subprocess.run(
        ["wg-quick", "strip", str(config_path)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if stripped.returncode != 0:
        raise RuntimeError(
            "تعذر تجهيز نفق الإدارة: %s"
            % stripped.stderr.decode(errors="ignore").strip()
        )

    fd, temp_name = tempfile.mkstemp(
        prefix="cloud-main-sync-",
        suffix=".conf",
    )
    os.close(fd)
    temp_path = Path(temp_name)
    try:
        temp_path.write_bytes(stripped.stdout)
        proc = subprocess.run(
            ["wg", "syncconf", interface, str(temp_path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if proc.returncode != 0:
            raise RuntimeError(
                "فشل تنظيف مسارات المشتركين من النفق الرئيسي: %s"
                % proc.stderr.decode(errors="ignore").strip()
            )
    finally:
        if temp_path.exists():
            temp_path.unlink()




def ensure_direct_routing_sysctls(peer_ids, settings=None):
    """Persist policy-routing sysctls and apply them to live interfaces."""
    settings = settings or get_settings()
    interfaces = [
        settings.get(
            "agent_interface",
            DEFAULT_AGENT_INTERFACE,
        ).strip()
    ]
    interfaces.extend(
        _direct_interface_name(peer_id)
        for peer_id in peer_ids
    )

    lines = [
        "net.ipv4.ip_forward=1",
        "net.ipv4.conf.all.rp_filter=0",
        "net.ipv4.conf.default.rp_filter=0",
    ]
    for interface in interfaces:
        if interface:
            lines.append(
                "net.ipv4.conf.%s.rp_filter=0"
                % interface
            )

    sysctl_path = Path(
        "/etc/sysctl.d/99-cloud-direct-routing.conf"
    )
    try:
        sysctl_path.write_text(
            "\n".join(lines) + "\n"
        )
    except Exception:
        pass

    subprocess.run(
        ["sysctl", "-w", "net.ipv4.ip_forward=1"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    for key in (
        "net.ipv4.conf.all.rp_filter",
        "net.ipv4.conf.default.rp_filter",
    ):
        subprocess.run(
            ["sysctl", "-w", "%s=0" % key],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    for interface in interfaces:
        if not interface:
            continue
        subprocess.run(
            [
                "sysctl", "-w",
                "net.ipv4.conf.%s.rp_filter=0"
                % interface,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )


def _direct_live_allowed_ips(interface, public_key):
    proc = subprocess.run(
        ["wg", "show", interface, "allowed-ips"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if proc.returncode != 0:
        return set()

    for raw in proc.stdout.decode(
        errors="ignore"
    ).splitlines():
        parts = raw.split()
        if not parts or parts[0] != public_key:
            continue
        return {
            item.strip().rstrip(",")
            for item in parts[1:]
            if item.strip()
        }
    return set()


def _direct_interface_live_ok(
    peer,
    params,
    subscriber_ips,
    device_ips,
):
    """Check the actual kernel state, not only the cached digest."""
    interface = params["interface"]

    if subprocess.run(
        ["wg", "show", interface],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ).returncode != 0:
        return False

    address_proc = subprocess.run(
        [
            "ip", "-o", "-4", "address", "show",
            "dev", interface,
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if address_proc.returncode != 0:
        return False
    if params["server_cidr"] not in address_proc.stdout.decode(
        errors="ignore"
    ):
        return False

    peers_proc = subprocess.run(
        ["wg", "show", interface, "peers"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    live_peers = peers_proc.stdout.decode(
        errors="ignore"
    ).split()
    if params["router_public"] not in live_peers:
        return False

    expected_allowed = {
        params["router_ip"] + "/32"
    }
    expected_allowed.update(
        value + "/32"
        for value in subscriber_ips
    )
    actual_allowed = _direct_live_allowed_ips(
        interface,
        params["router_public"],
    )
    if not expected_allowed.issubset(actual_allowed):
        return False

    table = str(params["table"])
    route_proc = subprocess.run(
        ["ip", "-4", "route", "show", "table", table],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    routes = route_proc.stdout.decode(
        errors="ignore"
    )
    if route_proc.returncode != 0:
        return False

    router_ip = str(
        ipaddress.ip_interface(peer["tunnel_ip"]).ip
    )
    if (
        router_ip not in routes
        or "unreachable default" not in routes
    ):
        return False

    for subscriber_ip in subscriber_ips:
        if (
            subscriber_ip not in routes
            or interface not in routes
        ):
            return False

    rules_proc = subprocess.run(
        ["ip", "-4", "rule", "show"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    rules = rules_proc.stdout.decode(
        errors="ignore"
    )
    if rules_proc.returncode != 0:
        return False

    for source_ip in device_ips:
        if (
            ("from %s" % source_ip) not in rules
            or ("lookup %s" % table) not in rules
        ):
            return False

    return True


def sync_direct_subscriber_routes(force=False):
    """Build one WireGuard interface and route table per router."""
    with DIRECT_ACCESS_LOCK:
        by_peer, conflicts = active_direct_subscriber_map()
        digest = _direct_state_digest(by_peer, conflicts)

        con = db()
        enabled_peers = con.execute(
            """
            SELECT * FROM peers
            WHERE enabled=1
            ORDER BY id
            """
        ).fetchall()
        devices = con.execute(
            """
            SELECT peer_id,tunnel_ip
            FROM agent_devices
            WHERE enabled=1
            ORDER BY peer_id,id
            """
        ).fetchall()
        con.close()

        enabled_peer_ids = [
            int(row["id"])
            for row in enabled_peers
        ]
        device_ips_by_peer = {}
        for device in devices:
            device_ips_by_peer.setdefault(
                int(device["peer_id"]), []
            ).append(
                str(
                    ipaddress.ip_interface(
                        device["tunnel_ip"]
                    ).ip
                )
            )

        settings = get_settings()
        ensure_direct_routing_sysctls(
            enabled_peer_ids,
            settings,
        )

        all_direct_healthy = True
        for peer in enabled_peers:
            peer_id = int(peer["id"])
            params = _direct_router_parameters(
                peer,
                settings,
            )
            if not _direct_interface_live_ok(
                peer,
                params,
                by_peer.get(peer_id, []),
                device_ips_by_peer.get(peer_id, []),
            ):
                all_direct_healthy = False
                break

        if (
            not force
            and DIRECT_ROUTE_STATE.get("digest") == digest
            and all_direct_healthy
        ):
            return {
                "changed": False,
                "count": sum(len(v) for v in by_peer.values()),
                "conflicts": conflicts,
                "self_healed": False,
            }

        repair_required = not all_direct_healthy

        # Remove subscriber AllowedIPs from the shared management interface,
        # then install them on dedicated router interfaces.
        with MAIN_WG_LOCK:
            _sync_main_management_config()

        apply_all_direct_router_wireguard(
            force=(force or repair_required)
        )

        settings = get_settings()
        main_interface = settings["interface"].strip()

        # Remove v7.3.1 global direct routes. They caused the first peer to win
        # whenever two routers owned the same customer IP.
        subprocess.run(
            [
                "ip", "-4", "route", "flush",
                "dev", main_interface, "proto", "186",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        for values in by_peer.values():
            for subscriber_ip in values:
                while subprocess.run(
                    [
                        "ip", "-4", "route", "del",
                        subscriber_ip + "/32",
                        "dev", main_interface,
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                ).returncode == 0:
                    pass

        regenerate_nat_rules()
        DIRECT_ROUTE_STATE["digest"] = digest

        return {
            "changed": True,
            "count": sum(len(v) for v in by_peer.values()),
            "conflicts": conflicts,
            "self_healed": repair_required,
        }


def apply_wireguard():
    with MAIN_WG_LOCK:
        settings = get_settings()
        interface = settings["interface"].strip()
        config_path = generate_server_config()

        run(
            ["systemctl", "enable", "wg-quick@%s" % interface],
            check=False,
        )
        proc = subprocess.run(
            [
                "systemctl", "restart",
                "wg-quick@%s" % interface,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if proc.returncode != 0:
            raise RuntimeError(
                "فشل تشغيل WireGuard بعد حفظ ملف صالح: %s"
                % proc.stderr.decode(errors="ignore").strip()
            )

        live = subprocess.run(
            ["wg", "show", interface, "dump"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if live.returncode != 0:
            raise RuntimeError(
                "WireGuard اشتغل لكن تعذر قراءة حالته: %s"
                % live.stderr.decode(errors="ignore").strip()
            )

        regenerate_nat_rules()
        DIRECT_ROUTE_STATE["digest"] = ""
        return True


def peer_config(peer):
    settings = get_settings()
    _, server_public = ensure_server_keys(settings["interface"])
    return """[Interface]
PrivateKey = {private_key}
Address = {address}
DNS = {dns}
MTU = {mtu}

[Peer]
PublicKey = {server_public}
PresharedKey = {psk}
Endpoint = {endpoint}:{port}
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
""".format(
        private_key=peer["private_key"],
        address=peer["tunnel_ip"],
        dns=settings.get("dns", "1.1.1.1"),
        mtu=settings.get("mtu", "1420"),
        server_public=server_public,
        psk=peer["preshared_key"],
        endpoint=settings["endpoint"],
        port=settings["port"],
    )


def ping_peer(tunnel_ip):
    host = str(ipaddress.ip_interface(tunnel_ip).ip)
    proc = subprocess.run(
        ["ping", "-c", "4", "-W", "1", host],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    output = proc.stdout.decode(errors="ignore")
    loss = "100%"
    latency = "-"
    match = re.search(r"(\d+(?:\.\d+)?)% packet loss", output)
    if match:
        loss = match.group(1) + "%"
    match = re.search(r"= [\d.]+/([\d.]+)/", output)
    if match:
        latency = match.group(1) + " ms"
    return {
        "online": proc.returncode == 0,
        "loss": loss,
        "latency": latency,
        "output": output,
    }


def wireguard_peer_stats():
    settings = get_settings()
    stats = {}
    try:
        output = run(["wg", "show", settings["interface"], "dump"], check=False)
        lines = output.splitlines()
        for line in lines[1:]:
            cols = line.split("\t")
            if len(cols) >= 8:
                public_key = cols[0]
                latest = int(cols[4] or 0)
                stats[public_key] = {
                    "latest_handshake": latest,
                    "handshake_text": datetime.fromtimestamp(latest).strftime("%Y-%m-%d %H:%M:%S") if latest else "-",
                    "rx": int(cols[5] or 0),
                    "tx": int(cols[6] or 0),
                    "online": latest > 0 and (datetime.now().timestamp() - latest) < 180,
                }
    except Exception:
        pass
    return stats


def human_bytes(value):
    value = float(value or 0)
    units = ["B", "KB", "MB", "GB", "TB"]
    index = 0
    while value >= 1024 and index < len(units) - 1:
        value /= 1024.0
        index += 1
    return "%.1f %s" % (value, units[index])


app.jinja_env.filters["human_bytes"] = human_bytes


def refresh_runtime_caches():
    if not RUNTIME_CACHE_LOCK.acquire(False):
        return False
    try:
        main_stats = wireguard_peer_stats()
        agent_stats = agent_wireguard_stats()
        RUNTIME_CACHE["main_stats"] = main_stats
        RUNTIME_CACHE["agent_stats"] = agent_stats
        RUNTIME_CACHE["updated_at"] = time.time()
        return True
    finally:
        RUNTIME_CACHE_LOCK.release()


def wireguard_interface_summary(interface, expected_peers=0):
    summary = {
        "interface": interface,
        "active": False,
        "peer_count": int(expected_peers or 0),
        "rx": 0,
        "tx": 0,
        "latest_handshake": 0,
    }
    try:
        output = run(["wg", "show", interface, "dump"], check=False)
        lines = [line for line in output.splitlines() if line.strip()]
        if lines:
            summary["active"] = True
            summary["peer_count"] = max(summary["peer_count"], len(lines) - 1)
            for line in lines[1:]:
                cols = line.split("\t")
                if len(cols) >= 8:
                    latest = int(cols[4] or 0)
                    summary["latest_handshake"] = max(
                        summary["latest_handshake"], latest
                    )
                    summary["rx"] += int(cols[5] or 0)
                    summary["tx"] += int(cols[6] or 0)
    except Exception:
        pass
    return summary


def cached_wireguard_peer_stats():
    return dict(RUNTIME_CACHE.get("main_stats") or {})


def cached_agent_wireguard_stats():
    return dict(RUNTIME_CACHE.get("agent_stats") or {})


def _quick_ping_result(tunnel_ip):
    host = str(ipaddress.ip_interface(tunnel_ip).ip)
    started = time.time()
    proc = subprocess.run(
        ["ping", "-c", "1", "-W", "1", host],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    elapsed = max(0.0, (time.time() - started) * 1000.0)
    output = proc.stdout.decode(errors="ignore")
    latency = "-"
    match = re.search(r"time[=<]([0-9.]+) ?ms", output)
    if match:
        latency = match.group(1) + " ms"
    elif proc.returncode == 0:
        latency = "%.1f ms" % elapsed
    return {
        "online": proc.returncode == 0,
        "latency": latency,
        "loss": "0%" if proc.returncode == 0 else "100%",
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }


def refresh_ping_cache():
    con = db()
    peers = [
        dict(row)
        for row in con.execute(
            "SELECT id,tunnel_ip FROM peers WHERE enabled=1 ORDER BY id"
        ).fetchall()
    ]
    con.close()
    if not peers:
        return

    results = {}
    pool = ThreadPoolExecutor(max_workers=min(6, len(peers)))
    try:
        future_map = {
            pool.submit(_quick_ping_result, peer["tunnel_ip"]): peer["id"]
            for peer in peers
        }
        for future in as_completed(future_map):
            peer_id = int(future_map[future])
            try:
                results[peer_id] = future.result()
            except Exception:
                results[peer_id] = {
                    "online": False,
                    "latency": "-",
                    "loss": "100%",
                    "updated_at": datetime.now().isoformat(timespec="seconds"),
                }
    finally:
        pool.shutdown(wait=False)

    with PING_CACHE_LOCK:
        PING_CACHE.update(results)


def cached_peer_ping(peer_id):
    with PING_CACHE_LOCK:
        return dict(PING_CACHE.get(int(peer_id)) or {
            "online": False,
            "latency": "...",
            "loss": "...",
            "updated_at": "",
        })


def runtime_cache_loop():
    while True:
        try:
            refresh_runtime_caches()
        except Exception:
            pass
        time.sleep(5)


def ping_cache_loop():
    time.sleep(2)
    while True:
        try:
            refresh_ping_cache()
        except Exception:
            pass
        time.sleep(30)


# ---------------- MikroTik API ----------------

def _encode_length(length):
    if length < 0x80:
        return bytes([length])
    if length < 0x4000:
        length |= 0x8000
        return struct.pack(">H", length)
    if length < 0x200000:
        length |= 0xC00000
        return bytes([(length >> 16) & 0xFF, (length >> 8) & 0xFF, length & 0xFF])
    if length < 0x10000000:
        length |= 0xE0000000
        return struct.pack(">I", length)
    return b"\xF0" + struct.pack(">I", length)


def _read_exact(sock, count):
    data = b""
    while len(data) < count:
        chunk = sock.recv(count - len(data))
        if not chunk:
            raise RuntimeError("انقطع اتصال MikroTik API")
        data += chunk
    return data


def _read_length(sock):
    first = _read_exact(sock, 1)[0]
    if (first & 0x80) == 0:
        return first
    if (first & 0xC0) == 0x80:
        return ((first & ~0xC0) << 8) + _read_exact(sock, 1)[0]
    if (first & 0xE0) == 0xC0:
        b2 = _read_exact(sock, 2)
        return ((first & ~0xE0) << 16) + (b2[0] << 8) + b2[1]
    if (first & 0xF0) == 0xE0:
        b3 = _read_exact(sock, 3)
        return ((first & ~0xF0) << 24) + (b3[0] << 16) + (b3[1] << 8) + b3[2]
    if first == 0xF0:
        return struct.unpack(">I", _read_exact(sock, 4))[0]
    raise RuntimeError("صيغة API غير صحيحة")


class RouterOSAPI(object):
    def __init__(self, host, port, username, password, use_ssl=False, timeout=4):
        self.host = host
        self.port = int(port)
        self.username = username
        self.password = password
        self.use_ssl = bool(use_ssl)
        self.timeout = timeout
        self.sock = None

    def connect(self):
        raw = socket.create_connection((self.host, self.port), self.timeout)
        if self.use_ssl:
            context = ssl._create_unverified_context()
            raw = context.wrap_socket(raw, server_hostname=self.host)
        self.sock = raw
        self.talk("/login", {
            "name": self.username,
            "password": self.password,
        })
        return self

    def close(self):
        try:
            if self.sock:
                self.sock.close()
        finally:
            self.sock = None

    def write_sentence(self, words):
        payload = b""
        for word in words:
            encoded = word.encode("utf-8")
            payload += _encode_length(len(encoded)) + encoded
        payload += b"\x00"
        self.sock.sendall(payload)

    def read_sentence(self):
        words = []
        while True:
            length = _read_length(self.sock)
            if length == 0:
                return words
            words.append(_read_exact(self.sock, length).decode("utf-8", errors="replace"))

    def talk(self, command, attrs=None, queries=None):
        words = [command]
        for key, value in (attrs or {}).items():
            words.append("=%s=%s" % (key, value))
        for query in queries or []:
            words.append(query)
        self.write_sentence(words)

        replies = []
        while True:
            sentence = self.read_sentence()
            if not sentence:
                continue
            reply_type = sentence[0]
            data = {}
            message = ""
            for word in sentence[1:]:
                if word.startswith("="):
                    parts = word[1:].split("=", 1)
                    if len(parts) == 2:
                        data[parts[0]] = parts[1]
                elif word.startswith("=message="):
                    message = word.split("=", 2)[2]
            if reply_type == "!re":
                replies.append(data)
            elif reply_type == "!trap":
                raise RuntimeError(data.get("message") or message or "MikroTik API error")
            elif reply_type == "!done":
                return replies

    def find_one(self, command, queries):
        rows = self.talk(command, queries=queries)
        return rows[0] if rows else None


def get_peer_or_404(peer_id):
    con = db()
    peer = con.execute("SELECT * FROM peers WHERE id=?", (peer_id,)).fetchone()
    con.close()
    return peer


def _peer_get(peer, key, default=""):
    try:
        value = peer[key]
    except Exception:
        try:
            value = peer.get(key, default)
        except Exception:
            return default
    return default if value is None else value


def connect_peer_api_primary(peer):
    password = decrypt_text(_peer_get(peer, "mt_password_enc", ""))
    username = str(_peer_get(peer, "mt_username", "") or "").strip()
    host = str(_peer_get(peer, "mt_host", "") or "").strip()
    if not host or not username or not password:
        raise RuntimeError("أدخل IP واسم المستخدم وكلمة مرور MikroTik API أولاً")
    return RouterOSAPI(
        host,
        int(_peer_get(peer, "mt_port", 8728) or 8728),
        username,
        password,
        bool(_peer_get(peer, "mt_ssl", 0)),
    ).connect()


def connect_peer_api(peer):
    try:
        return connect_peer_api_primary(peer)
    except Exception as primary_error:
        recovery_username = str(_peer_get(peer, "recovery_username", "") or "").strip()
        recovery_password = decrypt_text(_peer_get(peer, "recovery_password_enc", ""))
        host = str(_peer_get(peer, "mt_host", "") or "").strip()
        if recovery_username and recovery_password and host:
            try:
                return RouterOSAPI(
                    host,
                    int(_peer_get(peer, "mt_port", 8728) or 8728),
                    recovery_username,
                    recovery_password,
                    bool(_peer_get(peer, "mt_ssl", 0)),
                ).connect()
            except Exception:
                pass
        raise primary_error



def _subscriber_ipv4(value):
    value = (value or "").strip()
    if not value:
        return ""
    try:
        address = ipaddress.ip_interface(value).ip if "/" in value else ipaddress.ip_address(value)
    except Exception:
        return ""
    if address.version != 4:
        return ""
    if address.is_unspecified or address.is_loopback or address.is_multicast:
        return ""
    return str(address)


def _best_subscriber_name(*values):
    for value in values:
        value = (value or "").strip()
        if value and value not in ("0.0.0.0", "*", "unknown"):
            return value
    return ""


def probe_router_subscribers(peer_id):
    """Read active subscribers and return source-by-source diagnostics."""
    peer = get_peer_or_404(peer_id)
    if not peer:
        raise RuntimeError("الوكيل غير موجود")

    api = connect_peer_api(peer)
    found = {}
    sources = {
        "PPPoE": {"ok": False, "count": 0, "error": ""},
        "Hotspot": {"ok": False, "count": 0, "error": ""},
        "DHCP": {"ok": False, "count": 0, "error": ""},
    }

    def safe_print(command, proplist):
        try:
            return api.talk(
                command,
                attrs={".proplist": proplist},
            )
        except Exception:
            # Some older RouterOS builds behave better without .proplist.
            return api.talk(command)

    def add(
        source,
        subscriber_key,
        priority,
        ip_value,
        name_value,
        extra=""
    ):
        ip_value = _subscriber_ipv4(ip_value)
        subscriber_key = (
            subscriber_key or ""
        ).strip().lower()

        if not ip_value or not subscriber_key:
            return

        name_value = _best_subscriber_name(
            name_value,
            extra,
            ip_value,
        )

        item = {
            "key": subscriber_key,
            "ip": ip_value,
            "name": name_value,
            "source": source,
            "priority": int(priority),
            "extra": (extra or "").strip(),
        }

        current = found.get(subscriber_key)
        if (
            current is None
            or item["priority"] > current["priority"]
        ):
            found[subscriber_key] = item
        elif item["priority"] == current["priority"]:
            if (
                current["name"] == current["ip"]
                and item["name"] != item["ip"]
            ):
                found[subscriber_key] = item

    try:
        # PPPoE / PPP active sessions
        try:
            rows = safe_print(
                "/ppp/active/print",
                "name,address,caller-id,service",
            )
            valid_count = 0
            for row in rows:
                username = (
                    row.get("name")
                    or row.get("user")
                    or ""
                ).strip()
                address = (
                    row.get("address")
                    or row.get("remote-address")
                    or ""
                )
                before = len(found)
                add(
                    "PPPoE",
                    "pppoe:%s" % username.lower(),
                    100,
                    address,
                    username,
                    row.get("caller-id")
                    or row.get("service")
                    or "",
                )
                if len(found) > before:
                    valid_count += 1

            sources["PPPoE"]["ok"] = True
            sources["PPPoE"]["count"] = valid_count
        except Exception as exc:
            sources["PPPoE"]["error"] = str(exc)

        # Hotspot active sessions
        try:
            rows = safe_print(
                "/ip/hotspot/active/print",
                "user,address,mac-address,server",
            )
            valid_count = 0
            for row in rows:
                username = (
                    row.get("user")
                    or row.get("name")
                    or ""
                ).strip()
                before = len(found)
                add(
                    "Hotspot",
                    "hotspot:%s" % username.lower(),
                    95,
                    row.get("address"),
                    username,
                    row.get("mac-address")
                    or row.get("server")
                    or "",
                )
                if len(found) > before:
                    valid_count += 1

            sources["Hotspot"]["ok"] = True
            sources["Hotspot"]["count"] = valid_count
        except Exception as exc:
            sources["Hotspot"]["error"] = str(exc)

        # Bound DHCP leases
        try:
            rows = safe_print(
                "/ip/dhcp-server/lease/print",
                "address,status,mac-address,host-name,comment",
            )
            valid_count = 0
            for row in rows:
                status = (
                    row.get("status") or ""
                ).strip().lower()
                if status and status != "bound":
                    continue

                mac = (
                    row.get("mac-address") or ""
                ).strip().lower()
                host = (
                    row.get("comment")
                    or row.get("host-name")
                    or mac
                    or row.get("address")
                    or ""
                )
                key_value = (
                    "dhcp:%s" % mac
                    if mac
                    else "dhcp-ip:%s"
                    % (row.get("address") or "")
                )

                before = len(found)
                add(
                    "DHCP",
                    key_value,
                    85,
                    row.get("address"),
                    host,
                    row.get("host-name") or mac,
                )
                if len(found) > before:
                    valid_count += 1

            sources["DHCP"]["ok"] = True
            sources["DHCP"]["count"] = valid_count
        except Exception as exc:
            sources["DHCP"]["error"] = str(exc)
    finally:
        api.close()

    successful = [
        name
        for name, state in sources.items()
        if state["ok"]
    ]
    if not successful:
        errors = [
            "%s: %s" % (
                name,
                state["error"] or "unknown error",
            )
            for name, state in sources.items()
        ]
        raise RuntimeError(
            "تعذر قراءة المشتركين من MikroTik: "
            + " | ".join(errors)
        )

    subscribers = list(found.values())
    subscribers.sort(
        key=lambda item: (
            item["name"].lower(),
            tuple(
                int(part)
                for part in item["ip"].split(".")
            ),
        )
    )
    for item in subscribers:
        item.pop("priority", None)

    return {
        "subscribers": subscribers,
        "sources": sources,
        "successful_sources": successful,
        "failed_sources": [
            name
            for name, state in sources.items()
            if not state["ok"]
        ],
    }


def fetch_router_subscribers(peer_id):
    return probe_router_subscribers(peer_id)["subscribers"]


def canonical_router_subscriber(peer_id, internal_ip):
    internal_ip = normalize_internal_ip(internal_ip)
    for item in fetch_router_subscribers(peer_id):
        if item["ip"] == internal_ip:
            return item
    raise RuntimeError(
        "هذا الـIP غير موجود ضمن مشتركي الراوتر المحدد؛ حدّث قائمة المشتركين"
    )



def import_all_router_subscribers(
    default_internal_port=80,
    protocol="tcp",
    only_peer_id=None
):
    try:
        default_internal_port = int(default_internal_port)
    except Exception:
        raise RuntimeError("البورت الداخلي الافتراضي غير صحيح")
    if default_internal_port < 1 or default_internal_port > 65535:
        raise RuntimeError("البورت الداخلي الافتراضي غير صحيح")

    protocol = validate_forward_protocol(protocol)

    con = db()
    if only_peer_id is None:
        peers = con.execute(
            """
            SELECT * FROM peers
            WHERE enabled=1
            ORDER BY name, id
            """
        ).fetchall()
    else:
        peers = con.execute(
            """
            SELECT * FROM peers
            WHERE enabled=1 AND id=?
            ORDER BY name, id
            """,
            (int(only_peer_id),)
        ).fetchall()
    con.close()

    if not peers:
        raise RuntimeError("لا يوجد أي راوتر فعال")

    # Read used ports once before any write transaction begins.
    settings = get_settings()
    port_start = max(
        20001,
        int(settings.get("pf_port_start", "20001") or 20001),
    )
    port_end = min(
        65535,
        int(settings.get("pf_port_end", "65000") or 65000),
    )
    if port_start > port_end:
        port_start, port_end = 20001, 65000

    port_con = db()
    used_external_ports = {
        int(row["external_port"])
        for row in port_con.execute(
            "SELECT external_port FROM port_forwards"
        ).fetchall()
    }
    used_external_ports.update({
        int(row["winbox_external"])
        for row in port_con.execute(
            """
            SELECT winbox_external FROM peers
            WHERE winbox_external > 0
            """
        ).fetchall()
    })
    port_con.close()

    used_external_ports.update({
        22, 53, 80, 443, 1994, 8291, 8728, 8729, 9494,
        int(settings.get("port", "51820") or 51820),
        int(
            settings.get(
                "agent_port",
                str(DEFAULT_AGENT_PORT),
            ) or DEFAULT_AGENT_PORT
        ),
    })
    used_external_ports.update(
        _direct_listen_port(peer["id"])
        for peer in peers
    )

    def allocate_forward_port():
        for candidate in range(port_start, port_end + 1):
            if candidate in used_external_ports:
                continue
            if _listener_uses_port(candidate, "tcp"):
                continue
            if _listener_uses_port(candidate, "udp"):
                continue
            used_external_ports.add(candidate)
            return candidate
        raise RuntimeError(
            "لا يوجد بورت خارجي فارغ ابتداءً من 20001"
        )

    total_found = 0
    total_added = 0
    total_updated = 0
    total_deleted = 0
    changed_peer_ids = set()
    router_results = []
    discovery_errors = []

    for peer in peers:
        peer_id = int(peer["id"])
        router_result = {
            "peer_id": peer_id,
            "peer_name": peer["name"],
            "tunnel_ip": peer["tunnel_ip"],
            "found": 0,
            "added": 0,
            "updated": 0,
            "deleted": 0,
            "error": "",
        }

        try:
            # No deletion occurs unless this call succeeds.
            probe = probe_router_subscribers(peer_id)
            subscribers = probe["subscribers"]
            router_result["sources"] = probe["sources"]
            router_result["successful_sources"] = (
                probe["successful_sources"]
            )
            router_result["failed_sources"] = (
                probe["failed_sources"]
            )
            router_result["found"] = len(subscribers)
            total_found += len(subscribers)

            DB_WRITE_LOCK.acquire()
            con = db()
            existing_rows = con.execute(
                """
                SELECT * FROM port_forwards
                WHERE peer_id=?
                ORDER BY id
                """,
                (peer_id,)
            ).fetchall()

            by_key = {
                (row["subscriber_key"] or "").strip().lower(): row
                for row in existing_rows
                if (row["subscriber_key"] or "").strip()
            }
            unmatched = {int(row["id"]): row for row in existing_rows}
            seen_keys = set()
            stamp = datetime.now().isoformat(timespec="seconds")

            for subscriber in subscribers:
                subscriber_key = subscriber["key"].strip().lower()
                internal_ip = normalize_internal_ip(subscriber["ip"])
                name = (
                    (subscriber.get("name") or "").strip()
                    or internal_ip
                )
                source = (
                    subscriber.get("source") or ""
                ).strip()
                seen_keys.add(subscriber_key)

                existing = by_key.get(subscriber_key)

                # Upgrade legacy v7.0 records by matching same username first,
                # then same current IP. This preserves their public port.
                if existing is None:
                    lowered_name = name.lower()
                    for candidate in list(unmatched.values()):
                        if (
                            (candidate["name"] or "").strip().lower()
                            == lowered_name
                        ):
                            existing = candidate
                            break

                if existing is None:
                    for candidate in list(unmatched.values()):
                        if (
                            (candidate["internal_ip"] or "").strip()
                            == internal_ip
                        ):
                            existing = candidate
                            break

                if existing is not None:
                    existing_id = int(existing["id"])
                    unmatched.pop(existing_id, None)

                    changed = (
                        (existing["name"] or "") != name
                        or (existing["internal_ip"] or "") != internal_ip
                        or (existing["subscriber_key"] or "") != subscriber_key
                        or (existing["subscriber_source"] or "") != source
                        or int(existing["auto_managed"] or 0) != 1
                        or int(existing["enabled"] or 0) != 1
                    )

                    con.execute(
                        """
                        UPDATE port_forwards
                        SET name=?, internal_ip=?, subscriber_key=?,
                            subscriber_source=?, auto_managed=1,
                            enabled=1, last_seen_at=?, updated_at=?,
                            last_error=''
                        WHERE id=?
                        """,
                        (
                            name,
                            internal_ip,
                            subscriber_key,
                            source,
                            stamp,
                            stamp,
                            existing_id,
                        )
                    )

                    if changed:
                        router_result["updated"] += 1
                        total_updated += 1
                        changed_peer_ids.add(peer_id)
                    continue

                external_port = allocate_forward_port()
                con.execute(
                    """
                    INSERT INTO port_forwards
                    (
                        peer_id, name, internal_ip, internal_port,
                        external_port, protocol, enabled,
                        created_at, updated_at, last_applied_at, last_error,
                        subscriber_key, subscriber_source,
                        auto_managed, last_seen_at
                    )
                    VALUES(?,?,?,?,?,?,1,?,?,?,?,?,?,1,?)
                    """,
                    (
                        peer_id,
                        name,
                        internal_ip,
                        default_internal_port,
                        external_port,
                        protocol,
                        stamp,
                        stamp,
                        "",
                        "",
                        subscriber_key,
                        source,
                        stamp,
                    )
                )

                router_result["added"] += 1
                total_added += 1
                changed_peer_ids.add(peer_id)

            # Delete an offline subscriber only when its own source
            # was read successfully. A partial API failure cannot delete it.
            successful_sources = set(
                probe["successful_sources"]
            )
            all_sources_ok = len(successful_sources) == 3
            stale_ids = []

            for row in existing_rows:
                if int(row["auto_managed"] or 0) != 1:
                    continue

                key_value = (
                    row["subscriber_key"] or ""
                ).strip().lower()
                row_source = (
                    row["subscriber_source"] or ""
                ).strip()

                # A matched row was removed from unmatched above.
                if int(row["id"]) not in unmatched:
                    continue
                if key_value and key_value in seen_keys:
                    continue

                # Legacy records without source are deleted only when
                # all three source reads succeeded.
                if row_source:
                    if row_source not in successful_sources:
                        continue
                elif not all_sources_ok:
                    continue

                stale_ids.append(int(row["id"]))

            for stale_id in stale_ids:
                con.execute(
                    "DELETE FROM port_forwards WHERE id=?",
                    (stale_id,)
                )

            if stale_ids:
                router_result["deleted"] = len(stale_ids)
                total_deleted += len(stale_ids)
                changed_peer_ids.add(peer_id)

            con.commit()
            con.close()
            con = None
            DB_WRITE_LOCK.release()

        except Exception as exc:
            try:
                if "con" in locals() and con is not None:
                    con.rollback()
                    con.close()
                    con = None
            except Exception:
                pass
            try:
                if DB_WRITE_LOCK._is_owned():
                    DB_WRITE_LOCK.release()
            except Exception:
                pass
            router_result["error"] = str(exc)
            discovery_errors.append(
                "%s: %s" % (peer["name"], exc)
            )

        router_results.append(router_result)

    if changed_peer_ids:
        regenerate_nat_rules()

    apply_errors = []
    for peer_id in sorted(changed_peer_ids):
        try:
            sync_peer_port_forwards(peer_id)
        except Exception as exc:
            apply_errors.append(
                "الراوتر %s: %s" % (peer_id, exc)
            )
            con = db()
            con.execute(
                """
                UPDATE port_forwards
                SET last_error=?, updated_at=?
                WHERE peer_id=?
                """,
                (
                    str(exc)[:1000],
                    datetime.now().isoformat(timespec="seconds"),
                    peer_id,
                )
            )
            con.commit()
            con.close()

    # Reconcile direct access even when the DB rows did not change.
    # The in-memory hashes prevent unnecessary RouterOS API writes.
    for router_result in router_results:
        if router_result.get("error"):
            continue
        peer_id = int(router_result["peer_id"])
        try:
            sync_router_direct_subscriber_access(peer_id)
        except Exception as exc:
            apply_errors.append(
                "الراوتر %s direct access: %s"
                % (peer_id, exc)
            )

    try:
        sync_direct_subscriber_routes()
    except Exception as exc:
        apply_errors.append(
            "Ubuntu direct routes: %s" % exc
        )

    return {
        "found": total_found,
        "added": total_added,
        "updated": total_updated,
        "deleted": total_deleted,
        "routers": router_results,
        "discovery_errors": discovery_errors,
        "apply_errors": apply_errors,
    }


SUBSCRIBER_SYNC_LOCK = threading.Lock()


def _subscriber_sync_log(message):
    try:
        path = APP_DIR / "subscriber-sync.log"
        with path.open("a") as handle:
            handle.write(
                "%s %s\n"
                % (
                    datetime.now().isoformat(timespec="seconds"),
                    message,
                )
            )
    except Exception:
        pass


def run_automatic_subscriber_sync():
    if not SUBSCRIBER_SYNC_LOCK.acquire(False):
        return None

    with SUBSCRIBER_SYNC_STATE_LOCK:
        SUBSCRIBER_SYNC_STATE["running"] = True
        SUBSCRIBER_SYNC_STATE["last_started_at"] = (
            datetime.now().isoformat(timespec="seconds")
        )
        SUBSCRIBER_SYNC_STATE["last_error"] = ""

    try:
        settings = get_settings()
        if settings.get("subscriber_sync_enabled", "1") != "1":
            return None

        default_port = int(
            settings.get("subscriber_default_port", "80") or 80
        )
        default_protocol = settings.get(
            "subscriber_default_protocol", "tcp"
        )

        result = import_all_router_subscribers(
            default_internal_port=default_port,
            protocol=default_protocol,
        )

        _subscriber_sync_log(
            "found=%s added=%s updated=%s deleted=%s errors=%s"
            % (
                result["found"],
                result["added"],
                result["updated"],
                result["deleted"],
                len(result["discovery_errors"])
                + len(result["apply_errors"]),
            )
        )
        with SUBSCRIBER_SYNC_STATE_LOCK:
            SUBSCRIBER_SYNC_STATE["last_result"] = dict(result)
        return result
    except Exception as exc:
        _subscriber_sync_log("error=%s" % exc)
        with SUBSCRIBER_SYNC_STATE_LOCK:
            SUBSCRIBER_SYNC_STATE["last_error"] = str(exc)
        return None
    finally:
        with SUBSCRIBER_SYNC_STATE_LOCK:
            SUBSCRIBER_SYNC_STATE["running"] = False
            SUBSCRIBER_SYNC_STATE["last_finished_at"] = (
                datetime.now().isoformat(timespec="seconds")
            )
        SUBSCRIBER_SYNC_LOCK.release()



WIREGUARD_AUTO_SYNC_LOCK = threading.Lock()


def _wireguard_auto_sync_log(message):
    try:
        path = APP_DIR / "wireguard-auto-sync.log"
        with path.open("a") as handle:
            handle.write(
                "%s %s\n"
                % (
                    datetime.now().isoformat(timespec="seconds"),
                    message,
                )
            )
    except Exception:
        pass


def run_automatic_wireguard_sync():
    if not WIREGUARD_AUTO_SYNC_LOCK.acquire(False):
        return None
    try:
        imported = import_peers_from_ubuntu()
        created = ensure_all_agent_devices()
        agent_error = ""
        try:
            apply_agent_wireguard()
        except Exception as exc:
            agent_error = str(exc)
            # Keep the existing router/port NAT alive even if the
            # dedicated device interface cannot start.
            regenerate_nat_rules()

        _wireguard_auto_sync_log(
            "imported=%s agent_devices=%s nat=ok agent_error=%s"
            % (imported, created, agent_error or "-")
        )
        return imported
    except Exception as exc:
        _wireguard_auto_sync_log("error=%s" % exc)
        return None
    finally:
        WIREGUARD_AUTO_SYNC_LOCK.release()


def wireguard_auto_sync_loop():
    time.sleep(10)
    while True:
        run_automatic_wireguard_sync()
        time.sleep(30)


def subscriber_sync_loop():
    # Start quickly, then keep polling every 20 seconds by default.
    time.sleep(5)

    while True:
        run_automatic_subscriber_sync()

        try:
            settings = get_settings()
            interval = int(
                settings.get("subscriber_sync_seconds", "20") or 20
            )
        except Exception:
            interval = 20

        time.sleep(max(15, interval))


def random_api_credentials():
    username = "cwg_" + secrets.token_hex(4)
    password = secrets.token_urlsafe(18)
    return username, password


def ensure_random_api_credentials(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        return None, None, None

    current_password = decrypt_text(peer["mt_password_enc"])
    current_username = peer["mt_username"] or ""

    if current_username and current_password and int(peer["mt_port"] or 0) == 9494:
        return peer, current_username, current_password

    username, password = random_api_credentials()
    con = db()
    con.execute("""
        UPDATE peers
        SET mt_username=?, mt_password_enc=?, mt_port=9494, mt_ssl=0
        WHERE id=?
    """, (
        username,
        encrypt_text(password),
        peer_id,
    ))
    con.commit()
    con.close()
    return get_peer_or_404(peer_id), username, password


def mikrotik_api_bootstrap_script(peer, username, password):
    settings = get_settings()
    source_ip = (
        str(ipaddress.ip_interface(settings["address"]).ip)
        + "/32"
    )

    return """# Cloud WG Panel - Full API bootstrap
# Paste the whole block into MikroTik Terminal

:if ([:len [/user find where name="{username}"]] = 0) do={{
  /user add name="{username}" password="{password}" group="full" comment="Managed by Cloud WG Panel - FULL"
}} else={{
  /user set [find where name="{username}"] password="{password}" group="full" disabled=no comment="Managed by Cloud WG Panel - FULL"
}}

/ip/service set [find where name="api"] port=9494 disabled=no address={source_ip}

:put "Cloud API ready with FULL permissions"
:put "Username: {username}"
:put "Password: {password}"
:put "Group: full"
""".format(
        username=username,
        password=password,
        source_ip=source_ip,
    )



def _read_winbox_internal_port(api):
    """Return the live RouterOS WinBox port, or None when unavailable."""
    try:
        service = api.find_one("/ip/service/print", ["?name=winbox"])
        if not service:
            return None
        port = int(service.get("port", 0) or 0)
        return port if 1 <= port <= 65535 else None
    except Exception:
        return None


def _save_live_router_state(peer_id, winbox_port=None, radius_states=None):
    assignments = []
    values = []
    if winbox_port:
        assignments.append("winbox_internal=?")
        values.append(int(winbox_port))
    if radius_states:
        assignments.extend(["cloud_main_state=?", "cloud_bypass_state=?"])
        values.extend([
            radius_states.get("main", "unknown"),
            radius_states.get("bypass", "unknown"),
        ])
    if not assignments:
        return
    values.append(int(peer_id))
    con = db()
    con.execute(
        "UPDATE peers SET %s WHERE id=?" % ",".join(assignments),
        tuple(values),
    )
    con.commit()
    con.close()


def sync_peer_winbox_internal_silent(peer_id):
    """Refresh WinBox port without surfacing warnings to the UI."""
    peer = get_peer_or_404(peer_id)
    if not peer:
        return None
    try:
        api = connect_peer_api(peer)
        try:
            port = _read_winbox_internal_port(api)
            if port:
                _save_live_router_state(peer_id, winbox_port=port)
            return port
        finally:
            api.close()
    except Exception:
        return None


def router_overview(peer):
    api = connect_peer_api(peer)
    try:
        identity_rows = api.talk("/system/identity/print")
        resource_rows = api.talk("/system/resource/print")
        route_rows = api.talk("/ip/route/print")
        identity = identity_rows[0] if identity_rows else {}
        resource = resource_rows[0] if resource_rows else {}
        active_routes = sum(
            1 for item in route_rows
            if item.get("active", "false") == "true"
            and item.get("disabled", "false") != "true"
        )
        radius_states = _cloud_radius_states(api)
        winbox_port = _read_winbox_internal_port(api)
        _save_live_router_state(
            peer["id"],
            winbox_port=winbox_port,
            radius_states=radius_states,
        )
        return {
            "identity": identity.get("name", "-"),
            "version": resource.get("version", "-"),
            "uptime": resource.get("uptime", "-"),
            "architecture": resource.get("architecture-name", "-"),
            "board": resource.get("board-name", "-"),
            "cpu": resource.get("cpu", "-"),
            "cpu_count": resource.get("cpu-count", "-"),
            "cpu_load": resource.get("cpu-load", "0"),
            "free_memory": resource.get("free-memory", "0"),
            "total_memory": resource.get("total-memory", "0"),
            "free_hdd": resource.get("free-hdd-space", "0"),
            "active_routes": active_routes,
            "cloud_main_state": radius_states.get("main", "unknown"),
            "cloud_bypass_state": radius_states.get("bypass", "unknown"),
            "winbox_internal": winbox_port,
        }
    finally:
        api.close()

def provision_mikrotik_management(
    peer,
    managed_username,
    managed_password,
    target_port=9494
):
    if not managed_username:
        raise RuntimeError("اسم مستخدم الإدارة مطلوب")
    if len(managed_password) < 8:
        raise RuntimeError(
            "كلمة مرور الإدارة يجب أن تكون 8 أحرف على الأقل"
        )

    api = connect_peer_api(peer)
    try:
        user = api.find_one(
            "/user/print",
            ["?name=%s" % managed_username]
        )
        attrs = {
            "name": managed_username,
            "password": managed_password,
            "group": "full",
            "disabled": "no",
            "comment": "Managed by Cloud WG Panel - FULL",
        }
        if user:
            attrs[".id"] = user[".id"]
            api.talk("/user/set", attrs)
        else:
            api.talk("/user/add", attrs)

        service = api.find_one(
            "/ip/service/print",
            ["?name=api"]
        )
        if not service:
            raise RuntimeError("خدمة API غير موجودة")

        source = (
            str(
                ipaddress.ip_interface(
                    get_settings()["address"]
                ).ip
            )
            + "/32"
        )
        api.talk(
            "/ip/service/set",
            {
                ".id": service[".id"],
                "port": str(int(target_port)),
                "disabled": "no",
                "address": source,
            }
        )
    finally:
        api.close()

    con = db()
    con.execute(
        """
        UPDATE peers
        SET mt_port=?, mt_username=?,
            mt_password_enc=?, mt_ssl=0
        WHERE id=?
        """,
        (
            int(target_port),
            managed_username,
            encrypt_text(managed_password),
            peer["id"],
        )
    )
    con.commit()
    con.close()

    updated = get_peer_or_404(peer["id"])
    verify = connect_peer_api(updated)
    try:
        identity = verify.talk("/system/identity/print")
        resource = verify.talk("/system/resource/print")
        return {
            "identity": (
                identity[0].get("name", "-")
                if identity else "-"
            ),
            "version": (
                resource[0].get("version", "-")
                if resource else "-"
            ),
            "port": int(target_port),
            "username": managed_username,
            "group": "full",
        }
    finally:
        verify.close()



def _routeros_bool(value):
    return "yes" if bool(value) else "no"


def _api_find_by_comment(api, menu, comment):
    rows = api.talk(menu + "/print")
    for row in rows:
        if row.get("comment", "") == comment:
            return row
    return None


def _api_find_by_name(api, menu, name):
    rows = api.talk(menu + "/print")
    for row in rows:
        if row.get("name", "") == name:
            return row
    return None


def _ros_quote(value):
    return str(value or "").replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$")



def ensure_recovery_credentials(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        raise RuntimeError("الراوتر غير موجود")

    username = CLOUD_RECOVERY_USERNAME
    password = CLOUD_RECOVERY_PASSWORD
    health_token = str(
        _peer_get(peer, "cloud_health_token", "") or ""
    ).strip()
    if not health_token:
        health_token = secrets.token_urlsafe(24)

    current_username = str(
        _peer_get(peer, "recovery_username", "") or ""
    ).strip()
    current_password = decrypt_text(
        _peer_get(peer, "recovery_password_enc", "")
    )

    if (
        current_username != username
        or current_password != password
        or not _peer_get(peer, "cloud_health_token", "")
    ):
        con = db()
        con.execute(
            "UPDATE peers SET recovery_username=?,recovery_password_enc=?,cloud_health_token=? WHERE id=?",
            (
                username,
                encrypt_text(password),
                health_token,
                int(peer_id),
            ),
        )
        con.commit()
        con.close()

    return get_peer_or_404(peer_id), username, password

def _cloud_source_ip():
    return str(ipaddress.ip_interface(get_settings()["address"]).ip) + "/32"



def _ensure_recovery_account_api(api, peer):
    username = CLOUD_RECOVERY_USERNAME
    password = CLOUD_RECOVERY_PASSWORD
    if not username or not password:
        raise RuntimeError("بيانات حساب الاسترداد غير جاهزة")

    account = _api_find_by_name(api, "/user", username)
    attrs = {
        "name": username,
        "password": password,
        "group": "full",
        "address": _cloud_source_ip(),
        "disabled": "no",
        "comment": "Cloud WG Panel Recovery",
    }
    if account:
        attrs[".id"] = account[".id"]
        api.talk("/user/set", attrs)
    else:
        api.talk("/user/add", attrs)

    managed_username = str(
        _peer_get(peer, "mt_username", "") or ""
    ).strip()
    for row in api.talk("/user/print"):
        row_name = str(row.get("name", "") or "").strip()
        if (
            row.get("comment", "") == "Cloud WG Panel Recovery"
            and row_name
            and row_name not in (username, managed_username, "admin")
            and row.get(".id")
        ):
            api.talk("/user/remove", {".id": row[".id"]})

def _ensure_managed_account_api(api, peer):
    username = str(_peer_get(peer, "mt_username", "") or "").strip()
    password = decrypt_text(_peer_get(peer, "mt_password_enc", ""))
    if not username or not password:
        return False
    account = _api_find_by_name(api, "/user", username)
    attrs = {
        "name": username,
        "password": password,
        "group": "full",
        "disabled": "no",
        "comment": "Managed by Cloud WG Panel - FULL",
    }
    if account:
        attrs[".id"] = account[".id"]
        api.talk("/user/set", attrs)
    else:
        api.talk("/user/add", attrs)
    return True



def _router_provision_script_source(peer):
    recovery_username = _ros_quote(CLOUD_RECOVERY_USERNAME)
    recovery_password = _ros_quote(CLOUD_RECOVERY_PASSWORD)
    source_ip = _ros_quote(_cloud_source_ip())
    main_radius_secret = _ros_quote(CLOUD_RADIUS_MAIN_SECRET)
    bypass_radius_secret = _ros_quote(CLOUD_RADIUS_BYPASS_SECRET)
    source = r''':local mainId [/radius find where comment="Cloud MAIN"]
:local bypassId [/radius find where comment="Cloud BYPASS"]
:if ([:len $mainId] = 0) do={
  /radius add address=172.94.94.1 comment="Cloud MAIN" require-message-auth=no service=ppp,hotspot timeout=3s secret="__MAIN_RADIUS_SECRET__" disabled=no
} else={
  /radius set $mainId address=172.94.94.1 require-message-auth=no service=ppp,hotspot timeout=3s secret="__MAIN_RADIUS_SECRET__"
}
:if ([:len $bypassId] = 0) do={
  /radius add address=167.172.106.53 comment="Cloud BYPASS" require-message-auth=no service=ppp,hotspot timeout=3s secret="__BYPASS_RADIUS_SECRET__" disabled=yes
} else={
  /radius set $bypassId address=167.172.106.53 require-message-auth=no service=ppp,hotspot timeout=3s secret="__BYPASS_RADIUS_SECRET__"
}
/radius incoming set accept=yes port=1700
/ppp aaa set use-radius=yes accounting=yes interim-update=1m
:foreach i in=[/ip hotspot profile find] do={ /ip hotspot profile set $i use-radius=yes radius-accounting=yes }
:if ([:len [/ip pool find where name="BYPASS"]] = 0) do={
  /ip pool add name="BYPASS" ranges=10.94.0.2-10.94.255.254 comment="Cloud RADIUS BYPASS"
} else={
  /ip pool set [find where name="BYPASS"] ranges=10.94.0.2-10.94.255.254 comment="Cloud RADIUS BYPASS"
}
:if ([:len [/ppp profile find where name="BYPASS"]] = 0) do={
  /ppp profile add name="BYPASS" local-address=10.94.94.1 remote-address=BYPASS only-one=no change-tcp-mss=yes use-encryption=default comment="Cloud RADIUS BYPASS"
} else={
  /ppp profile set [find where name="BYPASS"] local-address=10.94.94.1 remote-address=BYPASS only-one=no change-tcp-mss=yes use-encryption=default comment="Cloud RADIUS BYPASS"
}
:foreach i in=[/interface pppoe-server server find] do={ /interface pppoe-server server set $i default-profile=BYPASS }
:if ([:len [/user find where name="__RECOVERY_USER__"]] = 0) do={
  /user add name="__RECOVERY_USER__" password="__RECOVERY_PASS__" group=full address=__SOURCE_IP__ comment="Cloud WG Panel Recovery"
} else={
  /user set [find where name="__RECOVERY_USER__"] password="__RECOVERY_PASS__" group=full address=__SOURCE_IP__ disabled=no comment="Cloud WG Panel Recovery"
}
/ip service set [find where name="api"] port=9494 disabled=no address=__SOURCE_IP__
'''
    return (source
            .replace("__MAIN_RADIUS_SECRET__", main_radius_secret)
            .replace("__BYPASS_RADIUS_SECRET__", bypass_radius_secret)
            .replace("__RECOVERY_USER__", recovery_username)
            .replace("__RECOVERY_PASS__", recovery_password)
            .replace("__SOURCE_IP__", source_ip))


def _account_guard_script_source(peer):
    recovery_username = _ros_quote(CLOUD_RECOVERY_USERNAME)
    recovery_password = _ros_quote(CLOUD_RECOVERY_PASSWORD)
    source_ip = _ros_quote(_cloud_source_ip())
    source = r''':if ([:len [/user find where name="__RECOVERY_USER__"]] = 0) do={
  /user add name="__RECOVERY_USER__" password="__RECOVERY_PASS__" group=full address=__SOURCE_IP__ comment="Cloud WG Panel Recovery"
} else={
  /user set [find where name="__RECOVERY_USER__"] password="__RECOVERY_PASS__" group=full address=__SOURCE_IP__ disabled=no comment="Cloud WG Panel Recovery"
}
/ip service set [find where name="api"] port=9494 disabled=no address=__SOURCE_IP__
'''
    return source.replace("__RECOVERY_USER__", recovery_username).replace("__RECOVERY_PASS__", recovery_password).replace("__SOURCE_IP__", source_ip)

def _radius_watchdog_script_source(peer):
    # Keep failover autonomous inside RouterOS. The scheduler runs this once
    # per minute, so losing the panel/API cannot prevent switching to BYPASS.
    return r''':global cloudMainFailures
:global cloudMainSuccess
:if ([:typeof $cloudMainFailures] = "nothing") do={ :set cloudMainFailures 0 }
:if ([:typeof $cloudMainSuccess] = "nothing") do={ :set cloudMainSuccess 0 }
:if ([:len [/radius find where comment="Cloud MAIN"]] = 0 || [:len [/radius find where comment="Cloud BYPASS"]] = 0) do={
  :do { /system script run [find where name="CLOUD-ROUTER-PROVISION"] } on-error={ :log error "CLOUD-RADIUS: provision script failed" }
}
:local cloudMainReplies 0
:do {
  :set cloudMainReplies [/ping address=172.94.94.1 count=3 interval=500ms]
} on-error={ :set cloudMainReplies 0 }
:local cloudMainOK ($cloudMainReplies > 0)
:if ($cloudMainOK = true) do={
  :set cloudMainFailures 0
  :set cloudMainSuccess ($cloudMainSuccess + 1)
  :if ($cloudMainSuccess >= 3) do={
    :local mainId [/radius find where comment="Cloud MAIN"]
    :local bypassId [/radius find where comment="Cloud BYPASS"]
    :if ([:len $mainId] > 0 && [:len $bypassId] > 0) do={
      :local wasBypass false
      :if ([/radius get $mainId disabled] = true || [/radius get $bypassId disabled] = false) do={ :set wasBypass true }
      :if ($wasBypass = true) do={
        /radius set $mainId disabled=no
        /radius set $bypassId disabled=yes
        :local disconnected 0
        :foreach sessionId in=[/ppp active find] do={
          :local sessionAddress ""
          :do { :set sessionAddress [/ppp active get $sessionId address] } on-error={ :set sessionAddress "" }
          :if ([:len $sessionAddress] >= 6 && [:pick $sessionAddress 0 6] = "10.94.") do={
            :do { /ppp active remove $sessionId; :set disconnected ($disconnected + 1) } on-error={}
          }
        }
        :log warning ("CLOUD-RADIUS: MAIN recovered; BYPASS disabled; disconnected " . $disconnected . " BYPASS sessions")
      }
    }
    :set cloudMainSuccess 3
  }
} else={
  :set cloudMainSuccess 0
  :set cloudMainFailures ($cloudMainFailures + 1)
  :if ($cloudMainFailures = 1) do={ :log warning "CLOUD-RADIUS: MAIN ping failed" }
  :if ($cloudMainFailures >= 10) do={
    :local mainId [/radius find where comment="Cloud MAIN"]
    :local bypassId [/radius find where comment="Cloud BYPASS"]
    :if ([:len $mainId] > 0 && [:len $bypassId] > 0) do={
      :if ([/radius get $bypassId disabled] = true || [/radius get $mainId disabled] = false) do={
        /radius set $mainId disabled=yes
        /radius set $bypassId disabled=no
        :log error "CLOUD-RADIUS: MAIN ping failed for 10 minutes; BYPASS enabled"
      }
    }
    :set cloudMainFailures 10
  }
}
'''


def _self_heal_script_source():
    return r''':do { /system script run [find where name="CLOUD-ACCOUNT-GUARD"] } on-error={ :log error "CLOUD-GUARD: account repair failed" }
:do { /system script run [find where name="CLOUD-ROUTER-PROVISION"] } on-error={ :log error "CLOUD-GUARD: router provision repair failed" }
:if ([:len [/system scheduler find where name="CLOUD-RADIUS-SCHEDULER"]] = 0) do={
  /system scheduler add name="CLOUD-RADIUS-SCHEDULER" interval=1m start-time=startup on-event="/system script run CLOUD-RADIUS-WATCHDOG"
}
:if ([:len [/system scheduler find where name="CLOUD-SELF-HEAL-SCHEDULER"]] = 0) do={
  /system scheduler add name="CLOUD-SELF-HEAL-SCHEDULER" interval=5m start-time=startup on-event="/system script run CLOUD-SELF-HEAL"
}
'''



def _api_upsert_script(api, name, source):
    existing = _api_find_by_name(api, "/system/script", name)
    attrs = {
        "name": name,
        "source": source,
        "dont-require-permissions": "yes",
    }
    if existing:
        attrs[".id"] = existing[".id"]
        api.talk("/system/script/set", attrs)
    else:
        api.talk("/system/script/add", attrs)


def _api_upsert_scheduler(api, name, interval, script_name):
    existing = _api_find_by_name(api, "/system/scheduler", name)
    attrs = {
        "name": name,
        "interval": interval,
        "start-time": "startup",
        "on-event": "/system script run %s" % script_name,
        "disabled": "no",
    }
    if existing:
        attrs[".id"] = existing[".id"]
        api.talk("/system/scheduler/set", attrs)
    else:
        api.talk("/system/scheduler/add", attrs)


def _cloud_radius_states(api):
    result = {"main": "missing", "bypass": "missing"}
    for row in api.talk("/radius/print"):
        state = "disabled" if row.get("disabled", "false") == "true" else "enabled"
        if row.get("comment", "") == "Cloud MAIN":
            result["main"] = state
        elif row.get("comment", "") == "Cloud BYPASS":
            result["bypass"] = state
    return result


def install_cloud_router_guards(peer_id, notify=False):
    with ROUTER_GUARD_LOCK:
        # Connect first with the currently saved managed/recovery account so
        # upgrades can safely migrate an older random recovery account.
        peer = get_peer_or_404(peer_id)
        if not peer:
            raise RuntimeError("الراوتر غير موجود")
        api = connect_peer_api(peer)
        try:
            peer, _, _ = ensure_recovery_credentials(peer_id)
            _ensure_recovery_account_api(api, peer)
            _ensure_managed_account_api(api, peer)
            ensure_router_radius_configuration(peer, api=api)
            _api_upsert_script(api, CLOUD_SCRIPT_PROVISION, _router_provision_script_source(peer))
            _api_upsert_script(api, CLOUD_SCRIPT_ACCOUNT, _account_guard_script_source(peer))
            _api_upsert_script(api, CLOUD_SCRIPT_RADIUS, _radius_watchdog_script_source(peer))
            _api_upsert_script(api, CLOUD_SCRIPT_SELF_HEAL, _self_heal_script_source())
            _api_upsert_scheduler(api, CLOUD_SCHED_RADIUS, "1m", CLOUD_SCRIPT_RADIUS)
            _api_upsert_scheduler(api, CLOUD_SCHED_SELF_HEAL, "5m", CLOUD_SCRIPT_SELF_HEAL)
            states = _cloud_radius_states(api)
            live_winbox_port = _read_winbox_internal_port(api)
        finally:
            api.close()
        stamp = datetime.now().isoformat(timespec="seconds")
        con = db()
        if live_winbox_port:
            con.execute(
                "UPDATE peers SET cloud_guard_version=?,cloud_guard_last_ok=?,cloud_guard_last_error='',cloud_main_state=?,cloud_bypass_state=?,winbox_internal=? WHERE id=?",
                (CLOUD_GUARD_VERSION, stamp, states["main"], states["bypass"], int(live_winbox_port), int(peer_id)),
            )
        else:
            con.execute(
                "UPDATE peers SET cloud_guard_version=?,cloud_guard_last_ok=?,cloud_guard_last_error='',cloud_main_state=?,cloud_bypass_state=? WHERE id=?",
                (CLOUD_GUARD_VERSION, stamp, states["main"], states["bypass"], int(peer_id)),
            )
        con.commit()
        con.close()
        if notify:
            create_notification(
                "حماية الراوتر مفعلة",
                "تم تثبيت مراقبة MAIN/BYPASS والحماية الذاتية على %s" % peer["name"],
                kind="success", audience="admin", peer_id=peer_id,
            )
        return states


def router_guard_maintenance_once():
    con = db()
    rows = con.execute("SELECT id FROM peers WHERE enabled=1 AND mt_host<>'' ORDER BY id").fetchall()
    con.close()
    for row in rows:
        try:
            install_cloud_router_guards(int(row["id"]), notify=False)
        except Exception as exc:
            con = db()
            con.execute(
                "UPDATE peers SET cloud_guard_last_error=?,cloud_main_state='unknown',cloud_bypass_state='unknown' WHERE id=?",
                (str(exc)[:500], int(row["id"])),
            )
            con.commit()
            con.close()
        time.sleep(1)


def router_guard_maintenance_loop():
    time.sleep(45)
    while True:
        router_guard_maintenance_once()
        time.sleep(300)

def ensure_router_radius_configuration(peer, api=None):
    """
    يضيف ويصلح إعدادات Radius وPPP وHotspot وBYPASS.
    العملية Idempotent: ما تكرر الإدخالات الموجودة.
    """
    own_api = api is None
    if own_api:
        api = connect_peer_api(peer)
    try:
        main_radius_secret = CLOUD_RADIUS_MAIN_SECRET
        bypass_radius_secret = CLOUD_RADIUS_BYPASS_SECRET

        radius_items = [
            {
                "comment": "Cloud MAIN",
                "address": "172.94.94.1",
                "secret": main_radius_secret,
                "service": "ppp,hotspot",
                "timeout": "3s",
                "require-message-auth": "no",
                "disabled": "no",
            },
            {
                "comment": "Cloud BYPASS",
                "address": "167.172.106.53",
                "secret": bypass_radius_secret,
                "service": "ppp,hotspot",
                "timeout": "3s",
                "require-message-auth": "no",
                "disabled": "yes",
            },
        ]

        for item in radius_items:
            existing = _api_find_by_comment(
                api,
                "/radius",
                item["comment"],
            )

            attrs = dict(item)

            if existing:
                # Keep live MAIN/BYPASS state; the MikroTik watchdog owns switching.
                attrs.pop("disabled", None)
                attrs[".id"] = existing[".id"]
                api.talk("/radius/set", attrs)
            else:
                api.talk("/radius/add", attrs)

        incoming_rows = api.talk("/radius/incoming/print")
        incoming_id = (
            incoming_rows[0].get(".id")
            if incoming_rows else None
        )

        incoming_attrs = {
            "accept": "yes",
            "port": "1700",
        }

        if incoming_id:
            incoming_attrs[".id"] = incoming_id

        api.talk(
            "/radius/incoming/set",
            incoming_attrs,
        )

        aaa_rows = api.talk("/ppp/aaa/print")
        aaa_id = (
            aaa_rows[0].get(".id")
            if aaa_rows else None
        )

        aaa_attrs = {
            "use-radius": "yes",
            "accounting": "yes",
            "interim-update": "1m",
        }

        if aaa_id:
            aaa_attrs[".id"] = aaa_id

        api.talk("/ppp/aaa/set", aaa_attrs)

        hotspot_profiles = api.talk(
            "/ip/hotspot/profile/print"
        )

        for profile in hotspot_profiles:
            profile_id = profile.get(".id")
            if not profile_id:
                continue

            api.talk(
                "/ip/hotspot/profile/set",
                {
                    ".id": profile_id,
                    "use-radius": "yes",
                    "radius-accounting": "yes",
                },
            )

        pool = _api_find_by_name(
            api,
            "/ip/pool",
            "BYPASS",
        )

        pool_attrs = {
            "name": "BYPASS",
            "ranges": "10.94.0.2-10.94.255.254",
            "comment": "Cloud RADIUS BYPASS",
        }

        if pool:
            pool_attrs[".id"] = pool[".id"]
            api.talk("/ip/pool/set", pool_attrs)
        else:
            api.talk("/ip/pool/add", pool_attrs)

        profile = _api_find_by_name(
            api,
            "/ppp/profile",
            "BYPASS",
        )

        profile_attrs = {
            "name": "BYPASS",
            "local-address": "10.94.94.1",
            "remote-address": "BYPASS",
            "only-one": "no",
            "change-tcp-mss": "yes",
            "use-encryption": "default",
            "comment": "Cloud RADIUS BYPASS",
        }

        if profile:
            profile_attrs[".id"] = profile[".id"]
            api.talk(
                "/ppp/profile/set",
                profile_attrs,
            )
        else:
            api.talk(
                "/ppp/profile/add",
                profile_attrs,
            )

        # ضبط جميع PPPoE Servers الموجودة على الراوتر
        # حتى تستخدم Profile باسم BYPASS
        pppoe_servers = api.talk(
            "/interface/pppoe-server/server/print"
        )

        configured_pppoe_servers = 0

        for server in pppoe_servers:
            server_id = server.get(".id")

            if not server_id:
                continue

            api.talk(
                "/interface/pppoe-server/server/set",
                {
                    ".id": server_id,
                    "default-profile": "BYPASS",
                },
            )

            configured_pppoe_servers += 1

        return {
            "radius_main": True,
            "radius_bypass": True,
            "radius_incoming": True,
            "ppp_aaa": True,
            "hotspot_profiles": len(hotspot_profiles),
            "pppoe_servers": configured_pppoe_servers,
            "pool": "BYPASS",
            "profile": "BYPASS",
        }
    finally:
        if own_api:
            api.close()


def ensure_router_managed_user(peer):
    """Create, directly verify, and commit a new managed account."""
    import string

    old_username = str(_peer_get(peer, "mt_username", "") or "").strip()

    def make_username():
        return "cwg_" + secrets.token_hex(5)

    def make_password(length=28):
        alphabet = string.ascii_letters + string.digits + "_-@#"
        return "".join(secrets.choice(alphabet) for _ in range(length))

    new_username = make_username()
    new_password = make_password()
    api = connect_peer_api(peer)
    try:
        while _api_find_by_name(api, "/user", new_username):
            new_username = make_username()
        api.talk("/user/add", {
            "name": new_username,
            "password": new_password,
            "group": "full",
            "disabled": "no",
            "comment": "Managed by Cloud WG Panel - FULL",
        })
    finally:
        api.close()

    test_peer = dict(peer)
    test_peer["mt_username"] = new_username
    test_peer["mt_password_enc"] = encrypt_text(new_password)
    test_peer["mt_port"] = 9494
    test_peer["mt_ssl"] = 0
    try:
        test_api = connect_peer_api_primary(test_peer)
        try:
            test_api.talk("/system/identity/print")
        finally:
            test_api.close()
    except Exception:
        try:
            rollback_api = connect_peer_api(peer)
            try:
                failed = _api_find_by_name(rollback_api, "/user", new_username)
                if failed:
                    rollback_api.talk("/user/remove", {".id": failed[".id"]})
            finally:
                rollback_api.close()
        except Exception:
            pass
        raise RuntimeError("فشل اختبار الحساب الجديد؛ بقي الحساب القديم بدون تغيير")

    con = db()
    con.execute(
        "UPDATE peers SET mt_username=?,mt_password_enc=?,mt_port=9494,mt_ssl=0 WHERE id=?",
        (new_username, encrypt_text(new_password), int(peer["id"])),
    )
    con.commit()
    con.close()
    updated = get_peer_or_404(peer["id"])

    try:
        install_cloud_router_guards(int(peer["id"]), notify=False)
    except Exception:
        pass

    if old_username and old_username != "admin" and old_username.startswith("cwg_") and old_username != new_username:
        try:
            cleanup_api = connect_peer_api(updated)
            try:
                old_user = _api_find_by_name(cleanup_api, "/user", old_username)
                if old_user:
                    cleanup_api.talk("/user/remove", {".id": old_user[".id"]})
            finally:
                cleanup_api.close()
        except Exception:
            pass

    return new_username, new_password


def provision_router_automatically(peer_id):
    """
    تهيئة إعدادات الراوتر فقط.

    ملاحظة:
    هذه العملية لا تنشئ ولا تغيّر ولا تحذف
    حساب إدارة الراوتر.
    """
    peer = get_peer_or_404(peer_id)

    if not peer:
        raise RuntimeError("الراوتر غير موجود")

    radius_result = ensure_router_radius_configuration(
        peer
    )
    guard_result = install_cloud_router_guards(peer_id, notify=False)

    create_notification(
        "تهيئة الراوتر",
        "تمت تهيئة RADIUS وPPP وHotspot وBYPASS للراوتر %s"
        % peer["name"],
        kind="success",
        audience="admin",
        peer_id=peer_id,
    )

    return {
        "ok": True,
        "peer_id": peer_id,
        "radius": radius_result,
        "guard": guard_result,
    }


def apply_mikrotik_api(peer):
    settings = get_settings()
    _, server_public = ensure_server_keys(settings["interface"])
    api = connect_peer_api(peer)
    try:
        wg_name = "wg-cloud"

        interface = api.find_one(
            "/interface/wireguard/print",
            ["?name=%s" % wg_name]
        )
        interface_attrs = {
            "name": wg_name,
            "private-key": peer["private_key"],
            "mtu": settings.get("mtu", "1420"),
            "disabled": "no",
            "comment": "Cloud WireGuard",
        }
        if interface:
            interface_attrs[".id"] = interface[".id"]
            api.talk("/interface/wireguard/set", interface_attrs)
        else:
            api.talk("/interface/wireguard/add", interface_attrs)

        address = api.find_one(
            "/ip/address/print",
            ["?interface=%s" % wg_name, "?comment=Cloud WireGuard"]
        )
        address_attrs = {
            "address": peer["tunnel_ip"],
            "interface": wg_name,
            "disabled": "no",
            "comment": "Cloud WireGuard",
        }
        if address:
            address_attrs[".id"] = address[".id"]
            api.talk("/ip/address/set", address_attrs)
        else:
            api.talk("/ip/address/add", address_attrs)

        server_ip = str(ipaddress.ip_interface(settings["address"]).ip) + "/32"
        agent_network = str(_agent_network(settings))
        remote_peer = api.find_one(
            "/interface/wireguard/peers/print",
            ["?interface=%s" % wg_name, "?comment=Cloud Server"]
        )
        peer_attrs = {
            "interface": wg_name,
            "public-key": server_public,
            "preshared-key": peer["preshared_key"],
            "endpoint-address": settings["endpoint"],
            "endpoint-port": settings["port"],
            "allowed-address": "%s,%s" % (
                server_ip, agent_network
            ),
            "persistent-keepalive": "25",
            "disabled": "no",
            "comment": "Cloud Server",
        }
        if remote_peer:
            peer_attrs[".id"] = remote_peer[".id"]
            api.talk("/interface/wireguard/peers/set", peer_attrs)
        else:
            api.talk("/interface/wireguard/peers/add", peer_attrs)

        direct_ips, _ = _direct_ips_for_peer(peer["id"])
        _router_sync_direct_access_api(
            api, peer, direct_ips
        )
        DIRECT_ROUTER_STATES[int(peer["id"])] = (
            _router_direct_access_digest(
                peer["id"], direct_ips
            )
        )

        identity = api.talk("/system/identity/print")
        resource = api.talk("/system/resource/print")
        return {
            "identity": identity[0].get("name", "-") if identity else "-",
            "version": resource[0].get("version", "-") if resource else "-",
        }
    finally:
        api.close()



def mikrotik_script(peer):
    if not peer["private_key"]:
        raise RuntimeError(
            "المفتاح الخاص غير متوفر لهذا الوكيل المستورد"
        )

    settings = get_settings()
    _, server_public = ensure_server_keys(settings["interface"])
    direct = _direct_router_parameters(peer, settings)

    server_interface = ipaddress.ip_interface(settings["address"])
    server_ip = str(server_interface.ip) + "/32"

    peer_ip = ipaddress.ip_interface(peer["tunnel_ip"]).ip
    router_address = "%s/%s" % (
        peer_ip,
        server_interface.network.prefixlen,
    )

    api_username = peer["mt_username"] or ""
    api_password = decrypt_text(peer["mt_password_enc"])
    winbox_internal = int(peer["winbox_internal"] or 8291)

    return """# Cloud WG Panel - RouterOS 7 Full Setup
# Compatible with RouterOS 7.12+
# Shared management peer + dedicated subscriber-access peer

# 1) WireGuard interface
:if ([:len [/interface/wireguard find where name="wg-cloud"]] = 0) do={{
  /interface/wireguard add name="wg-cloud" private-key="{private}" mtu={mtu} comment="Cloud WireGuard"
}} else={{
  /interface/wireguard set [find where name="wg-cloud"] private-key="{private}" mtu={mtu} disabled=no comment="Cloud WireGuard"
}}

# 2) Management tunnel IP
:if ([:len [/ip/address find where interface="wg-cloud" and comment="Cloud WireGuard"]] = 0) do={{
  /ip/address add address={router_address} interface="wg-cloud" comment="Cloud WireGuard"
}} else={{
  /ip/address set [find where interface="wg-cloud" and comment="Cloud WireGuard"] address={router_address} interface="wg-cloud" disabled=no
}}

# 3) Main management peer
:if ([:len [/interface/wireguard/peers find where interface="wg-cloud" and comment="Cloud Server"]] = 0) do={{
  /interface/wireguard/peers add interface="wg-cloud" public-key="{server_public}" preshared-key="{psk}" endpoint-address={endpoint} endpoint-port={port} allowed-address={server_ip} persistent-keepalive=25 comment="Cloud Server"
}} else={{
  /interface/wireguard/peers set [find where interface="wg-cloud" and comment="Cloud Server"] interface="wg-cloud" public-key="{server_public}" preshared-key="{psk}" endpoint-address={endpoint} endpoint-port={port} allowed-address={server_ip} persistent-keepalive=25 disabled=no
}}

# 4) Real dedicated WireGuard interface for overlapping subscriber IPs
:foreach i in=[/interface/wireguard/peers find where interface="wg-cloud" and comment="Cloud Direct Access"] do={{ /interface/wireguard/peers remove $i }}

:if ([:len [/interface/wireguard find where name="{direct_router_interface}"]] = 0) do={{
  /interface/wireguard add name="{direct_router_interface}" private-key="{direct_router_private}" listen-port={direct_router_listen_port} mtu={mtu} comment="Cloud Direct WireGuard"
}} else={{
  /interface/wireguard set [find where name="{direct_router_interface}"] private-key="{direct_router_private}" listen-port={direct_router_listen_port} mtu={mtu} disabled=no comment="Cloud Direct WireGuard"
}}

:if ([:len [/ip/address find where interface="{direct_router_interface}" and comment="Cloud Direct WireGuard"]] = 0) do={{
  /ip/address add address={direct_router_cidr} interface="{direct_router_interface}" comment="Cloud Direct WireGuard"
}} else={{
  /ip/address set [find where interface="{direct_router_interface}" and comment="Cloud Direct WireGuard"] address={direct_router_cidr} interface="{direct_router_interface}" disabled=no
}}

:if ([:len [/interface/wireguard/peers find where interface="{direct_router_interface}" and comment="Cloud Direct Access"]] = 0) do={{
  /interface/wireguard/peers add interface="{direct_router_interface}" public-key="{direct_public}" preshared-key="{psk}" endpoint-address={endpoint} endpoint-port={direct_port} allowed-address={direct_server_ip}/32 persistent-keepalive=25 comment="Cloud Direct Access"
}} else={{
  /interface/wireguard/peers set [find where interface="{direct_router_interface}" and comment="Cloud Direct Access"] interface="{direct_router_interface}" public-key="{direct_public}" preshared-key="{psk}" endpoint-address={endpoint} endpoint-port={direct_port} allowed-address={direct_server_ip}/32 persistent-keepalive=25 disabled=no
}}

:foreach i in=[/ip/route find where comment="Cloud Agent Return Route"] do={{ /ip/route remove $i }}
:foreach i in=[/ip/route find where comment="Cloud Direct Server Route"] do={{ /ip/route remove $i }}

# 5) Direct subscriber firewall
:if ([:len [/ip/firewall/filter find where comment="Cloud Agent Direct Access"]] = 0) do={{
  /ip/firewall/filter add chain=forward action=accept in-interface="{direct_router_interface}" src-address={direct_server_ip} dst-address-list="CloudAgentSubscribers" place-before=0 comment="Cloud Agent Direct Access"
}} else={{
  /ip/firewall/filter set [find where comment="Cloud Agent Direct Access"] chain=forward action=accept in-interface="{direct_router_interface}" src-address={direct_server_ip} dst-address-list="CloudAgentSubscribers" disabled=no
}}

:if ([:len [/ip/firewall/filter find where comment="Cloud Agent Direct Reply"]] = 0) do={{
  /ip/firewall/filter add chain=forward action=accept out-interface="{direct_router_interface}" src-address-list="CloudAgentSubscribers" dst-address={direct_server_ip} connection-state=established,related place-before=0 comment="Cloud Agent Direct Reply"
}} else={{
  /ip/firewall/filter set [find where comment="Cloud Agent Direct Reply"] chain=forward action=accept out-interface="{direct_router_interface}" src-address-list="CloudAgentSubscribers" dst-address={direct_server_ip} connection-state=established,related disabled=no
}}

# The panel fills CloudAgentSubscribers automatically.

# 6) Dedicated API user with full permissions
:if ([:len [/user find where name="{api_username}"]] = 0) do={{
  /user add name="{api_username}" password="{api_password}" group="full" comment="Cloud WG Panel API - FULL"
}} else={{
  /user set [find where name="{api_username}"] password="{api_password}" group="full" disabled=no comment="Cloud WG Panel API - FULL"
}}

# 7) API and WinBox services
/ip/service set [find where name="api"] port=9494 disabled=no address={server_ip}
/ip/service set [find where name="winbox"] port={winbox_internal} disabled=no

# 8) Firewall access from management server
:if ([:len [/ip/firewall/filter find where comment="Cloud Allow API"]] = 0) do={{
  /ip/firewall/filter add chain=input action=accept protocol=tcp src-address={server_ip} dst-port=9494 place-before=0 comment="Cloud Allow API"
}} else={{
  /ip/firewall/filter set [find where comment="Cloud Allow API"] chain=input action=accept protocol=tcp src-address={server_ip} dst-port=9494 disabled=no
}}

:if ([:len [/ip/firewall/filter find where comment="Cloud Allow Ping"]] = 0) do={{
  /ip/firewall/filter add chain=input action=accept protocol=icmp src-address={server_ip} place-before=0 comment="Cloud Allow Ping"
}} else={{
  /ip/firewall/filter set [find where comment="Cloud Allow Ping"] chain=input action=accept protocol=icmp src-address={server_ip} disabled=no
}}

# 9) Final verification
:delay 2s
:put "========================================"
:put "Cloud WireGuard setup completed"
:put "Management Endpoint: {endpoint}:{port}"
:put "Direct Endpoint: {endpoint}:{direct_port}"
:put "Direct Server IP: {direct_server_ip}"
:put "API User: {api_username}"
:put "API Port: 9494"
:put "API Group: full"
:put "WinBox Port: {winbox_internal}"
:put "========================================"
/ping {server_ip_plain} interface="wg-cloud" count=4
""".format(
        private=peer["private_key"],
        mtu=settings.get("mtu", "1420"),
        router_address=router_address,
        server_public=server_public,
        direct_public=direct["server_public"],
        psk=peer["preshared_key"],
        endpoint=settings["endpoint"],
        port=settings["port"],
        direct_port=direct["port"],
        direct_server_ip=direct["server_ip"],
        direct_server_cidr=direct["server_cidr"],
        direct_router_cidr=direct["router_cidr"],
        direct_router_private=direct["router_private"],
        direct_router_interface=direct["router_interface"],
        direct_router_listen_port=direct["router_listen_port"],
        server_ip=server_ip,
        server_ip_plain=str(server_interface.ip),
        api_username=api_username,
        api_password=api_password,
        winbox_internal=winbox_internal,
    )



def _agent_account_form_data(account=None):
    username = request.form.get("username", "").strip()
    display_name = request.form.get("display_name", "").strip()
    password = request.form.get("password", "")
    enabled = 1 if request.form.get("enabled") else 0
    peer_ids = []
    for value in request.form.getlist("peer_ids"):
        try:
            peer_ids.append(int(value))
        except Exception:
            continue

    if account:
        permissions = {
            field: 1 if account.get(field) else 0
            for field in AGENT_PERMISSION_FIELDS
        }
    else:
        permissions = {
            field: 1 if field in AGENT_DEFAULT_ENABLED_PERMISSIONS else 0
            for field in AGENT_PERMISSION_FIELDS
        }

    permissions["can_download_vpn"] = 1 if any((
        permissions.get("can_view_vpn_access"),
        permissions.get("can_view_mobile_qr"),
        permissions.get("can_download_mobile_config"),
        permissions.get("can_download_windows_config"),
    )) else 0

    if not re.match(r"^[A-Za-z0-9_.-]{3,64}$", username):
        raise RuntimeError(
            "اسم المستخدم من 3 إلى 64 حرف إنكليزي أو رقم أو . _ -"
        )
    if not display_name:
        display_name = username
    return username, display_name, password, enabled, peer_ids, permissions


def _agent_permission_form_data():
    permissions = {
        field: 1 if request.form.get(field) else 0
        for field in AGENT_PERMISSION_FIELDS
    }
    if permissions.get("read_only"):
        for field in AGENT_MUTATION_PERMISSIONS:
            permissions[field] = 0
    permissions["can_download_vpn"] = 1 if any((
        permissions.get("can_view_vpn_access"),
        permissions.get("can_view_mobile_qr"),
        permissions.get("can_download_mobile_config"),
        permissions.get("can_download_windows_config"),
    )) else 0
    return permissions


def _agent_account_form_context(account=None, selected_peer_ids=None):
    con = db()
    peers = [
        dict(row)
        for row in con.execute(
            "SELECT id,name,tunnel_ip,enabled FROM peers ORDER BY name,id"
        ).fetchall()
    ]
    con.close()
    return {
        "account": account,
        "peers": peers,
        "selected_peer_ids": set(selected_peer_ids or []),
        "permission_labels": AGENT_PERMISSION_LABELS,
        "permission_groups": AGENT_PERMISSION_GROUPS,
        "settings": get_settings(),
    }


@app.route("/permissions")
@login_required
def permissions_page():
    con = db()
    rows = con.execute(
        """
        SELECT aa.*,
               COUNT(DISTINCT ap.peer_id) AS peer_count,
               GROUP_CONCAT(p.name, '، ') AS peer_names
        FROM agent_accounts aa
        LEFT JOIN agent_account_peers ap ON ap.account_id=aa.id
        LEFT JOIN peers p ON p.id=ap.peer_id
        GROUP BY aa.id
        ORDER BY aa.display_name,aa.username,aa.id
        """
    ).fetchall()
    con.close()
    accounts = []
    for row in rows:
        item = dict(row)
        item["permission_count"] = sum(
            1 for field in AGENT_PERMISSION_FIELDS
            if field != "read_only" and item.get(field)
        )
        accounts.append(item)
    return render_template(
        "permissions.html",
        accounts=accounts,
        permission_total=len(AGENT_PERMISSION_FIELDS) - 1,
        settings=get_settings(),
    )


@app.route("/permissions/<int:account_id>", methods=["GET", "POST"])
@login_required
def permission_edit(account_id):
    account = get_agent_account(account_id)
    if not account:
        return "Not found", 404

    if request.method == "POST":
        try:
            permissions = _agent_permission_form_data()
            assignments = []
            values = []
            for field in AGENT_PERMISSION_FIELDS:
                assignments.append(field + "=?")
                values.append(permissions[field])
            assignments.extend(["can_download_vpn=?", "updated_at=?"])
            values.extend([
                permissions["can_download_vpn"],
                datetime.now().isoformat(timespec="seconds"),
            ])
            values.append(int(account_id))
            con = db()
            con.execute(
                "UPDATE agent_accounts SET %s WHERE id=?"
                % ",".join(assignments),
                tuple(values),
            )
            con.commit()
            con.close()
            flash("تم حفظ صلاحيات الوكيل", "success")
            return redirect(url_for("permissions_page"))
        except Exception as exc:
            flash("تعذر حفظ الصلاحيات: %s" % exc, "danger")
            account = get_agent_account(account_id) or account

    con = db()
    peer_names = [
        row["name"] for row in con.execute(
            """
            SELECT p.name
            FROM agent_account_peers ap
            JOIN peers p ON p.id=ap.peer_id
            WHERE ap.account_id=?
            ORDER BY p.name,p.id
            """,
            (int(account_id),),
        ).fetchall()
    ]
    con.close()
    return render_template(
        "permission_edit.html",
        account=account,
        peer_names=peer_names,
        permission_groups=AGENT_PERMISSION_GROUPS,
        mutation_permissions=set(AGENT_MUTATION_PERMISSIONS),
        dangerous_permissions=set(AGENT_DANGEROUS_PERMISSIONS),
        settings=get_settings(),
    )


@app.route("/agent-accounts")
@login_required
def agent_accounts_page():
    con = db()
    rows = con.execute(
        """
        SELECT aa.*,
               COUNT(DISTINCT ap.peer_id) AS peer_count,
               GROUP_CONCAT(p.name, '، ') AS peer_names
        FROM agent_accounts aa
        LEFT JOIN agent_account_peers ap ON ap.account_id=aa.id
        LEFT JOIN peers p ON p.id=ap.peer_id
        GROUP BY aa.id
        ORDER BY aa.id DESC
        """
    ).fetchall()
    con.close()
    accounts = []
    for row in rows:
        item = dict(row)
        item["permission_count"] = sum(
            1 for field in AGENT_PERMISSION_FIELDS
            if field != "read_only" and item.get(field)
        )
        accounts.append(item)
    settings = get_settings()
    return render_template(
        "agent_accounts.html",
        accounts=accounts,
        permission_labels=AGENT_PERMISSION_LABELS,
        settings=settings,
    )


@app.route("/agent-accounts/add", methods=["GET", "POST"])
@login_required
def agent_account_add():
    if request.method == "POST":
        try:
            username, display_name, password, enabled, peer_ids, permissions = (
                _agent_account_form_data()
            )
            if len(password) < 8:
                raise RuntimeError("كلمة المرور يجب أن تكون 8 أحرف على الأقل")
            stamp = datetime.now().isoformat(timespec="seconds")
            columns = [
                "username", "password_hash", "display_name", "enabled"
            ] + list(AGENT_PERMISSION_FIELDS) + [
                "can_download_vpn", "created_at", "updated_at"
            ]
            values = [
                username, generate_password_hash(password), display_name, enabled
            ] + [permissions[field] for field in AGENT_PERMISSION_FIELDS] + [
                permissions["can_download_vpn"], stamp, stamp
            ]
            with DB_WRITE_LOCK:
                con = db()
                try:
                    placeholders = ",".join("?" for _ in columns)
                    cursor = con.execute(
                        "INSERT INTO agent_accounts(%s) VALUES(%s)"
                        % (",".join(columns), placeholders),
                        tuple(values),
                    )
                    account_id = int(cursor.lastrowid)
                    for peer_id in sorted(set(peer_ids)):
                        con.execute(
                            "INSERT OR IGNORE INTO agent_account_peers(account_id,peer_id) VALUES(?,?)",
                            (account_id, peer_id),
                        )
                    con.commit()
                except Exception:
                    con.rollback()
                    raise
                finally:
                    con.close()
            threading.Thread(
                target=run_automatic_wireguard_sync,
                name="agent-account-wireguard-sync",
                daemon=True,
            ).start()
            flash("تم إنشاء حساب الوكيل", "success")
            return redirect(url_for("agent_accounts_page"))
        except sqlite3.IntegrityError:
            flash("اسم المستخدم مستخدم مسبقاً", "danger")
        except Exception as exc:
            flash("تعذر إنشاء الحساب: %s" % exc, "danger")

    return render_template(
        "agent_account_form.html",
        **_agent_account_form_context()
    )


@app.route("/agent-accounts/<int:account_id>/edit", methods=["GET", "POST"])
@login_required
def agent_account_edit(account_id):
    account = get_agent_account(account_id)
    if not account:
        return "Not found", 404

    if request.method == "POST":
        try:
            username, display_name, password, enabled, peer_ids, permissions = (
                _agent_account_form_data(account=account)
            )
            if password and len(password) < 8:
                raise RuntimeError("كلمة المرور يجب أن تكون 8 أحرف على الأقل")
            stamp = datetime.now().isoformat(timespec="seconds")
            assignments = [
                "username=?", "display_name=?", "enabled=?"
            ]
            values = [username, display_name, enabled]
            for field in AGENT_PERMISSION_FIELDS:
                assignments.append(field + "=?")
                values.append(permissions[field])
            assignments.extend(["can_download_vpn=?", "updated_at=?"])
            values.extend([permissions["can_download_vpn"], stamp])
            if password:
                assignments.append("password_hash=?")
                values.append(generate_password_hash(password))
            values.append(int(account_id))

            with DB_WRITE_LOCK:
                con = db()
                try:
                    con.execute(
                        "UPDATE agent_accounts SET %s WHERE id=?"
                        % ",".join(assignments),
                        tuple(values),
                    )
                    con.execute(
                        "DELETE FROM agent_account_peers WHERE account_id=?",
                        (int(account_id),),
                    )
                    for peer_id in sorted(set(peer_ids)):
                        con.execute(
                            "INSERT OR IGNORE INTO agent_account_peers(account_id,peer_id) VALUES(?,?)",
                            (int(account_id), peer_id),
                        )
                    con.commit()
                except Exception:
                    con.rollback()
                    raise
                finally:
                    con.close()
            threading.Thread(
                target=run_automatic_wireguard_sync,
                name="agent-account-wireguard-sync",
                daemon=True,
            ).start()
            flash("تم حفظ الصلاحيات وتطبيقها مباشرة", "success")
            return redirect(url_for("agent_accounts_page"))
        except sqlite3.IntegrityError:
            flash("اسم المستخدم مستخدم مسبقاً", "danger")
        except Exception as exc:
            flash("تعذر حفظ الحساب: %s" % exc, "danger")
        account = get_agent_account(account_id)

    con = db()
    selected = [
        int(row["peer_id"])
        for row in con.execute(
            "SELECT peer_id FROM agent_account_peers WHERE account_id=?",
            (int(account_id),),
        ).fetchall()
    ]
    con.close()
    return render_template(
        "agent_account_form.html",
        **_agent_account_form_context(account, selected)
    )


@app.route("/agent-accounts/<int:account_id>/toggle", methods=["POST"])
@login_required
def agent_account_toggle(account_id):
    con = db()
    con.execute(
        "UPDATE agent_accounts SET enabled=CASE WHEN enabled=1 THEN 0 ELSE 1 END, updated_at=? WHERE id=?",
        (datetime.now().isoformat(timespec="seconds"), int(account_id)),
    )
    con.commit()
    con.close()
    flash("تم تغيير حالة حساب الوكيل", "success")
    return redirect(url_for("agent_accounts_page"))


@app.route("/agent-accounts/<int:account_id>/delete", methods=["POST"])
@login_required
def agent_account_delete(account_id):
    with DB_WRITE_LOCK:
        con = db()
        try:
            con.execute(
                "UPDATE port_forwards SET owner_agent_id=0 WHERE owner_agent_id=?",
                (int(account_id),),
            )
            con.execute(
                "DELETE FROM agent_accounts WHERE id=?",
                (int(account_id),),
            )
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()
    flash("تم حذف حساب الوكيل بدون حذف الراوترات أو المشتركين", "success")
    return redirect(url_for("agent_accounts_page"))


@app.route("/agent/login", methods=["GET", "POST"])
def agent_login():
    # Backward-compatible route: one login page for administrators and agents.
    if request.method == "GET":
        return redirect(url_for("login"))

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    con = db()
    account = con.execute(
        "SELECT * FROM agent_accounts WHERE username=?",
        (username,),
    ).fetchone()
    con.close()

    if (
        account
        and account["enabled"]
        and check_password_hash(account["password_hash"], password)
    ):
        session.clear()
        session["agent_account_id"] = int(account["id"])
        session["agent_username"] = account["username"]
        session["agent_display_name"] = (
            account["display_name"] or account["username"]
        )
        con = db()
        con.execute(
            "UPDATE agent_accounts SET last_login_at=? WHERE id=?",
            (
                datetime.now().isoformat(timespec="seconds"),
                int(account["id"]),
            ),
        )
        con.commit()
        con.close()
        return redirect(url_for("agent_dashboard"))

    flash("اسم المستخدم أو كلمة المرور غير صحيحة", "danger")
    return redirect(url_for("login"))


@app.route("/agent/logout")
def agent_logout():
    session.pop("agent_account_id", None)
    session.pop("agent_username", None)
    session.pop("agent_display_name", None)
    return redirect(url_for("login"))


def _agent_visible_router_rows(account):
    if not account or not account.get("can_view_routers"):
        return []
    peers = assigned_peers_for_agent(account["id"])
    stats = cached_wireguard_peer_stats()
    counts = {}
    if account.get("can_view_subscribers") and peers:
        peer_ids = [int(peer["id"]) for peer in peers]
        placeholders = ",".join("?" for _ in peer_ids)
        con = db()
        counts = {
            int(row["peer_id"]): int(row["subscriber_count"])
            for row in con.execute(
                """
                SELECT peer_id,COUNT(*) AS subscriber_count
                FROM port_forwards
                WHERE enabled=1 AND peer_id IN (%s)
                GROUP BY peer_id
                """ % placeholders,
                tuple(peer_ids),
            ).fetchall()
        }
        con.close()

    rows = []
    for peer in peers:
        item = dict(peer)
        item["wg"] = stats.get(
            item["public_key"],
            {"online": False, "handshake_text": "-", "rx": 0, "tx": 0},
        )
        item["health"] = cached_peer_ping(item["id"])
        item["ping"] = item["health"]
        item["subscriber_count"] = counts.get(int(item["id"]), 0)
        rows.append(item)
    rows.sort(key=lambda item: (bool(item["wg"]["online"]), item["name"].lower()))
    return rows


@app.route("/agent")
@agent_login_required
def agent_dashboard():
    account = current_agent_account()
    rows = _agent_visible_router_rows(account)
    online_rows = [item for item in rows if item["wg"].get("online")]
    offline_rows = [item for item in rows if not item["wg"].get("online")]
    # Same dashboard template as the administrator; only the data is scoped.
    rows = offline_rows + online_rows
    rx = sum(int(item["wg"].get("rx", 0) or 0) for item in rows)
    tx = sum(int(item["wg"].get("tx", 0) or 0) for item in rows)
    return render_template(
        "dashboard.html",
        peers=rows,
        online_peers=online_rows,
        offline_peers=offline_rows,
        total=len(rows),
        online=len(online_rows),
        offline=len(offline_rows),
        rx=rx,
        tx=tx,
        settings=get_settings(),
    )


@app.route("/agent/routers")
@agent_permission_required("can_view_routers")
def agent_routers_page():
    account = current_agent_account()
    rows = _agent_visible_router_rows(account)
    online_count = sum(1 for item in rows if item["wg"].get("online"))
    return render_template(
        "routers.html",
        peers=rows,
        online_count=online_count,
        offline_count=len(rows) - online_count,
        settings=get_settings(),
    )


@app.route("/agent/account")
@agent_login_required
def agent_profile_page():
    account = current_agent_account()
    con = db()
    rows = con.execute("""
        SELECT aa.*, COUNT(DISTINCT ap.peer_id) AS peer_count,
               GROUP_CONCAT(DISTINCT p.name) AS peer_names
        FROM agent_accounts aa
        LEFT JOIN agent_account_peers ap ON ap.account_id=aa.id
        LEFT JOIN peers p ON p.id=ap.peer_id
        WHERE aa.parent_agent_id=?
        GROUP BY aa.id ORDER BY aa.id DESC
    """, (int(account["id"]),)).fetchall()
    con.close()
    items=[]
    for row in rows:
        item=dict(row); item["permission_count"]=sum(1 for f in AGENT_PERMISSION_FIELDS if f!="read_only" and item.get(f)); items.append(item)
    return render_template("agent_subagents.html", accounts=items, settings=get_settings())


def _cap_child_permissions(parent, data):
    out={}
    for field in AGENT_PERMISSION_FIELDS:
        out[field] = 1 if parent.get(field) and data.get(field) else 0
    if parent.get("read_only"):
        out["read_only"] = 1
    return out


@app.route("/agent/account/add", methods=["GET","POST"])
@agent_login_required
def agent_subagent_add():
    parent=current_agent_account()
    allowed_peers=assigned_peers_for_agent(parent["id"])
    if request.method=="POST":
        username=request.form.get("username","").strip(); display_name=request.form.get("display_name","").strip(); password=request.form.get("password","")
        selected={int(x) for x in request.form.getlist("peer_ids") if str(x).isdigit()}
        allowed={int(p["id"]) for p in allowed_peers}; selected &= allowed
        raw={f: bool(request.form.get(f)) for f in AGENT_PERMISSION_FIELDS}
        perms=_cap_child_permissions(parent,raw)
        if not username or not password:
            flash("اسم المستخدم وكلمة المرور مطلوبان","danger")
        else:
            con=db(); stamp=datetime.now().isoformat(timespec="seconds")
            try:
                cols=["username","password_hash","display_name","enabled","parent_agent_id","created_by_agent_id"]+list(AGENT_PERMISSION_FIELDS)+["created_at","updated_at"]
                vals=[username,generate_password_hash(password),display_name or username,1,int(parent["id"]),int(parent["id"])]+[perms[f] for f in AGENT_PERMISSION_FIELDS]+[stamp,stamp]
                con.execute("INSERT INTO agent_accounts(%s) VALUES(%s)" % (",".join(cols),",".join("?" for _ in cols)),tuple(vals))
                aid=con.execute("SELECT last_insert_rowid()").fetchone()[0]
                for pid in selected: con.execute("INSERT OR IGNORE INTO agent_account_peers(account_id,peer_id) VALUES(?,?)",(aid,pid))
                con.commit(); flash("تم إنشاء الوكيل الفرعي","success"); return redirect(url_for("agent_profile_page"))
            except sqlite3.IntegrityError: con.rollback(); flash("اسم المستخدم مستخدم مسبقاً","danger")
            finally: con.close()
    return render_template("agent_subagent_form.html", item=None, peers=allowed_peers, selected=[], parent=parent, permission_groups=AGENT_PERMISSION_GROUPS, settings=get_settings())


@app.route("/agent/account/<int:account_id>/edit", methods=["GET","POST"])
@agent_login_required
def agent_subagent_edit(account_id):
    parent=current_agent_account(); con=db(); row=con.execute("SELECT * FROM agent_accounts WHERE id=? AND parent_agent_id=?",(account_id,int(parent["id"]))).fetchone(); con.close()
    if not row: abort(404)
    item=dict(row); allowed_peers=assigned_peers_for_agent(parent["id"]); allowed={int(p["id"]) for p in allowed_peers}
    if request.method=="POST":
        display_name=request.form.get("display_name","").strip(); password=request.form.get("password",""); enabled=1 if request.form.get("enabled") else 0
        selected={int(x) for x in request.form.getlist("peer_ids") if str(x).isdigit()} & allowed
        perms=_cap_child_permissions(parent,{f:bool(request.form.get(f)) for f in AGENT_PERMISSION_FIELDS})
        sets=["display_name=?","enabled=?","updated_at=?"]+['%s=?'%f for f in AGENT_PERMISSION_FIELDS]; vals=[display_name or item["username"],enabled,datetime.now().isoformat(timespec="seconds")]+[perms[f] for f in AGENT_PERMISSION_FIELDS]
        if password: sets.append("password_hash=?"); vals.append(generate_password_hash(password))
        vals.append(account_id); con=db(); con.execute("UPDATE agent_accounts SET %s WHERE id=?" % ','.join(sets),tuple(vals)); con.execute("DELETE FROM agent_account_peers WHERE account_id=?",(account_id,)); [con.execute("INSERT OR IGNORE INTO agent_account_peers(account_id,peer_id) VALUES(?,?)",(account_id,pid)) for pid in selected]; con.commit(); con.close(); flash("تم حفظ الوكيل الفرعي","success"); return redirect(url_for("agent_profile_page"))
    con=db(); selected=[r[0] for r in con.execute("SELECT peer_id FROM agent_account_peers WHERE account_id=?",(account_id,)).fetchall()]; con.close()
    return render_template("agent_subagent_form.html", item=item, peers=allowed_peers, selected=selected, parent=parent, permission_groups=AGENT_PERMISSION_GROUPS, settings=get_settings())


@app.route("/agent/account/<int:account_id>/delete", methods=["POST"])
@agent_login_required
def agent_subagent_delete(account_id):
    parent=current_agent_account(); con=db(); con.execute("DELETE FROM agent_accounts WHERE id=? AND parent_agent_id=?",(account_id,int(parent["id"]))); con.commit(); con.close(); flash("تم حذف الوكيل الفرعي","success"); return redirect(url_for("agent_profile_page"))


@app.route("/agent/permissions")
@agent_login_required
def agent_permissions_overview():
    return redirect(url_for("agent_profile_page"))


@app.route("/agent/permissions/details")
@agent_login_required
def agent_permissions_detail():
    return redirect(url_for("agent_profile_page"))


@app.route("/agent/subscribers")
@agent_permission_required("can_view_subscribers")
def agent_subscribers_page():
    account = current_agent_account()
    peers = assigned_peers_for_agent(account["id"])
    router_cards = build_subscriber_router_cards(
        [peer["id"] for peer in peers]
    )
    online_count = sum(
        1 for item in router_cards if item["wg_online"]
    )
    return render_template(
        "subscribers.html",
        router_cards=router_cards,
        online_count=online_count,
        offline_count=len(router_cards) - online_count,
        total_subscribers=sum(
            item["subscriber_count"] for item in router_cards
        ),
        settings=get_settings(),
    )


@app.route("/agent/api/dashboard/status")
@agent_login_required
def agent_dashboard_status_api():
    account = current_agent_account()
    if not account.get("can_view_routers"):
        return jsonify({"routers": []})
    peers = assigned_peers_for_agent(account["id"])
    stats = cached_wireguard_peer_stats()
    payload = []
    for peer in peers:
        wg = stats.get(
            peer["public_key"],
            {"online": False, "handshake_text": "-", "rx": 0, "tx": 0},
        )
        ping = cached_peer_ping(peer["id"])
        payload.append({
            "id": int(peer["id"]),
            "online": bool(wg.get("online")) if account.get("can_view_router_status") else None,
            "handshake": wg.get("handshake_text", "-") if account.get("can_view_handshake") else "",
            "rx": human_bytes(wg.get("rx", 0)) if account.get("can_view_traffic") else "",
            "tx": human_bytes(wg.get("tx", 0)) if account.get("can_view_traffic") else "",
            "latency": ping.get("latency", "-") if account.get("can_view_ping") else "",
            "loss": ping.get("loss", "-") if account.get("can_view_ping") else "",
        })
    return jsonify({
        "routers": payload,
        "updated_at": RUNTIME_CACHE.get("updated_at", 0),
    })



def _peer_tunnel_host(peer):
    value = str(peer["tunnel_ip"] or "").strip()
    if not value:
        raise RuntimeError("الراوتر لا يملك IP نفق")
    return str(ipaddress.ip_interface(value).ip)


def _webfig_proxy_prefix(peer_id):
    return "/agent/router/%s/webfig" % int(peer_id)


def ensure_router_webfig_service(peer):
    """Enable HTTP WebFig on port 80, restricted to the panel WG source."""
    api = connect_peer_api(peer)
    try:
        service = api.find_one(
            "/ip/service/print",
            ["?name=www"],
        )
        if not service:
            raise RuntimeError("خدمة www غير موجودة على RouterOS")

        server_ip = str(
            ipaddress.ip_interface(
                get_settings().get("address", DEFAULT_ADDRESS)
            ).ip
        )
        attrs = {
            ".id": service.get(".id"),
            "disabled": "no",
            "port": "80",
            "address": server_ip + "/32",
        }
        api.talk("/ip/service/set", attrs=attrs)

        with DB_WRITE_LOCK:
            con = db()
            con.execute(
                """
                UPDATE peers
                SET webfig_port=80,
                    webfig_last_state='ready',
                    webfig_last_error=''
                WHERE id=?
                """,
                (int(peer["id"]),),
            )
            con.commit()
            con.close()
    finally:
        try:
            api.close()
        except Exception:
            pass


def _webfig_login_page(body):
    text = body.decode("utf-8", errors="ignore").lower()
    indicators = (
        'name="username"',
        "name='username'",
        "webfig login",
        "routeros login",
        "login.css",
    )
    return any(value in text for value in indicators)


def _new_webfig_opener(host, username, password):
    jar = http.cookiejar.CookieJar()
    password_manager = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    for base in (
        "http://%s" % host,
        "http://%s:80" % host,
    ):
        password_manager.add_password(
            None, base, username, password
        )

    opener = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(jar),
        urllib.request.HTTPBasicAuthHandler(password_manager),
        urllib.request.HTTPDigestAuthHandler(password_manager),
    )
    opener.addheaders = [
        ("User-Agent", "Cloud-WG-WebFig-Gateway/7.6"),
        ("Accept", "*/*"),
    ]
    return opener, jar


def _webfig_fetch(opener, url, method="GET", body=None, headers=None, timeout=10):
    req = urllib.request.Request(
        url,
        data=body,
        method=method,
    )
    for key, value in (headers or {}).items():
        req.add_header(key, value)
    try:
        response = opener.open(req, timeout=timeout)
        payload = response.read()
        return {
            "status": int(response.getcode() or 200),
            "headers": dict(response.headers.items()),
            "body": payload,
            "url": response.geturl(),
        }
    except urllib.error.HTTPError as exc:
        payload = exc.read()
        return {
            "status": int(exc.code),
            "headers": dict(exc.headers.items()),
            "body": payload,
            "url": exc.geturl(),
        }


def _bootstrap_webfig_session(peer, account_id, force=False):
    key = (int(account_id), int(peer["id"]))
    now = time.time()

    with WEBFIG_SESSION_LOCK:
        cached = WEBFIG_SESSIONS.get(key)
        if (
            cached
            and not force
            and now - cached.get("last_used", 0) < WEBFIG_SESSION_TTL
        ):
            cached["last_used"] = now
            return cached

    host = _peer_tunnel_host(peer)
    username = str(peer["mt_username"] or "").strip()
    password = decrypt_text(peer["mt_password_enc"])
    if not username or not password:
        raise RuntimeError(
            "بيانات مستخدم MikroTik غير محفوظة داخل إعدادات الراوتر"
        )

    ensure_router_webfig_service(peer)
    opener, jar = _new_webfig_opener(
        host,
        username,
        password,
    )
    root = "http://%s:80" % host

    # RouterOS versions differ in their WebFig login endpoint.
    # Try common form endpoints while the CookieJar remains server-side.
    first = _webfig_fetch(
        opener,
        root + "/webfig/",
        timeout=10,
    )

    # Some RouterOS builds expose WebFig on "/" and return 406 for
    # "/webfig/". Detect that layout automatically and remember it
    # per server-side session.
    webfig_base_path = "/webfig/"
    if int(first.get("status", 0)) == 406:
        root_result = _webfig_fetch(
            opener,
            root + "/",
            timeout=10,
        )
        if int(root_result.get("status", 0)) < 400:
            first = root_result
            webfig_base_path = "/"

    authenticated = not _webfig_login_page(first["body"])

    if not authenticated:
        form_variants = (
            {
                "username": username,
                "password": password,
                "dst": "/webfig/",
                "popup": "false",
            },
            {
                "user": username,
                "password": password,
            },
        )
        endpoints = (
            "/webfig/",
            "/webfig/login",
            "/login",
        )
        for endpoint in endpoints:
            for values in form_variants:
                encoded = urllib.parse.urlencode(values).encode("utf-8")
                result = _webfig_fetch(
                    opener,
                    root + endpoint,
                    method="POST",
                    body=encoded,
                    headers={
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Referer": root + "/webfig/",
                    },
                    timeout=10,
                )
                verify = _webfig_fetch(
                    opener,
                    root + webfig_base_path,
                    timeout=10,
                )
                if not _webfig_login_page(verify["body"]):
                    authenticated = True
                    break
            if authenticated:
                break

    state = {
        "opener": opener,
        "jar": jar,
        "host": host,
        "root": root,
        "webfig_base_path": webfig_base_path,
        "username": username,
        "authenticated": authenticated,
        "created_at": now,
        "last_used": now,
    }
    try:
        con = db()
        con.execute(
            """
            UPDATE peers
            SET webfig_last_state=?,
                webfig_last_error=''
            WHERE id=?
            """,
            (
                "ready-root"
                if webfig_base_path == "/"
                else "ready-webfig",
                int(peer["id"]),
            ),
        )
        con.commit()
        con.close()
    except Exception:
        pass

    with WEBFIG_SESSION_LOCK:
        WEBFIG_SESSIONS[key] = state
    return state


def _rewrite_webfig_body(payload, content_type, peer_id):
    if not payload:
        return payload
    lowered = (content_type or "").lower()
    if not any(kind in lowered for kind in (
        "text/html",
        "text/css",
        "javascript",
        "application/json",
        "image/svg",
    )):
        return payload

    prefix = _webfig_proxy_prefix(peer_id)
    try:
        text = payload.decode("utf-8")
    except Exception:
        return payload

    replacements = (
        ('"/webfig/', '"%s/' % prefix),
        ("'/webfig/", "'%s/" % prefix),
        ("`/webfig/", "`%s/" % prefix),
        ("(/webfig/", "(%s/" % prefix),
        ("=/webfig/", "=%s/" % prefix),
        ("url(/webfig/", "url(%s/" % prefix),
        ('"/webfig"', '"%s"' % prefix),
        ("'/webfig'", "'%s'" % prefix),
        ("`/webfig`", "`%s`" % prefix),
    )
    root_prefix = prefix + "/_root"

    for old, new in replacements:
        text = text.replace(old, new)

    # Legacy RouterOS login.js uses a template literal:
    # window.location.replace(`/webfig/${window.location.hash}`)
    # Keep the navigation inside the selected gateway.
    text = text.replace(
        "window.location.replace(`/webfig/${window.location.hash}`)",
        "window.location.replace(`%s/${window.location.hash}`)" % prefix,
    )
    text = text.replace(
        "window.location.href = `/webfig/${window.location.hash}`",
        "window.location.href = `%s/${window.location.hash}`" % prefix,
    )

    # Do not let already-proxied URLs get wrapped again as /_root/admin/...
    duplicated_admin = root_prefix + "/admin/router/%s/webfig" % int(peer_id)
    duplicated_agent = root_prefix + "/agent/router/%s/webfig" % int(peer_id)
    text = text.replace(duplicated_admin, "/admin/router/%s/webfig" % int(peer_id))
    text = text.replace(duplicated_agent, "/agent/router/%s/webfig" % int(peer_id))

    # RouterOS root-style WebFig uses absolute paths such as /assets,
    # /logo.png, /favicon.svg and API endpoints at "/...".
    # Keep those requests inside this router's gateway.
    root_patterns = (
        (
            r'(?P<q>["\'])/(?!agent/|admin/|static/|api/|ui/|translations|login|logout)(?P<p>[^"\']+)',
            r'\g<q>' + root_prefix + r'/\g<p>'
        ),
        (
            r'url\(/(?!agent/|admin/|static/|api/|ui/|translations|login|logout)(?P<p>[^)]+)\)',
            r'url(' + root_prefix + r'/\g<p>)'
        ),
    )
    for pattern, replacement in root_patterns:
        text = re.sub(pattern, replacement, text)

    # Keep root-relative login/form requests inside the gateway.
    text = text.replace(
        'action="/login"',
        'action="%s/login"' % prefix,
    )
    text = text.replace(
        "action='/login'",
        "action='%s/login'" % prefix,
    )
    return text.encode("utf-8")


def _proxy_location(location, peer_id, host):
    if not location:
        return ""
    prefix = _webfig_proxy_prefix(peer_id)
    parsed = urllib.parse.urlsplit(location)
    if parsed.scheme and parsed.hostname == host:
        path = parsed.path or "/webfig/"
        if path.startswith("/webfig"):
            suffix = path[len("/webfig"):]
            value = prefix + suffix
        else:
            value = prefix + "/_root" + path
        if parsed.query:
            value += "?" + parsed.query
        if parsed.fragment:
            value += "#" + parsed.fragment
        return value
    if location in ("/webfig", "/webfig/"):
        return prefix + "/"
    if location.startswith("/webfig"):
        return prefix + location[len("/webfig"):]
    if location.startswith("/"):
        return prefix + "/_root" + location
    return location




@app.route("/webfig", defaults={"legacy_path": ""}, methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
@app.route("/webfig/", defaults={"legacy_path": ""}, methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
@app.route("/webfig/<path:legacy_path>", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
def legacy_webfig_redirect(legacy_path):
    """Return RouterOS absolute /webfig redirects to the active gateway."""
    query = request.query_string.decode("utf-8", errors="ignore")

    if session.get("user_id"):
        peer_id = session.get("last_admin_webfig_peer_id")
        if not peer_id:
            return "No active WebFig router", 404
        target = url_for(
            "admin_webfig_gateway",
            peer_id=int(peer_id),
            proxy_path=legacy_path or "",
        )
    elif session.get("agent_account_id"):
        peer_id = session.get("last_agent_webfig_peer_id")
        if not peer_id:
            return "No active WebFig router", 404
        account = current_agent_account()
        peer = get_agent_assigned_peer(
            account["id"],
            int(peer_id),
        ) if account else None
        if not peer or not account.get("can_open_webfig"):
            return "Forbidden", 403
        target = url_for(
            "agent_webfig_gateway",
            peer_id=int(peer_id),
            proxy_path=legacy_path or "",
        )
    else:
        return redirect(url_for("login"))

    if query:
        target += "?" + query

    return redirect(target, code=307)


@app.route("/admin/router/<int:peer_id>/webfig", defaults={"proxy_path": ""}, methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
@app.route("/admin/router/<int:peer_id>/webfig/", defaults={"proxy_path": ""}, methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
@app.route("/admin/router/<int:peer_id>/webfig/<path:proxy_path>", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
@login_required
def admin_webfig_gateway(peer_id, proxy_path):
    session["last_admin_webfig_peer_id"] = int(peer_id)
    con = db()
    peer_row = con.execute("SELECT * FROM peers WHERE id=?", (peer_id,)).fetchone()
    con.close()
    if not peer_row:
        return "Not found", 404
    peer = dict(peer_row)

    class AdminAccount(dict):
        pass

    account_id = -int(session.get("user_id") or 1)
    try:
        force = request.args.get("_reconnect") == "1"
        state = _bootstrap_webfig_session(peer, account_id, force=force)
        path = proxy_path or ""
        if path.startswith("_root/"):
            upstream_path = "/" + path[len("_root/"):]
        elif path == "_root":
            upstream_path = "/"
        else:
            upstream_path = state.get(
                "webfig_base_path",
                "/webfig/",
            )
            if path:
                if not upstream_path.endswith("/"):
                    upstream_path += "/"
                upstream_path += path

        query_pairs = [
            (key, value)
            for key, values in request.args.lists()
            if key != "_reconnect"
            for value in values
        ]
        if query_pairs:
            upstream_path += "?" + urllib.parse.urlencode(query_pairs)

        forwarded_headers = {}
        for key in (
            "Content-Type",
            "Accept",
            "X-Requested-With",
            "Origin",
            "Sec-Fetch-Dest",
            "Sec-Fetch-Mode",
            "Sec-Fetch-Site",
        ):
            value = request.headers.get(key)
            if value:
                forwarded_headers[key] = value
        forwarded_headers["Referer"] = state["root"] + "/webfig/"

        result = _webfig_fetch(
            state["opener"],
            state["root"] + upstream_path,
            method=request.method,
            body=request.get_data() if request.method != "GET" else None,
            headers=forwarded_headers,
            timeout=15,
        )
        state["last_used"] = time.time()

        content_type = result["headers"].get(
            "Content-Type", "application/octet-stream"
        )
        payload = _rewrite_webfig_body(
            result["body"], content_type, peer_id
        )
        # Rewrite agent proxy paths to admin proxy paths.
        try:
            payload = payload.replace(
                ("/agent/router/%s/webfig" % peer_id).encode("utf-8"),
                ("/admin/router/%s/webfig" % peer_id).encode("utf-8"),
            )
        except Exception:
            pass

        response = Response(
            payload,
            status=result["status"],
            content_type=content_type,
        )
        location = result["headers"].get("Location")
        if location:
            location = _proxy_location(location, peer_id, state["host"])
            location = location.replace(
                "/agent/router/%s/webfig" % peer_id,
                "/admin/router/%s/webfig" % peer_id,
            )
            response.headers["Location"] = location
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["X-Cloud-WebFig-Base"] = state.get(
            "webfig_base_path",
            "/webfig/",
        )
        response.headers["Content-Security-Policy"] = (
            "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; "
            "connect-src 'self' ws: wss:; "
            "img-src 'self' data: blob:; "
            "font-src 'self' data:;"
        )
        return response
    except Exception as exc:
        create_notification(
            "فشل فتح WebFig",
            "%s: %s" % (peer.get("name", "Router"), exc),
            kind="error",
            audience="admin",
            peer_id=peer_id,
        )
        return render_template(
            "agent_webfig_error.html",
            peer=peer,
            error=str(exc),
            settings=get_settings(),
        ), 502


@app.route("/agent/router/<int:peer_id>/webfig", defaults={"proxy_path": ""}, methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
@app.route("/agent/router/<int:peer_id>/webfig/", defaults={"proxy_path": ""}, methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
@app.route("/agent/router/<int:peer_id>/webfig/<path:proxy_path>", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
@agent_permission_required("can_open_webfig")
def agent_webfig_gateway(peer_id, proxy_path):
    session["last_agent_webfig_peer_id"] = int(peer_id)
    account = current_agent_account()
    peer = get_agent_assigned_peer(account["id"], peer_id)
    if not peer:
        return "Not found", 404

    try:
        force = request.args.get("_reconnect") == "1"
        state = _bootstrap_webfig_session(
            peer,
            account["id"],
            force=force,
        )

        path = proxy_path or ""
        if path.startswith("_root/"):
            upstream_path = "/" + path[len("_root/"):]
        elif path == "_root":
            upstream_path = "/"
        else:
            upstream_path = state.get(
                "webfig_base_path",
                "/webfig/",
            )
            if path:
                if not upstream_path.endswith("/"):
                    upstream_path += "/"
                upstream_path += path

        query_pairs = [
            (key, value)
            for key, values in request.args.lists()
            if key != "_reconnect"
            for value in values
        ]
        if query_pairs:
            upstream_path += "?" + urllib.parse.urlencode(query_pairs)

        forwarded_headers = {}
        for key in (
            "Content-Type",
            "Accept",
            "X-Requested-With",
            "Origin",
            "Sec-Fetch-Dest",
            "Sec-Fetch-Mode",
            "Sec-Fetch-Site",
        ):
            value = request.headers.get(key)
            if value:
                forwarded_headers[key] = value
        forwarded_headers["Referer"] = state["root"] + "/webfig/"

        result = _webfig_fetch(
            state["opener"],
            state["root"] + upstream_path,
            method=request.method,
            body=request.get_data() if request.method != "GET" else None,
            headers=forwarded_headers,
            timeout=15,
        )
        state["last_used"] = time.time()

        content_type = result["headers"].get(
            "Content-Type",
            "application/octet-stream",
        )
        payload = _rewrite_webfig_body(
            result["body"],
            content_type,
            peer_id,
        )

        response = Response(
            payload,
            status=result["status"],
            content_type=content_type,
        )
        location = result["headers"].get("Location")
        if location:
            response.headers["Location"] = _proxy_location(
                location,
                peer_id,
                state["host"],
            )
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["X-Cloud-WebFig-Base"] = state.get(
            "webfig_base_path",
            "/webfig/",
        )
        response.headers["Content-Security-Policy"] = (
            "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; "
            "connect-src 'self' ws: wss:; "
            "img-src 'self' data: blob:; "
            "font-src 'self' data:;"
        )
        return response
    except Exception as exc:
        with DB_WRITE_LOCK:
            con = db()
            con.execute(
                """
                UPDATE peers
                SET webfig_last_state='error',
                    webfig_last_error=?
                WHERE id=?
                """,
                (str(exc)[:500], int(peer_id)),
            )
            con.commit()
            con.close()
        return render_template(
            "agent_webfig_error.html",
            peer=peer,
            error=str(exc),
            settings=get_settings(),
        ), 502


@app.route("/agent/router/<int:peer_id>/webfig/disconnect", methods=["POST"])
@agent_permission_required("can_open_webfig")
def agent_webfig_disconnect(peer_id):
    account = current_agent_account()
    peer = get_agent_assigned_peer(account["id"], peer_id)
    if not peer:
        return "Not found", 404
    with WEBFIG_SESSION_LOCK:
        WEBFIG_SESSIONS.pop(
            (int(account["id"]), int(peer_id)),
            None,
        )
    flash("تم إنهاء جلسة WebFig", "success")
    return redirect(
        url_for("agent_router_page", peer_id=peer_id)
    )


@app.route("/agent/router/<int:peer_id>")
@agent_permission_required("can_view_routers")
def agent_router_page(peer_id):
    account = current_agent_account()
    peer = get_agent_assigned_peer(account["id"], peer_id)
    if not peer:
        return "Not found", 404

    devices = []
    if account.get("can_view_vpn_access"):
        con = db()
        device_rows = con.execute(
            """
            SELECT * FROM agent_devices
            WHERE peer_id=?
            ORDER BY CASE device_type WHEN 'mobile' THEN 1 WHEN 'windows' THEN 2 ELSE 3 END
            """,
            (int(peer_id),),
        ).fetchall()
        con.close()
        agent_stats = cached_agent_wireguard_stats()
        for row in device_rows:
            item = dict(row)
            item["wg"] = agent_stats.get(
                item["public_key"],
                {"online": False, "handshake_text": "-"},
            )
            devices.append(item)

    subscriber_total = 0
    if account.get("can_view_subscribers"):
        con = db()
        subscriber_total = int(con.execute(
            "SELECT COUNT(*) FROM port_forwards WHERE peer_id=?",
            (int(peer_id),),
        ).fetchone()[0])
        con.close()

    peer_stats = cached_wireguard_peer_stats().get(
        peer["public_key"],
        {"online": False, "handshake_text": "-", "rx": 0, "tx": 0},
    )
    settings = get_settings()
    return render_template(
        "agent_router_portal.html",
        peer=peer,
        peer_stats=peer_stats,
        peer_ping=cached_peer_ping(peer_id),
        devices=devices,
        subscriber_total=subscriber_total,
        settings=settings,
        agent_server_ip=_agent_server_ip(settings),
    )


@app.route("/agent/router/<int:peer_id>/subscribers")
@agent_permission_required("can_view_subscribers")
def agent_router_subscribers_page(peer_id):
    account = current_agent_account()
    peer_row = get_agent_assigned_peer(account["id"], peer_id)
    if not peer_row:
        return "Not found", 404
    peer = dict(peer_row)
    stats = cached_wireguard_peer_stats()
    peer["wg"] = stats.get(
        peer.get("public_key", ""),
        {"handshake_text": "-", "rx": 0, "tx": 0, "online": False},
    )
    peer["health"] = cached_peer_ping(peer["id"])
    con = db()
    forwards = [
        dict(row) for row in con.execute(
            """
            SELECT pf.*, p.name AS peer_name, p.tunnel_ip
            FROM port_forwards pf
            JOIN peers p ON p.id=pf.peer_id
            WHERE pf.peer_id=?
            ORDER BY pf.name,pf.external_port,pf.id
            """,
            (int(peer_id),),
        ).fetchall()
    ]
    con.close()
    active_count = sum(
        1 for item in forwards
        if item.get("enabled") and not item.get("last_error")
    )
    error_count = sum(1 for item in forwards if item.get("last_error"))
    manual_count = sum(1 for item in forwards if not item.get("auto_managed"))
    return render_template(
        "router_subscribers.html",
        peer=peer,
        forwards=forwards,
        active_count=active_count,
        inactive_count=len(forwards) - active_count,
        error_count=error_count,
        manual_count=manual_count,
        settings=get_settings(),
        agent_mode=True,
    )


@app.route("/agent/api/router/<int:peer_id>/status")
@agent_permission_required("can_view_routers")
def agent_router_status_api(peer_id):
    account = current_agent_account()
    peer = get_agent_assigned_peer(account["id"], peer_id)
    if not peer:
        return jsonify({"error": "not found"}), 404
    wg = cached_wireguard_peer_stats().get(
        peer["public_key"],
        {"online": False, "handshake_text": "-", "rx": 0, "tx": 0},
    )
    ping = cached_peer_ping(peer_id)
    return jsonify({
        "online": bool(wg.get("online")) if account.get("can_view_router_status") else None,
        "handshake": wg.get("handshake_text", "-") if account.get("can_view_handshake") else "",
        "rx": human_bytes(wg.get("rx", 0)) if account.get("can_view_traffic") else "",
        "tx": human_bytes(wg.get("tx", 0)) if account.get("can_view_traffic") else "",
        "latency": ping.get("latency", "-") if account.get("can_view_ping") else "",
        "loss": ping.get("loss", "-") if account.get("can_view_ping") else "",
    })


@app.route("/agent/api/peers/<int:peer_id>/subscribers")
@agent_permission_required("can_view_subscribers")
def agent_peer_subscribers_api(peer_id):
    account = current_agent_account()
    peer = get_agent_assigned_peer(account["id"], peer_id)
    if not peer:
        return jsonify({"ok": False, "error": "not found", "subscribers": []}), 404
    try:
        subscribers = fetch_router_subscribers(peer_id)
        return jsonify({
            "ok": True,
            "peer": {"id": peer["id"], "name": peer["name"], "tunnel_ip": peer["tunnel_ip"]},
            "count": len(subscribers),
            "subscribers": subscribers,
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc), "subscribers": []}), 500


@app.route("/agent/api/router/<int:peer_id>/subscribers")
@agent_permission_required("can_view_subscribers")
def agent_subscribers_api(peer_id):
    account = current_agent_account()
    peer = get_agent_assigned_peer(account["id"], peer_id)
    if not peer:
        return jsonify({"error": "not found"}), 404

    try:
        page = max(1, int(request.args.get("page", "1") or 1))
    except Exception:
        page = 1
    try:
        per_page = min(50, max(10, int(request.args.get("per_page", "20") or 20)))
    except Exception:
        per_page = 20
    query = request.args.get("q", "").strip()
    offset = (page - 1) * per_page

    where = ["peer_id=?"]
    params = [int(peer_id)]
    if query:
        where.append("(name LIKE ? OR internal_ip LIKE ?)")
        like = "%" + query + "%"
        params.extend([like, like])
    where_sql = " AND ".join(where)

    con = db()
    total = int(con.execute(
        "SELECT COUNT(*) FROM port_forwards WHERE " + where_sql,
        tuple(params),
    ).fetchone()[0])
    rows = con.execute(
        """
        SELECT * FROM port_forwards
        WHERE %s
        ORDER BY enabled DESC,name,id
        LIMIT ? OFFSET ?
        """ % where_sql,
        tuple(params + [per_page, offset]),
    ).fetchall()
    con.close()

    direct_ips, _ = _direct_ips_for_peer(peer_id)
    direct_set = set(direct_ips)
    items = []
    for row in rows:
        item = dict(row)
        item["direct_url"] = _agent_direct_url(item)
        item["direct_available"] = item["internal_ip"] in direct_set
        item["owned_by_current_agent"] = (
            int(item.get("owner_agent_id") or 0) == int(account["id"])
        )
        items.append(item)

    pages = max(1, (total + per_page - 1) // per_page)
    html = render_template(
        "_agent_subscriber_cards.html",
        items=items,
        peer=peer,
        page=page,
        pages=pages,
    )
    return jsonify({
        "html": html,
        "total": total,
        "page": page,
        "pages": pages,
    })


@app.route("/agent/router/<int:peer_id>/access/<device_type>/config")
@agent_login_required
def agent_portal_download_config(peer_id, device_type):
    account = current_agent_account()
    peer = get_agent_assigned_peer(account["id"], peer_id)
    if not peer:
        return "Not found", 404
    if device_type == "mobile":
        permission = "can_download_mobile_config"
    elif device_type == "windows":
        permission = "can_download_windows_config"
    else:
        return "Not found", 404
    if not account.get(permission):
        return "Forbidden", 403
    ensure_agent_devices(peer_id)
    device = get_agent_device(peer_id, device_type)
    if not device:
        return "Not found", 404
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "-", peer["name"]).strip("-") or ("peer-%s" % peer_id)
    return send_file(
        io.BytesIO(agent_client_config(device).encode("utf-8")),
        mimetype="text/plain",
        as_attachment=True,
        download_name="%s-%s.conf" % (safe_name, device_type),
    )


@app.route("/agent/router/<int:peer_id>/access/<device_type>/qr.png")
@agent_permission_required("can_view_mobile_qr")
def agent_portal_qr(peer_id, device_type):
    if device_type != "mobile":
        return "Not found", 404
    account = current_agent_account()
    peer = get_agent_assigned_peer(account["id"], peer_id)
    if not peer:
        return "Not found", 404
    ensure_agent_devices(peer_id)
    device = get_agent_device(peer_id, device_type)
    if not device:
        return "Not found", 404
    image = qrcode.make(agent_client_config(device))
    output = io.BytesIO()
    image.save(output, format="PNG")
    output.seek(0)
    return send_file(output, mimetype="image/png", as_attachment=False, download_name="agent-%s-%s.png" % (peer_id, device_type))


@app.route("/agent/router/<int:peer_id>/sync", methods=["POST"])
@agent_mutation_permission_required("can_sync_subscribers")
def agent_router_sync(peer_id):
    account = current_agent_account()
    if not get_agent_assigned_peer(account["id"], peer_id):
        return jsonify({"error": "not found"}), 404
    with SUBSCRIBER_SYNC_STATE_LOCK:
        running = bool(SUBSCRIBER_SYNC_STATE.get("running"))
    if not running:
        threading.Thread(
            target=run_automatic_subscriber_sync,
            name="agent-manual-subscriber-sync",
            daemon=True,
        ).start()
    if request.is_json:
        return jsonify({"started": not running, "running": True}), 202
    flash("بدأت مزامنة المشتركين" if not running else "المزامنة تعمل حالياً", "success")
    return redirect(url_for("agent_router_subscribers_page", peer_id=peer_id))


@app.route("/agent/router/<int:peer_id>/export.csv")
@agent_permission_required("can_export_subscribers")
def agent_router_export(peer_id):
    account = current_agent_account()
    peer = get_agent_assigned_peer(account["id"], peer_id)
    if not peer:
        return "Not found", 404
    con = db()
    rows = con.execute(
        """
        SELECT name,internal_ip,internal_port,protocol,enabled,last_seen_at
        FROM port_forwards WHERE peer_id=? ORDER BY name,id
        """,
        (int(peer_id),),
    ).fetchall()
    con.close()
    output = io.StringIO()
    output.write(u"\ufeff")
    writer = csv.writer(output)
    writer.writerow(["Name", "IP", "Port", "Protocol", "Enabled", "Last Seen"])
    for row in rows:
        writer.writerow([
            row["name"], row["internal_ip"], row["internal_port"],
            row["protocol"], row["enabled"], row["last_seen_at"],
        ])
    data = io.BytesIO(output.getvalue().encode("utf-8"))
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "-", peer["name"]).strip("-") or ("router-%s" % peer_id)
    return send_file(
        data,
        mimetype="text/csv; charset=utf-8",
        as_attachment=True,
        download_name=safe_name + "-subscribers.csv",
    )


@app.route("/agent/router/<int:peer_id>/notes", methods=["POST"])
@agent_mutation_permission_required("can_edit_notes")
def agent_router_notes(peer_id):
    account = current_agent_account()
    if not get_agent_assigned_peer(account["id"], peer_id):
        return "Not found", 404
    notes = request.form.get("notes", "").strip()[:2000]
    con = db()
    con.execute("UPDATE peers SET notes=? WHERE id=?", (notes, int(peer_id)))
    con.commit()
    con.close()
    flash("تم حفظ ملاحظات الراوتر", "success")
    return redirect(url_for("agent_router_page", peer_id=peer_id))


@app.route("/agent/router/<int:peer_id>/subscribers/add", methods=["POST"])
@agent_mutation_permission_required("can_add_subscriber")
def agent_subscriber_add(peer_id):
    account = current_agent_account()
    peer = get_agent_assigned_peer(account["id"], peer_id)
    if not peer:
        return "Not found", 404
    try:
        internal_ip = _agent_allowed_manual_ip(peer, request.form.get("internal_ip", ""))
        name = request.form.get("name", "").strip() or internal_ip
        internal_port = int(request.form.get("internal_port", "80") or 80)
        if internal_port < 1 or internal_port > 65535:
            raise RuntimeError("البورت الداخلي غير صحيح")
        protocol = validate_forward_protocol(request.form.get("protocol", "tcp"))
        external_port = next_forward_external_port()
        stamp = datetime.now().isoformat(timespec="seconds")
        con = db()
        cursor = con.execute(
            """
            INSERT INTO port_forwards(
                peer_id,name,internal_ip,internal_port,external_port,
                protocol,enabled,created_at,updated_at,auto_managed,
                subscriber_source,owner_agent_id
            ) VALUES(?,?,?,?,?,?,1,?,?,0,'agent-manual',?)
            """,
            (
                int(peer_id), name[:120], internal_ip, internal_port,
                external_port, protocol, stamp, stamp, int(account["id"]),
            ),
        )
        forward_id = int(cursor.lastrowid)
        con.commit()
        con.close()
        try:
            _sync_forward_changes([peer_id])
            flash("تمت إضافة IP الدخول وتطبيقه", "success")
        except Exception as exc:
            mark_forward_error(forward_id, exc)
            flash("تمت الإضافة، لكن فشل تطبيقها على الراوتر: %s" % exc, "danger")
    except Exception as exc:
        flash("تعذر إضافة IP: %s" % exc, "danger")
    return redirect(url_for("agent_router_page", peer_id=peer_id))


@app.route("/agent/subscribers/<int:forward_id>/edit", methods=["GET", "POST"])
@agent_mutation_permission_required("can_edit_subscriber")
def agent_subscriber_edit(forward_id):
    account = current_agent_account()
    item = get_agent_assigned_forward(account["id"], forward_id)
    if not item:
        return "Not found", 404

    assigned_peers = assigned_peers_for_agent(account["id"])
    peer_ids = {int(peer["id"]) for peer in assigned_peers}
    if request.method == "GET":
        return render_template(
            "edit_forward.html",
            item=item,
            peers=assigned_peers,
            settings=get_settings(),
            agent_mode=True,
        )

    try:
        peer_id = int(request.form.get("peer_id", item["peer_id"]) or item["peer_id"])
        if peer_id not in peer_ids:
            raise RuntimeError("الراوتر غير مسموح لهذا الحساب")
        peer = get_agent_assigned_peer(account["id"], peer_id)
        internal_ip = _agent_allowed_manual_ip(
            peer, request.form.get("internal_ip", item["internal_ip"])
        )
        internal_port = int(request.form.get("internal_port", item["internal_port"]) or item["internal_port"])
        if internal_port < 1 or internal_port > 65535:
            raise RuntimeError("البورت الداخلي غير صحيح")
        protocol = validate_forward_protocol(request.form.get("protocol", item["protocol"]))
        external_port = int(request.form.get("external_port", item["external_port"]) or item["external_port"])
        validate_forward_external_port(external_port, forward_id=forward_id)
        enabled = 1 if request.form.get("enabled") else 0
        con = db()
        con.execute(
            """
            UPDATE port_forwards SET peer_id=?,internal_ip=?,internal_port=?,
                external_port=?,protocol=?,enabled=?,updated_at=?,last_error=''
            WHERE id=?
            """,
            (
                peer_id, internal_ip, internal_port, external_port, protocol,
                enabled, datetime.now().isoformat(timespec="seconds"),
                int(forward_id),
            ),
        )
        con.commit()
        con.close()
        _sync_forward_changes(sorted({int(item["peer_id"]), peer_id}))
        flash("تم تعديل المنفذ وتطبيقه", "success")
    except Exception as exc:
        flash("تعذر التعديل: %s" % exc, "danger")

    return redirect(
        request.args.get("next")
        or url_for("agent_router_subscribers_page", peer_id=item["peer_id"])
    )


@app.route("/agent/subscribers/<int:forward_id>/apply", methods=["POST"])
@agent_mutation_permission_required("can_edit_subscriber")
def agent_subscriber_apply(forward_id):
    account = current_agent_account()
    item = get_agent_assigned_forward(account["id"], forward_id)
    if not item:
        return "Not found", 404
    try:
        _sync_forward_changes([int(item["peer_id"])])
        flash("تم تطبيق إعداد المشترك", "success")
    except Exception as exc:
        mark_forward_error(forward_id, exc)
        flash("فشل تطبيق الإعداد: %s" % exc, "danger")
    return redirect(
        request.args.get("next")
        or url_for("agent_router_subscribers_page", peer_id=item["peer_id"])
    )


@app.route("/agent/subscribers/<int:forward_id>/toggle", methods=["POST"])
@agent_mutation_permission_required("can_edit_subscriber")
def agent_subscriber_toggle(forward_id):
    account = current_agent_account()
    item = get_agent_assigned_forward(account["id"], forward_id)
    if not item:
        return "Not found", 404
    con = db()
    con.execute(
        "UPDATE port_forwards SET enabled=?,updated_at=?,last_error='' WHERE id=?",
        (
            0 if item.get("enabled") else 1,
            datetime.now().isoformat(timespec="seconds"),
            int(forward_id),
        ),
    )
    con.commit()
    con.close()
    try:
        _sync_forward_changes([int(item["peer_id"])])
        flash("تم تحديث حالة المشترك", "success")
    except Exception as exc:
        mark_forward_error(forward_id, exc)
        flash("تم الحفظ، لكن فشل التطبيق: %s" % exc, "danger")
    return redirect(
        request.args.get("next")
        or url_for("agent_router_subscribers_page", peer_id=item["peer_id"])
    )


@app.route("/agent/subscribers/<int:forward_id>/delete", methods=["POST"])
@agent_mutation_permission_required("can_delete_subscriber")
def agent_subscriber_delete(forward_id):
    account = current_agent_account()
    item = get_agent_assigned_forward(account["id"], forward_id)
    if not item:
        return "Not found", 404
    con = db()
    con.execute(
        "DELETE FROM port_forwards WHERE id=?",
        (int(forward_id),),
    )
    con.commit()
    con.close()
    try:
        _sync_forward_changes([item["peer_id"]])
        flash("تم حذف إدخال المشترك", "success")
    except Exception as exc:
        flash("تم الحذف من الصفحة، لكن تعذر تنظيف الراوتر: %s" % exc, "danger")
    return redirect(url_for("agent_router_subscribers_page", peer_id=item["peer_id"]))


@app.route("/agent/password", methods=["POST"])
@agent_mutation_permission_required("can_change_password")
def agent_change_password():
    account = current_agent_account()
    current = request.form.get("current_password", "")
    new = request.form.get("new_password", "")
    if len(new) < 8:
        flash("كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل", "danger")
        return redirect(url_for("agent_dashboard"))
    if not check_password_hash(account["password_hash"], current):
        flash("كلمة المرور الحالية غير صحيحة", "danger")
        return redirect(url_for("agent_dashboard"))
    con = db()
    con.execute(
        "UPDATE agent_accounts SET password_hash=?,updated_at=? WHERE id=?",
        (
            generate_password_hash(new),
            datetime.now().isoformat(timespec="seconds"),
            int(account["id"]),
        ),
    )
    con.commit()
    con.close()
    flash("تم تغيير كلمة المرور", "success")
    return redirect(url_for("agent_dashboard"))


@app.route("/internal/radius-health/<token>")
def internal_radius_health(token):
    con = db()
    peer = con.execute(
        "SELECT id FROM peers WHERE cloud_health_token=? AND enabled=1",
        (str(token),),
    ).fetchone()
    con.close()
    if not peer:
        return "Not found", 404
    try:
        proc = subprocess.run(
            ["ss", "-H", "-lun"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            universal_newlines=True,
            timeout=3,
        )
        output = proc.stdout or ""
        listening = bool(re.search(r":1812(?:\s|$)", output, re.M))
    except Exception:
        listening = False
    if listening:
        return Response(status=204)
    return Response("RADIUS unavailable", status=503, mimetype="text/plain")


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    if current_agent_account():
        return redirect(url_for("agent_dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        # Try administrator accounts first.
        con = db()
        user = con.execute(
            "SELECT * FROM users WHERE username=?",
            (username,),
        ).fetchone()
        con.close()

        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = int(user["id"])
            session["username"] = user["username"]
            create_notification(
                "تسجيل دخول الإدارة",
                "تم تسجيل الدخول بواسطة %s" % user["username"],
                kind="success",
                audience="admin",
            )
            return redirect(url_for("dashboard"))

        # Same form also accepts agent accounts.
        con = db()
        account = con.execute(
            "SELECT * FROM agent_accounts WHERE username=?",
            (username,),
        ).fetchone()
        con.close()

        if (
            account
            and account["enabled"]
            and check_password_hash(account["password_hash"], password)
        ):
            session.clear()
            session["agent_account_id"] = int(account["id"])
            session["agent_username"] = account["username"]
            session["agent_display_name"] = (
                account["display_name"] or account["username"]
            )

            create_notification(
                "دخول وكيل",
                "سجل الوكيل %s الدخول"
                % (account["display_name"] or account["username"]),
                kind="info",
                audience="admin",
            )
            create_notification(
                "تم تسجيل الدخول",
                "مرحباً بك في بوابة الوكيل",
                kind="success",
                audience="agent",
                agent_account_id=account["id"],
            )

            con = db()
            con.execute(
                "UPDATE agent_accounts SET last_login_at=? WHERE id=?",
                (
                    datetime.now().isoformat(timespec="seconds"),
                    int(account["id"]),
                ),
            )
            con.commit()
            con.close()
            return redirect(url_for("agent_dashboard"))

        flash("اسم المستخدم أو كلمة المرور غير صحيحة", "danger")

    return render_template("login.html", settings=get_settings())


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def dashboard():
    try:
        import_peers_from_ubuntu()
    except Exception:
        pass

    con = db()
    rows = con.execute(
        "SELECT * FROM peers ORDER BY id DESC"
    ).fetchall()
    con.close()

    stats = cached_wireguard_peer_stats()
    peers = []
    for row in rows:
        item = dict(row)
        item["wg"] = stats.get(
            item["public_key"],
            {
                "handshake_text": "-",
                "rx": 0,
                "tx": 0,
                "online": False,
            },
        )
        item["health"] = cached_peer_ping(item["id"])
        peers.append(item)

    online_peers = [
        peer for peer in peers
        if peer["wg"]["online"]
    ]
    offline_peers = [
        peer for peer in peers
        if not peer["wg"]["online"]
    ]

    # Offline routers first so a problem is visible immediately.
    peers = offline_peers + online_peers

    rx = sum(
        peer["wg"].get("rx", 0)
        for peer in peers
    )
    tx = sum(
        peer["wg"].get("tx", 0)
        for peer in peers
    )

    return render_template(
        "dashboard.html",
        peers=peers,
        online_peers=online_peers,
        offline_peers=offline_peers,
        total=len(peers),
        online=len(online_peers),
        offline=len(offline_peers),
        rx=rx,
        tx=tx,
        settings=get_settings(),
    )


@app.route("/system/health")
@login_required
def health_center_page():
    def service_state(name):
        try:
            proc=subprocess.run(["systemctl","is-active",name],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,universal_newlines=True,timeout=3)
            return "ok" if proc.stdout.strip()=="active" else "down"
        except Exception:
            return "unknown"
    checks=[]
    try:
        con=db(); con.execute("SELECT 1").fetchone(); con.close(); db_state="ok"
    except Exception:
        db_state="down"
    checks.append({"name":"قاعدة البيانات","state":db_state,"detail":"SQLite data.db"})
    checks.append({"name":"خدمة اللوحة","state":"ok","detail":"Port 1994"})
    checks.append({"name":"WireGuard الراوترات","state":"ok" if subprocess.run(["ip","link","show",DEFAULT_INTERFACE],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0 else "down","detail":DEFAULT_INTERFACE})
    checks.append({"name":"WireGuard الوكلاء","state":"ok" if subprocess.run(["ip","link","show",DEFAULT_AGENT_INTERFACE],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0 else "down","detail":DEFAULT_AGENT_INTERFACE})
    checks.append({"name":"FreeRADIUS","state":service_state("freeradius"),"detail":"UDP 1812/1813"})
    checks.append({"name":"Nginx","state":service_state("nginx"),"detail":"WebFig gateway"})
    con=db(); total=con.execute("SELECT COUNT(*) FROM peers").fetchone()[0]; con.close()
    stats=cached_wireguard_peer_stats(); online=sum(1 for v in stats.values() if v.get("online"))
    return render_template("health_center.html",checks=checks,total_routers=total,online_routers=online,settings=get_settings())


@app.route("/system/audit")
@login_required
def audit_log_page():
    con=db(); rows=[dict(r) for r in con.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 500").fetchall()]; con.close()
    return render_template("audit_log.html",rows=rows,settings=get_settings())


@app.route("/system/maintenance", methods=["GET","POST"])
@login_required
def maintenance_page():
    if request.method=="POST":
        enabled="1" if request.form.get("enabled")=="1" else "0"
        con=db(); con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('maintenance_mode',?)",(enabled,)); con.commit(); con.close()
        audit_event("maintenance_mode", "system", "enabled="+enabled)
        flash("تم تحديث وضع الصيانة","success")
        return redirect(url_for("maintenance_page"))
    return render_template("maintenance_settings.html",enabled=maintenance_enabled(),settings=get_settings())


@app.route("/router-groups", methods=["GET","POST"])
@login_required
def router_groups_page():
    con=db()
    if request.method=="POST":
        name=request.form.get("name","").strip(); peer_ids=[int(x) for x in request.form.getlist("peer_ids") if str(x).isdigit()]
        if name:
            stamp=datetime.now().isoformat(timespec="seconds")
            try:
                con.execute("INSERT INTO router_groups(name,notes,created_at) VALUES(?,?,?)",(name,request.form.get("notes","").strip(),stamp)); gid=con.execute("SELECT last_insert_rowid()").fetchone()[0]
                for pid in peer_ids: con.execute("INSERT OR IGNORE INTO router_group_peers(group_id,peer_id) VALUES(?,?)",(gid,pid))
                con.commit(); flash("تم إنشاء مجموعة الراوترات","success")
            except sqlite3.IntegrityError: con.rollback(); flash("اسم المجموعة مستخدم","danger")
        con.close(); return redirect(url_for("router_groups_page"))
    groups=[dict(r) for r in con.execute("SELECT * FROM router_groups ORDER BY name").fetchall()]
    peers=[dict(r) for r in con.execute("SELECT id,name FROM peers ORDER BY name").fetchall()]
    for g in groups:
        g["peers"]=[dict(r) for r in con.execute("SELECT p.id,p.name FROM peers p JOIN router_group_peers x ON x.peer_id=p.id WHERE x.group_id=? ORDER BY p.name",(g["id"],)).fetchall()]
    con.close(); return render_template("router_groups.html",groups=groups,peers=peers,settings=get_settings())


@app.route("/router-groups/<int:group_id>/delete",methods=["POST"])
@login_required
def router_group_delete(group_id):
    con=db(); con.execute("DELETE FROM router_groups WHERE id=?",(group_id,)); con.commit(); con.close(); flash("تم حذف المجموعة","success"); return redirect(url_for("router_groups_page"))


def _safe_extract_zip(zf, dest):
    base = os.path.realpath(dest)
    for member in zf.infolist():
        target = os.path.realpath(os.path.join(dest, member.filename))
        if not target.startswith(base + os.sep):
            raise ValueError("ملف التحديث يحتوي مساراً غير آمن")
    zf.extractall(dest)


UPDATE_ROOT = Path("/var/lib/cloud-wireguard-panel/updates")


def _read_update_status():
    try:
        UPDATE_ROOT.mkdir(parents=True, exist_ok=True)
        jobs = [p for p in UPDATE_ROOT.iterdir() if p.is_dir()]
        if not jobs:
            return None
        latest = max(jobs, key=lambda p: p.stat().st_mtime)
        status_path = latest / "status.txt"
        output_path = latest / "output.log"
        status = "unknown"
        message = ""
        if status_path.exists():
            parts = status_path.read_text(encoding="utf-8", errors="replace").split("|", 1)
            status = parts[0].strip() or "unknown"
            if len(parts) > 1:
                message = parts[1].strip()
        output = ""
        if output_path.exists():
            output = output_path.read_text(encoding="utf-8", errors="replace")[-12000:]
        return {
            "job_id": latest.name,
            "status": status,
            "message": message,
            "output": output,
            "updated_at": datetime.fromtimestamp(latest.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
        }
    except Exception:
        return None


def _start_update_job(upload):
    UPDATE_ROOT.mkdir(parents=True, exist_ok=True)
    job_id = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
    job_dir = UPDATE_ROOT / job_id
    payload_dir = job_dir / "payload"
    job_dir.mkdir(parents=True, exist_ok=False)
    payload_dir.mkdir(parents=True, exist_ok=True)
    zip_path = job_dir / "update.zip"
    upload.save(str(zip_path))

    with zipfile.ZipFile(str(zip_path)) as zf:
        _safe_extract_zip(zf, str(payload_dir))

    scripts = []
    for dp, _, fs in os.walk(str(payload_dir)):
        for filename in fs:
            if filename.startswith("upgrade-") and filename.endswith(".sh"):
                scripts.append(os.path.join(dp, filename))
    if len(scripts) != 1:
        raise ValueError("ملف التحديث يجب أن يحتوي سكربت ترقية واحد")

    upgrade_script = scripts[0]
    runner_path = job_dir / "run-update.sh"
    status_path = job_dir / "status.txt"
    output_path = job_dir / "output.log"
    status_path.write_text("queued|تم استلام التحديث وبانتظار التنفيذ", encoding="utf-8")

    runner = """#!/bin/bash
set +e
JOB_DIR=%s
SCRIPT=%s
WORK_DIR=%s
STATUS="$JOB_DIR/status.txt"
OUTPUT="$JOB_DIR/output.log"
printf 'running|جاري تثبيت التحديث' > "$STATUS"
chmod 700 "$SCRIPT"
cd "$WORK_DIR"
/bin/bash "$SCRIPT" > "$OUTPUT" 2>&1
RC=$?
if [ "$RC" -eq 0 ]; then
  printf 'success|اكتمل تثبيت التحديث بنجاح' > "$STATUS"
else
  printf 'failed|فشل التحديث برمز خروج %%s' "$RC" > "$STATUS"
fi
exit "$RC"
""" % (
        subprocess.list2cmdline([str(job_dir)]),
        subprocess.list2cmdline([upgrade_script]),
        subprocess.list2cmdline([os.path.dirname(upgrade_script)]),
    )
    runner_path.write_text(runner, encoding="utf-8")
    os.chmod(str(runner_path), 0o700)

    unit = "cloud-panel-update-" + job_id.replace("-", "")
    proc = subprocess.run(
        ["systemd-run", "--unit=" + unit, "--property=Type=oneshot", "/bin/bash", str(runner_path)],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        timeout=20,
    )
    if proc.returncode != 0:
        status_path.write_text("failed|تعذر تشغيل خدمة التحديث", encoding="utf-8")
        raise RuntimeError(proc.stdout.strip() or "تعذر تشغيل خدمة التحديث")
    return job_id


@app.route("/system/updates", methods=["GET", "POST"])
@login_required
def system_updates_page():
    if request.method == "POST":
        upload = request.files.get("update_file")
        if not upload or not upload.filename.lower().endswith(".zip"):
            flash("اختر ملف تحديث ZIP", "danger")
            return redirect(url_for("system_updates_page"))
        try:
            job_id = _start_update_job(upload)
            audit_event("system_update_queued", upload.filename, job_id)
            flash("تم رفع التحديث وبدأ تثبيته بالخلفية. انتظر قليلاً ثم حدّث الصفحة.", "success")
        except Exception as exc:
            audit_event("system_update_failed", upload.filename, str(exc))
            flash("تعذر بدء التحديث: %s" % exc, "danger")
        return redirect(url_for("system_updates_page"))
    return render_template(
        "system_updates.html",
        update_status=_read_update_status(),
        settings=get_settings(),
    )


@app.route("/api/system/update-status")
@login_required
def system_update_status_api():
    return jsonify(_read_update_status() or {"status": "idle", "message": "لا يوجد تحديث قيد التنفيذ"})


@app.route("/routers")
@login_required
def routers_page():
    con = db()
    rows = con.execute("SELECT * FROM peers ORDER BY id DESC").fetchall()
    con.close()

    stats = cached_wireguard_peer_stats()
    peers = []
    for row in rows:
        item = dict(row)
        item["wg"] = stats.get(item["public_key"], {
            "handshake_text": "-", "rx": 0, "tx": 0, "online": False
        })
        item["health"] = cached_peer_ping(item["id"])
        peers.append(item)

    peers.sort(
        key=lambda item: (
            bool(item["wg"]["online"]),
            item["name"].lower(),
        )
    )
    online_count = sum(
        1 for item in peers
        if item["wg"]["online"]
    )
    return render_template(
        "routers.html",
        peers=peers,
        online_count=online_count,
        offline_count=len(peers) - online_count,
        settings=get_settings(),
    )


@app.route("/wireguard")
@login_required
def wireguard_page():
    con = db()
    rows = con.execute("SELECT * FROM peers ORDER BY id DESC").fetchall()
    agent_rows = con.execute(
        "SELECT public_key,enabled FROM agent_devices ORDER BY id"
    ).fetchall()
    con.close()

    stats = cached_wireguard_peer_stats()
    agent_stats = cached_agent_wireguard_stats()
    peers = []
    for row in rows:
        item = dict(row)
        item["wg"] = stats.get(item["public_key"], {
            "handshake_text": "-", "rx": 0, "tx": 0, "online": False
        })
        item["health"] = cached_peer_ping(item["id"])
        peers.append(item)

    peers.sort(
        key=lambda item: (
            bool(item["wg"]["online"]),
            item["name"].lower(),
        )
    )
    online_count = sum(1 for item in peers if item["wg"]["online"])
    agent_total = sum(1 for row in agent_rows if row["enabled"])
    agent_online = sum(
        1 for row in agent_rows
        if row["enabled"] and agent_stats.get(row["public_key"], {}).get("online")
    )
    rx = sum(item["wg"].get("rx", 0) for item in peers)
    tx = sum(item["wg"].get("tx", 0) for item in peers)
    settings = get_settings()
    main_server = wireguard_interface_summary(
        settings.get("interface", DEFAULT_INTERFACE),
        len(peers),
    )
    agent_server = wireguard_interface_summary(
        settings.get("agent_interface", DEFAULT_AGENT_INTERFACE),
        agent_total,
    )

    return render_template(
        "wireguard.html",
        peers=peers,
        online_count=online_count,
        offline_count=len(peers) - online_count,
        agent_total=agent_total,
        agent_online=agent_online,
        rx=rx,
        tx=tx,
        main_server=main_server,
        agent_server=agent_server,
        settings=settings,
    )


@app.route("/wireguard/server/<server_key>/<action>", methods=["POST"])
@login_required
def wireguard_server_action(server_key, action):
    if server_key not in ("routers", "agents") or action not in ("start", "restart"):
        return "Not found", 404
    settings = get_settings()
    interface = (
        settings.get("interface", DEFAULT_INTERFACE)
        if server_key == "routers"
        else settings.get("agent_interface", DEFAULT_AGENT_INTERFACE)
    )
    label = "خادم الراوترات" if server_key == "routers" else "خادم الوكلاء"
    try:
        run(["systemctl", action, "wg-quick@%s" % interface])
        refresh_runtime_caches()
        flash("تم %s %s" % ("تشغيل" if action == "start" else "إعادة تشغيل", label), "success")
    except Exception as exc:
        flash("تعذر تنفيذ العملية على %s: %s" % (label, exc), "danger")
    return redirect(url_for("wireguard_page"))


@app.route("/wireguard/server/<server_key>/log")
@login_required
def wireguard_server_log(server_key):
    if server_key not in ("routers", "agents"):
        return "Not found", 404
    settings = get_settings()
    interface = (
        settings.get("interface", DEFAULT_INTERFACE)
        if server_key == "routers"
        else settings.get("agent_interface", DEFAULT_AGENT_INTERFACE)
    )
    output = run([
        "journalctl", "-u", "wg-quick@%s" % interface,
        "-n", "120", "--no-pager",
    ], check=False)
    return Response(output or "لا يوجد سجل حالياً", mimetype="text/plain")


@app.route("/wireguard/sync-ubuntu", methods=["POST"])
@login_required
def sync_ubuntu_peers():
    try:
        count = import_peers_from_ubuntu()
        ensure_all_agent_devices()
        apply_agent_wireguard()
        if count:
            flash("تم استيراد %s وكيل جديد وتحديث NAT" % count, "success")
        else:
            flash("تمت مزامنة Ubuntu وتحديث الوكلاء وقواعد NAT", "success")
    except Exception as exc:
        flash("فشلت مزامنة Ubuntu: %s" % exc, "danger")
    return redirect(url_for("wireguard_page"))


@app.route("/wireguard/sync-log")
@login_required
def sync_log():
    path = APP_DIR / "sync-debug.log"
    text = path.read_text(errors="ignore") if path.exists() else "No sync log yet"
    return "<pre style='direction:ltr;text-align:left;white-space:pre-wrap'>%s</pre>" % text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


@app.route("/settings", methods=["POST"])
@login_required
def save_settings():
    fields = [
        "interface", "endpoint", "port", "address", "dns", "mtu",
        "out_interface", "system_name", "agent_interface", "agent_port",
        "agent_address", "agent_mtu",
    ]
    values = {key: request.form.get(key, "").strip() for key in fields}
    try:
        ipaddress.ip_interface(values["address"])
        ipaddress.ip_interface(values["agent_address"])
        port = int(values["port"])
        agent_port = int(values["agent_port"])
        if port < 1 or port > 65535 or agent_port < 1 or agent_port > 65535:
            raise ValueError()
        if not re.match(r"^[A-Za-z0-9_.-]{1,15}$", values["interface"]):
            raise ValueError()
        if not re.match(r"^[A-Za-z0-9_.-]{1,15}$", values["agent_interface"]):
            raise ValueError()
        if values["interface"] == values["agent_interface"]:
            raise ValueError()
        if port == agent_port:
            raise ValueError()
    except Exception:
        flash("إعدادات خادمي WireGuard غير صحيحة", "danger")
        return redirect(url_for("wireguard_page"))

    con = db()
    for key, value in values.items():
        con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (key, value))
    con.commit()
    con.close()
    flash("تم حفظ إعدادات خادمي WireGuard", "success")
    return redirect(url_for("wireguard_page") + "#server-settings")


@app.route("/wireguard/apply", methods=["POST"])
@login_required
def apply():
    try:
        apply_wireguard()
        ensure_all_agent_devices()
        apply_agent_wireguard()
        flash(
            "تمت مزامنة WireGuard للراوترات وأجهزة الوكلاء بنجاح",
            "success",
        )
    except Exception as exc:
        flash("فشل التطبيق: %s" % exc, "danger")
    return redirect(url_for("wireguard_page"))


@app.route("/peers/add", methods=["POST"])
@login_required
def add_peer():
    con = None
    peer_id = None
    try:
        name = request.form.get("name", "").strip()
        if not name:
            raise ValueError("اسم الراوتر مطلوب")

        tunnel_ip = next_tunnel_ip()
        winbox_internal = 8291
        requested_external = request.form.get("winbox_external", "").strip()
        winbox_external = int(requested_external) if requested_external else next_winbox_port()
        if winbox_external < 1 or winbox_external > 65535:
            raise ValueError("بورت WinBox الخارجي غير صحيح")

        lan_ips = request.form.get("lan_ips", "").strip()
        clean_networks(lan_ips)
        private_key, public_key, psk = wg_keypair()
        api_username, api_password = random_api_credentials()
        mt_host = str(ipaddress.ip_interface(tunnel_ip).ip)

        con = db()
        if con.execute("SELECT 1 FROM peers WHERE winbox_external=?", (winbox_external,)).fetchone():
            raise ValueError("بورت WinBox الخارجي مستخدم من وكيل آخر")
        con.execute("""
            INSERT INTO peers
            (name,tunnel_ip,lan_ips,public_ips,private_key,public_key,preshared_key,enabled,notes,
             mt_host,mt_port,mt_username,mt_password_enc,mt_ssl,winbox_internal,winbox_external)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            name, tunnel_ip, lan_ips,
            request.form.get("public_ips", "").strip(),
            private_key, public_key, psk, 1,
            request.form.get("notes", "").strip(),
            mt_host, 9494, api_username, encrypt_text(api_password), 0,
            winbox_internal, winbox_external,
        ))
        peer_id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
        con.commit(); con.close(); con = None

        # Apply router tunnel, then create mobile and Windows access.
        apply_wireguard()
        ensure_agent_devices(peer_id)
        apply_agent_wireguard()
        flash(
            "تمت إضافة الراوتر تلقائياً. WinBox: %s:%s "
            "وتم إنشاء باركود الموبايل وكونفك Windows"
            % (
                get_settings()["endpoint"],
                winbox_external,
            ),
            "success",
        )
        return redirect(url_for("peer_scripts", peer_id=peer_id))
    except sqlite3.IntegrityError:
        if con: con.rollback(); con.close()
        flash("حدث تكرار في IP أو بورت WinBox", "danger")
    except Exception as exc:
        if con: con.rollback(); con.close()
        if peer_id:
            cleanup = db()
            cleanup.execute(
                "DELETE FROM agent_devices WHERE peer_id=?",
                (peer_id,),
            )
            cleanup.execute(
                "DELETE FROM peers WHERE id=?",
                (peer_id,),
            )
            cleanup.commit()
            cleanup.close()
            try:
                apply_wireguard()
                apply_agent_wireguard()
            except Exception:
                pass
        flash("تعذر إضافة الراوتر: %s" % exc, "danger")
    return redirect(url_for("routers_page"))


@app.route("/peers/<int:peer_id>/edit", methods=["GET", "POST"])
@login_required
def edit_peer(peer_id):
    con = db()
    peer = con.execute("SELECT * FROM peers WHERE id=?", (peer_id,)).fetchone()
    if not peer:
        con.close()
        return "Not found", 404

    if request.method == "POST":
        try:
            tunnel_ip = request.form.get("tunnel_ip", "").strip()
            ipaddress.ip_interface(tunnel_ip)
            lan_ips = request.form.get("lan_ips", "").strip()
            clean_networks(lan_ips)
            old_password = peer["mt_password_enc"]
            new_password = request.form.get("mt_password", "")
            password_enc = encrypt_text(new_password) if new_password else old_password
            requested_external = int(request.form.get("winbox_external", "0") or 0)
            validate_external_port(requested_external, peer_id)
            con.execute("""
                UPDATE peers SET
                    name=?, tunnel_ip=?, lan_ips=?, public_ips=?, notes=?,
                    mt_host=?, mt_port=?, mt_username=?, mt_password_enc=?, mt_ssl=?,
                    winbox_internal=?, winbox_external=?
                WHERE id=?
            """, (
                request.form.get("name", "").strip(),
                tunnel_ip,
                lan_ips,
                request.form.get("public_ips", "").strip(),
                request.form.get("notes", "").strip(),
                request.form.get("mt_host", "").strip(),
                int(request.form.get("mt_port", "8728") or 8728),
                request.form.get("mt_username", "").strip(),
                password_enc,
                1 if request.form.get("mt_ssl") else 0,
                int(peer["winbox_internal"] or 8291),
                requested_external,
                peer_id,
            ))
            con.commit()
            con.close()
            apply_wireguard()
            ensure_agent_devices(peer_id)
            apply_agent_wireguard()
            sync_peer_winbox_internal_silent(peer_id)
            flash(
                "تم تعديل الراوتر وتحديث WireGuard وWinBox ودخول الأجهزة تلقائياً",
                "success",
            )
            return redirect(url_for("routers_page"))
        except Exception as exc:
            flash("فشل التعديل: %s" % exc, "danger")
    con.close()
    sync_peer_winbox_internal_silent(peer_id)
    peer = get_peer_or_404(peer_id)
    return render_template("edit_peer.html", peer=peer, settings=get_settings())


@app.route("/peers/<int:peer_id>/api-test", methods=["POST"])
@login_required
def api_test(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        return "Not found", 404
    try:
        api = connect_peer_api(peer)
        try:
            identity = api.talk("/system/identity/print")
            resource = api.talk("/system/resource/print")
            name = identity[0].get("name", "-") if identity else "-"
            version = resource[0].get("version", "-") if resource else "-"
            uptime = resource[0].get("uptime", "-") if resource else "-"
            live_winbox_port = _read_winbox_internal_port(api)
            if live_winbox_port:
                _save_live_router_state(peer_id, winbox_port=live_winbox_port)
            flash("اتصال MikroTik ناجح: %s | RouterOS %s | %s" % (name, version, uptime), "success")
        finally:
            api.close()
    except Exception as exc:
        flash("فشل اتصال MikroTik API: %s" % exc, "danger")
    return redirect(url_for("edit_peer", peer_id=peer_id))


@app.route("/peers/<int:peer_id>/api-apply", methods=["POST"])
@login_required
def api_apply(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        return "Not found", 404
    try:
        result = apply_mikrotik_api(peer)
        flash(
            "تم تطبيق WireGuard على MikroTik عبر API: %s | RouterOS %s" %
            (result["identity"], result["version"]),
            "success"
        )
    except Exception as exc:
        flash("فشل تطبيق MikroTik API: %s" % exc, "danger")
    return redirect(url_for("edit_peer", peer_id=peer_id))



@app.route("/peers/<int:peer_id>/scripts")
@login_required
def peer_scripts(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer or not peer["private_key"]:
        return redirect(url_for("routers_page"))

    username = peer["mt_username"] or ""
    password = decrypt_text(peer["mt_password_enc"])
    combined_script = mikrotik_script(peer)

    return render_template(
        "scripts.html",
        peer=peer,
        username=username,
        password=password,
        combined_script=combined_script,
        settings=get_settings(),
    )


@app.route("/peers/<int:peer_id>/scripts/regenerate", methods=['POST'])
@login_required
def regenerate_api_credentials(peer_id):
    return redirect(url_for("routers_page"))


@app.route("/routers/<int:peer_id>")
@login_required
def router_manage(peer_id):
    peer_row = get_peer_or_404(peer_id)
    if not peer_row:
        return "Not found", 404
    peer = dict(peer_row)
    cloud_state_known = False
    try:
        router = router_overview(peer_row)
        error = None
        cloud_state_known = True
        peer["cloud_main_state"] = router.get("cloud_main_state", "unknown")
        peer["cloud_bypass_state"] = router.get("cloud_bypass_state", "unknown")
        if router.get("winbox_internal"):
            peer["winbox_internal"] = router["winbox_internal"]
    except Exception as exc:
        router = None
        error = str(exc)
        peer["cloud_main_state"] = "unknown"
        peer["cloud_bypass_state"] = "unknown"
    return render_template(
        "router_manage.html",
        peer=peer,
        router=router,
        error=error,
        cloud_state_known=cloud_state_known,
        settings=get_settings(),
    )






@app.route(
    "/routers/<int:peer_id>/managed-account/rotate",
    methods=["POST"],
)
@login_required
def router_rotate_managed_account(peer_id):
    peer = get_peer_or_404(peer_id)

    if not peer:
        return "Not found", 404

    old_username = str(
        peer["mt_username"] or ""
    ).strip()

    try:
        new_username, new_password = (
            ensure_router_managed_user(peer)
        )

        flash(
            "تم إنشاء حساب إدارة جديد واختباره بنجاح",
            "success",
        )

        create_notification(
            "تغيير حساب إدارة الراوتر",
            "تم تغيير حساب الراوتر %s من %s إلى %s"
            % (
                peer["name"],
                old_username or "غير محدد",
                new_username,
            ),
            kind="success",
            audience="admin",
            peer_id=peer_id,
        )

    except Exception as exc:
        flash(
            "فشل تغيير حساب إدارة الراوتر: %s"
            % exc,
            "danger",
        )

        create_notification(
            "فشل تغيير حساب الإدارة",
            "%s: %s" % (
                peer["name"],
                exc,
            ),
            kind="error",
            audience="admin",
            peer_id=peer_id,
        )

    return redirect(
        url_for(
            "router_manage",
            peer_id=peer_id,
        )
    )


@app.context_processor
def inject_router_account_helpers():
    def reveal_router_password(value):
        if not value:
            return ""
        try:
            return decrypt_text(value)
        except Exception:
            return ""

    return {
        "reveal_router_password":
            reveal_router_password,
    }

@app.route(
    "/routers/<int:peer_id>/auto-provision",
    methods=["POST"],
)
@login_required
def router_auto_provision(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        return "Not found", 404

    try:
        result = provision_router_automatically(peer_id)

        flash(
            "تمت تهيئة الراوتر وتثبيت حماية MAIN/BYPASS والإصلاح الذاتي",
            "success",
        )

        create_notification(
            "تهيئة الراوتر مكتملة",
            "تمت تهيئة الراوتر %s بنجاح"
            % peer["name"],
            kind="success",
            audience="admin",
            peer_id=peer_id,
        )

    except Exception as exc:
        flash(
            "فشلت التهيئة التلقائية: %s" % exc,
            "danger",
        )

        create_notification(
            "فشل تهيئة الراوتر",
            "%s: %s" % (
                peer["name"],
                exc,
            ),
            kind="error",
            audience="admin",
            peer_id=peer_id,
        )

    return redirect(
        url_for(
            "router_manage",
            peer_id=peer_id,
        )
    )

@app.route("/routers/<int:peer_id>/provision", methods=["POST"])
@login_required
def router_provision(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        return "Not found", 404
    try:
        username = request.form.get("managed_username", "").strip()
        password = request.form.get("managed_password", "")
        if not username or not password:
            username, password = random_api_credentials()
        result = provision_mikrotik_management(peer, username, password, 9494)
        install_cloud_router_guards(peer_id, notify=False)
        flash("تم إنشاء مستخدم الإدارة %s وتغيير API إلى 9494 وتثبيت الحماية على %s" %
              (result["username"], result["identity"]), "success")
    except Exception as exc:
        flash("فشلت تهيئة إدارة MikroTik: %s" % exc, "danger")
    return redirect(url_for("edit_peer", peer_id=peer_id))


@app.route("/routers/<int:peer_id>/identity", methods=["POST"])
@login_required
def router_set_identity(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        return "Not found", 404
    name = request.form.get("identity", "").strip()
    if not name:
        flash("اسم الراوتر مطلوب", "danger")
        return redirect(url_for("router_manage", peer_id=peer_id))
    try:
        api = connect_peer_api(peer)
        try:
            api.talk("/system/identity/set", {"name": name})
        finally:
            api.close()
        flash("تم تغيير اسم الراوتر", "success")
    except Exception as exc:
        flash("فشل تغيير الاسم: %s" % exc, "danger")
    return redirect(url_for("router_manage", peer_id=peer_id))


@app.route("/routers/<int:peer_id>/service", methods=["POST"])
@login_required
def router_set_service(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        return "Not found", 404
    service_name = request.form.get("service_name", "").strip()
    action = request.form.get("action", "").strip()
    try:
        api = connect_peer_api(peer)
        try:
            service = api.find_one("/ip/service/print", ["?name=%s" % service_name])
            if not service:
                raise RuntimeError("الخدمة غير موجودة")
            api.talk("/ip/service/set", {
                ".id": service[".id"],
                "disabled": "no" if action == "enable" else "yes",
            })
        finally:
            api.close()
        flash("تم تحديث خدمة %s" % service_name, "success")
    except Exception as exc:
        flash("فشل تحديث الخدمة: %s" % exc, "danger")
    return redirect(url_for("router_manage", peer_id=peer_id))


@app.route("/routers/<int:peer_id>/reboot", methods=["POST"])
@login_required
def router_reboot(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        return "Not found", 404
    try:
        api = connect_peer_api(peer)
        try:
            api.talk("/system/reboot")
        finally:
            api.close()
        flash("تم إرسال أمر إعادة التشغيل", "success")
    except Exception as exc:
        if "انقطع اتصال" in str(exc):
            flash("تم إرسال أمر إعادة التشغيل", "success")
        else:
            flash("فشل إعادة التشغيل: %s" % exc, "danger")
    return redirect(url_for("router_manage", peer_id=peer_id))



@app.route("/api/peers/<int:peer_id>/subscribers")
@login_required
def peer_subscribers_api(peer_id):
    try:
        peer = get_peer_or_404(peer_id)
        if not peer:
            return jsonify({
                "ok": False,
                "error": "الوكيل غير موجود",
                "subscribers": [],
            }), 404

        subscribers = fetch_router_subscribers(peer_id)
        return jsonify({
            "ok": True,
            "peer": {
                "id": peer["id"],
                "name": peer["name"],
                "tunnel_ip": peer["tunnel_ip"],
            },
            "count": len(subscribers),
            "subscribers": subscribers,
        })
    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
            "subscribers": [],
        }), 500


def build_subscriber_router_cards(peer_ids=None):
    con = db()
    where_sql = ""
    params = ()
    if peer_ids is not None:
        peer_ids = [int(value) for value in peer_ids]
        if not peer_ids:
            con.close()
            return []
        where_sql = "WHERE p.id IN (%s)" % ",".join(
            "?" for _ in peer_ids
        )
        params = tuple(peer_ids)
    peers = con.execute(
        """
        SELECT
            p.id,p.name,p.tunnel_ip,p.enabled,p.mt_host,p.mt_port,
            p.mt_username,p.winbox_external,p.winbox_internal,p.public_key,
            COUNT(pf.id) AS subscriber_count,
            SUM(CASE WHEN pf.enabled=1 AND COALESCE(pf.last_error,'')=''
                     THEN 1 ELSE 0 END) AS active_forward_count,
            MAX(pf.last_seen_at) AS last_subscriber_seen
        FROM peers p
        LEFT JOIN port_forwards pf ON pf.peer_id=p.id
        %s
        GROUP BY p.id
        ORDER BY p.name,p.id
        """ % where_sql,
        params,
    ).fetchall()
    con.close()
    stats = cached_wireguard_peer_stats()
    cards = []
    for peer in peers:
        item = dict(peer)
        wg = stats.get(item.get("public_key", ""), {
            "online": False, "handshake_text": "-", "rx": 0, "tx": 0,
        })
        item["wg_online"] = bool(wg.get("online"))
        item["handshake_text"] = wg.get("handshake_text", "-")
        item["subscriber_count"] = int(item.get("subscriber_count") or 0)
        item["active_forward_count"] = int(item.get("active_forward_count") or 0)
        item["api_ready"] = bool(item.get("mt_host") and item.get("mt_username"))
        item["health"] = cached_peer_ping(item["id"])
        cards.append(item)
    cards.sort(key=lambda item: (not bool(item["wg_online"]), item["name"].lower()))
    return cards


@app.route("/subscribers")
@login_required
def subscribers_page():
    router_cards = build_subscriber_router_cards()
    online_count = sum(1 for item in router_cards if item["wg_online"])
    return render_template(
        "subscribers.html",
        router_cards=router_cards,
        online_count=online_count,
        offline_count=len(router_cards) - online_count,
        total_subscribers=sum(item["subscriber_count"] for item in router_cards),
        settings=get_settings(),
    )


@app.route("/port-forwards")
@login_required
def port_forwards_page():
    con = db()
    rows = con.execute(
        """
        SELECT pf.*,p.name AS peer_name,p.tunnel_ip
        FROM port_forwards pf
        JOIN peers p ON p.id=pf.peer_id
        ORDER BY p.name,pf.external_port,pf.name,pf.id
        """
    ).fetchall()
    con.close()
    forwards = [dict(row) for row in rows]
    active_count = sum(
        1 for item in forwards
        if item.get("enabled") and not item.get("last_error")
    )
    return render_template(
        "port_forwards.html",
        forwards=forwards,
        active_count=active_count,
        inactive_count=len(forwards) - active_count,
        settings=get_settings(),
    )


@app.route("/port-forwards/import-all", methods=["POST"])
@login_required
def port_forward_import_all():
    try:
        internal_port = int(
            request.form.get("internal_port", "80") or 80
        )
        protocol = validate_forward_protocol(
            request.form.get("protocol", "tcp")
        )

        acquired = SUBSCRIBER_SYNC_LOCK.acquire(
            timeout=90
        )
        if not acquired:
            raise RuntimeError(
                "المزامنة التلقائية مشغولة؛ حاول بعد ثوانٍ"
            )
        try:
            result = import_all_router_subscribers(
                default_internal_port=internal_port,
                protocol=protocol,
            )
        finally:
            SUBSCRIBER_SYNC_LOCK.release()

        message = (
            "تم فحص %(found)s مشترك متصل؛ إضافة %(added)s جديد، "
            "تحديث %(updated)s، وحذف %(deleted)s غير متصل"
        ) % result

        all_errors = (
            result["discovery_errors"] + result["apply_errors"]
        )
        if all_errors:
            flash(
                message + " — بعض الراوترات بيها خطأ: "
                + " | ".join(all_errors),
                "danger"
            )
        else:
            flash(message + "، وتم عزلهم حسب كل راوتر", "success")

    except Exception as exc:
        flash("فشل إضافة كل المشتركين: %s" % exc, "danger")

    return redirect(url_for("subscribers_page"))



@app.route("/port-forwards/router/<int:peer_id>")
@login_required
def router_subscribers_page(peer_id):
    peer_row = get_peer_or_404(peer_id)
    if not peer_row:
        return "Not found", 404

    peer = dict(peer_row)
    stats = cached_wireguard_peer_stats()
    peer["wg"] = stats.get(
        peer.get("public_key", ""),
        {"handshake_text": "-", "rx": 0, "tx": 0, "online": False},
    )
    peer["health"] = cached_peer_ping(peer["id"])

    con = db()
    forwards = [
        dict(row) for row in con.execute(
            """
            SELECT pf.*, p.name AS peer_name, p.tunnel_ip
            FROM port_forwards pf
            JOIN peers p ON p.id=pf.peer_id
            WHERE pf.peer_id=?
            ORDER BY pf.name,pf.external_port,pf.id
            """,
            (int(peer_id),),
        ).fetchall()
    ]
    con.close()
    active_count = sum(
        1 for item in forwards
        if item.get("enabled") and not item.get("last_error")
    )
    error_count = sum(1 for item in forwards if item.get("last_error"))
    manual_count = sum(1 for item in forwards if not item.get("auto_managed"))
    return render_template(
        "router_subscribers.html",
        peer=peer,
        forwards=forwards,
        active_count=active_count,
        inactive_count=len(forwards) - active_count,
        error_count=error_count,
        manual_count=manual_count,
        settings=get_settings(),
    )


@app.route("/port-forwards/router/<int:peer_id>/sync", methods=["POST"])
@login_required
def router_subscribers_sync(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        return "Not found", 404

    try:
        settings = get_settings()
        acquired = SUBSCRIBER_SYNC_LOCK.acquire(
            timeout=90
        )
        if not acquired:
            raise RuntimeError(
                "المزامنة التلقائية مشغولة؛ حاول بعد ثوانٍ"
            )
        try:
            result = import_all_router_subscribers(
                default_internal_port=int(
                    settings.get(
                        "subscriber_default_port",
                        "80",
                    ) or 80
                ),
                protocol=settings.get(
                    "subscriber_default_protocol",
                    "tcp",
                ),
                only_peer_id=peer_id,
            )
        finally:
            SUBSCRIBER_SYNC_LOCK.release()
        flash(
            "تمت مزامنة %s: متصلون %(found)s، إضافة %(added)s، "
            "تحديث %(updated)s، حذف %(deleted)s"
            % peer["name"] % result,
            "success"
        )
    except Exception as exc:
        flash(
            "فشلت مزامنة الراوتر %s: %s"
            % (peer["name"], exc),
            "danger"
        )

    return redirect(
        url_for("router_subscribers_page", peer_id=peer_id)
    )



@app.route("/port-forwards/add", methods=["POST"])
@login_required
def port_forward_add():
    forward_id = None
    peer_id = None
    try:
        peer_id = int(request.form.get("peer_id", "0") or 0)
        peer = get_peer_or_404(peer_id)
        if not peer:
            raise RuntimeError("اختر وكيل صحيح")

        internal_ip = normalize_internal_ip(request.form.get("internal_ip", ""))
        subscriber = canonical_router_subscriber(peer_id, internal_ip)
        name = subscriber["name"]
        internal_port = int(request.form.get("internal_port", "0") or 0)
        if internal_port < 1 or internal_port > 65535:
            raise RuntimeError("البورت الداخلي غير صحيح")

        protocol = validate_forward_protocol(request.form.get("protocol", "tcp"))
        requested = request.form.get("external_port", "").strip()
        external_port = (
            validate_forward_external_port(int(requested))
            if requested else next_forward_external_port()
        )
        if not name:
            name = "%s:%s" % (internal_ip, internal_port)

        stamp = datetime.now().isoformat(timespec="seconds")
        con = db()
        con.execute(
            """
            INSERT INTO port_forwards
            (peer_id,name,internal_ip,internal_port,external_port,protocol,
             enabled,created_at,updated_at,last_applied_at,last_error,
             auto_managed,last_seen_at)
            VALUES(?,?,?,?,?,?,1,?,?,?,?,0,?)
            """,
            (
                peer_id, name, internal_ip, internal_port, external_port,
                protocol, stamp, stamp, "", "", stamp
            )
        )
        forward_id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
        con.commit()
        con.close()

        _sync_forward_changes([peer_id])
        flash(
            "تم إنشاء التحويل: %s:%s ← %s:%s"
            % (
                get_settings()["endpoint"], external_port,
                internal_ip, internal_port
            ),
            "success"
        )
    except Exception as exc:
        if forward_id:
            mark_forward_error(forward_id, exc)
            try:
                regenerate_nat_rules()
            except Exception:
                pass
            flash(
                "تم حفظ التحويل، لكن فشل تطبيقه على MikroTik: %s" % exc,
                "danger"
            )
        else:
            flash("تعذر إنشاء التحويل: %s" % exc, "danger")
    return redirect(url_for("port_forwards_page"))


def safe_local_return_url(value, fallback):
    value = str(value or "").strip()
    if value.startswith("/") and not value.startswith("//"):
        return value
    return fallback


@app.route("/port-forwards/<int:forward_id>/edit", methods=["GET", "POST"])
@login_required
def port_forward_edit(forward_id):
    item = get_forward_or_404(forward_id)
    if not item:
        return "Not found", 404

    if request.method == "POST":
        old_peer_id = int(item["peer_id"])
        try:
            peer_id = int(request.form.get("peer_id", "0") or 0)
            if not get_peer_or_404(peer_id):
                raise RuntimeError("الوكيل غير موجود")

            internal_ip = normalize_internal_ip(request.form.get("internal_ip", ""))
            subscriber = canonical_router_subscriber(peer_id, internal_ip)
            name = subscriber["name"]
            internal_port = int(request.form.get("internal_port", "0") or 0)
            if internal_port < 1 or internal_port > 65535:
                raise RuntimeError("البورت الداخلي غير صحيح")
            protocol = validate_forward_protocol(request.form.get("protocol", "tcp"))
            external_port = validate_forward_external_port(
                request.form.get("external_port", "0"),
                forward_id
            )
            enabled = 1 if request.form.get("enabled") else 0
            stamp = datetime.now().isoformat(timespec="seconds")

            con = db()
            con.execute(
                """
                UPDATE port_forwards SET
                    peer_id=?, name=?, internal_ip=?, internal_port=?,
                    external_port=?, protocol=?, enabled=?, updated_at=?,
                    last_error=''
                WHERE id=?
                """,
                (
                    peer_id, name or ("%s:%s" % (internal_ip, internal_port)),
                    internal_ip, internal_port, external_port, protocol,
                    enabled, stamp, forward_id
                )
            )
            con.commit()
            con.close()

            _sync_forward_changes([old_peer_id, peer_id])
            flash("تم تعديل التحويل وتطبيقه على Ubuntu وMikroTik", "success")
            fallback = url_for("router_subscribers_page", peer_id=peer_id)
            return redirect(safe_local_return_url(request.args.get("next"), fallback))
        except Exception as exc:
            mark_forward_error(forward_id, exc)
            flash("فشل تطبيق التعديل: %s" % exc, "danger")
            item = get_forward_or_404(forward_id)

    con = db()
    peers = con.execute(
        "SELECT id,name,tunnel_ip,enabled FROM peers ORDER BY name"
    ).fetchall()
    con.close()
    return render_template(
        "edit_forward.html",
        item=item,
        peers=peers,
        settings=get_settings(),
    )


@app.route("/port-forwards/<int:forward_id>/apply", methods=["POST"])
@login_required
def port_forward_apply(forward_id):
    item = get_forward_or_404(forward_id)
    if not item:
        return "Not found", 404
    try:
        _sync_forward_changes([item["peer_id"]])
        flash("تم تطبيق التحويل على Ubuntu وMikroTik", "success")
    except Exception as exc:
        mark_forward_error(forward_id, exc)
        flash("فشل تطبيق التحويل: %s" % exc, "danger")
    fallback = url_for("router_subscribers_page", peer_id=item["peer_id"])
    return redirect(safe_local_return_url(request.args.get("next"), fallback))


@app.route("/port-forwards/apply-all", methods=["POST"])
@login_required
def port_forward_apply_all():
    con = db()
    peer_ids = [
        row["peer_id"]
        for row in con.execute(
            "SELECT DISTINCT peer_id FROM port_forwards"
        ).fetchall()
    ]
    con.close()
    try:
        _sync_forward_changes(peer_ids)
        flash("تمت مزامنة جميع التحويلات", "success")
    except Exception as exc:
        flash("اكتملت مزامنة Ubuntu، لكن بعض الراوترات فشلت: %s" % exc, "danger")
    return redirect(url_for("port_forwards_page"))


@app.route("/port-forwards/<int:forward_id>/toggle", methods=["POST"])
@login_required
def port_forward_toggle(forward_id):
    item = get_forward_or_404(forward_id)
    if not item:
        return "Not found", 404

    con = db()
    con.execute(
        """
        UPDATE port_forwards
        SET enabled=CASE WHEN enabled=1 THEN 0 ELSE 1 END,
            updated_at=?, last_error=''
        WHERE id=?
        """,
        (datetime.now().isoformat(timespec="seconds"), forward_id)
    )
    con.commit()
    con.close()

    try:
        _sync_forward_changes([item["peer_id"]])
        flash("تم تغيير حالة التحويل", "success")
    except Exception as exc:
        mark_forward_error(forward_id, exc)
        flash("تغيّرت الحالة، لكن فشل تطبيقها على الراوتر: %s" % exc, "danger")
    fallback = url_for("router_subscribers_page", peer_id=item["peer_id"])
    return redirect(safe_local_return_url(request.args.get("next"), fallback))


@app.route("/port-forwards/<int:forward_id>/delete", methods=["POST"])
@login_required
def port_forward_delete(forward_id):
    item = get_forward_or_404(forward_id)
    if not item:
        return "Not found", 404
    peer_id = int(item["peer_id"])

    con = db()
    con.execute("DELETE FROM port_forwards WHERE id=?", (forward_id,))
    con.commit()
    con.close()

    try:
        _sync_forward_changes([peer_id])
        flash("تم حذف التحويل من Ubuntu وMikroTik", "success")
    except Exception as exc:
        flash(
            "حُذف من البنل وUbuntu، لكن تعذر تنظيف الراوتر: %s" % exc,
            "danger"
        )
    return redirect(url_for("port_forwards_page"))




@app.route("/peers/<int:peer_id>/access")
@login_required
def peer_agent_access(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        return "Not found", 404

    try:
        ensure_agent_devices(peer_id)
        apply_agent_wireguard()
        access_error = ""
    except Exception as exc:
        access_error = str(exc)

    con = db()
    devices = con.execute(
        """
        SELECT * FROM agent_devices
        WHERE peer_id=?
        ORDER BY
            CASE device_type
                WHEN 'mobile' THEN 1
                WHEN 'windows' THEN 2
                ELSE 3
            END
        """,
        (int(peer_id),),
    ).fetchall()
    forwards = con.execute(
        """
        SELECT * FROM port_forwards
        WHERE peer_id=? AND enabled=1
        ORDER BY external_port,name,id
        """,
        (int(peer_id),),
    ).fetchall()
    con.close()

    direct_ips, direct_conflicts = _direct_ips_for_peer(
        peer_id
    )
    direct_ip_set = set(direct_ips)
    forward_rows = []
    for row in forwards:
        item = dict(row)
        port = int(item.get("internal_port") or 80)
        if port == 80:
            item["direct_url"] = "http://%s" % item["internal_ip"]
        elif port == 443:
            item["direct_url"] = "https://%s" % item["internal_ip"]
        else:
            item["direct_url"] = "http://%s:%s" % (
                item["internal_ip"], port
            )
        item["direct_available"] = (
            item["internal_ip"] in direct_ip_set
        )
        forward_rows.append(item)

    stats = agent_wireguard_stats()
    device_rows = []
    for row in devices:
        item = dict(row)
        item["wg"] = stats.get(
            item["public_key"],
            {
                "online": False,
                "handshake_text": "-",
            },
        )
        device_rows.append(item)

    settings = get_settings()
    return render_template(
        "agent_access.html",
        peer=peer,
        devices=device_rows,
        forwards=forward_rows,
        direct_conflicts=direct_conflicts,
        settings=settings,
        agent_server_ip=_agent_server_ip(settings),
        direct_tunnel=_direct_router_parameters(peer, settings),
        access_error=access_error,
    )


@app.route(
    "/peers/<int:peer_id>/access/<device_type>/config"
)
@login_required
def download_agent_config(peer_id, device_type):
    device = get_agent_device(peer_id, device_type)
    if not device:
        return "Not found", 404

    safe_name = re.sub(
        r"[^A-Za-z0-9_.-]+",
        "-",
        device["peer_name"],
    ).strip("-") or ("peer-%s" % peer_id)
    filename = "%s-%s.conf" % (
        safe_name,
        device_type,
    )
    return send_file(
        io.BytesIO(
            agent_client_config(device).encode("utf-8")
        ),
        mimetype="text/plain",
        as_attachment=True,
        download_name=filename,
    )


@app.route(
    "/peers/<int:peer_id>/access/<device_type>/qr.png"
)
@login_required
def agent_access_qr(peer_id, device_type):
    device = get_agent_device(peer_id, device_type)
    if not device:
        return "Not found", 404

    image = qrcode.make(agent_client_config(device))
    output = io.BytesIO()
    image.save(output, format="PNG")
    output.seek(0)
    return send_file(
        output,
        mimetype="image/png",
        as_attachment=False,
        download_name=(
            "peer-%s-%s-qr.png"
            % (peer_id, device_type)
        ),
    )


@app.route("/peers/<int:peer_id>/toggle", methods=["POST"])
@login_required
def toggle_peer(peer_id):
    con = db()
    peer = con.execute("SELECT enabled FROM peers WHERE id=?", (peer_id,)).fetchone()
    if peer:
        con.execute("UPDATE peers SET enabled=? WHERE id=?", (0 if peer["enabled"] else 1, peer_id))
        con.commit()
    con.close()
    apply_wireguard()
    ensure_agent_devices(peer_id)
    apply_agent_wireguard()
    sync_direct_subscriber_routes(force=True)
    flash(
        "تم تغيير حالة الراوتر وتحديث الربط وأجهزة الوكلاء",
        "success",
    )
    return redirect(url_for("routers_page"))


@app.route("/peers/<int:peer_id>/delete", methods=["POST"])
@login_required
def delete_peer(peer_id):
    con = db()
    con.execute(
        "DELETE FROM port_forwards WHERE peer_id=?",
        (peer_id,),
    )
    con.execute(
        "DELETE FROM agent_devices WHERE peer_id=?",
        (peer_id,),
    )
    con.execute(
        "DELETE FROM peers WHERE id=?",
        (peer_id,),
    )
    con.commit()
    con.close()
    apply_wireguard()
    apply_agent_wireguard()
    sync_direct_subscriber_routes(force=True)
    flash(
        "تم حذف الراوتر وإزالة ربط WireGuard والموبايل وWindows وNAT",
        "success",
    )
    return redirect(url_for("routers_page"))


@app.route("/peers/<int:peer_id>/config")
@login_required
def download_config(peer_id):
    return redirect(url_for("routers_page"))


@app.route("/peers/<int:peer_id>/qr")
@login_required
def peer_qr(peer_id):
    return redirect(url_for("routers_page"))


@app.route("/peers/<int:peer_id>/mikrotik")
@login_required
def download_mikrotik(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer or not peer["private_key"]:
        return redirect(url_for("routers_page"))

    return send_file(
        io.BytesIO(mikrotik_script(peer).encode()),
        mimetype="text/plain",
        as_attachment=True,
        download_name="%s-mikrotik-full.rsc" % peer["name"],
    )


@app.route("/peers/<int:peer_id>/ping")
@login_required
def peer_ping(peer_id):
    peer = get_peer_or_404(peer_id)
    if not peer:
        return "Not found", 404
    result = ping_peer(peer["tunnel_ip"])
    return render_template("ping.html", peer=peer, result=result, settings=get_settings())


@app.route("/account/password", methods=["POST"])
@login_required
def change_password():
    current = request.form.get("current_password", "")
    new = request.form.get("new_password", "")
    if len(new) < 8:
        flash("كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل", "danger")
        return redirect(url_for("dashboard"))
    con = db()
    user = con.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    if not user or not check_password_hash(user["password_hash"], current):
        con.close()
        flash("كلمة المرور الحالية غير صحيحة", "danger")
        return redirect(url_for("dashboard"))
    con.execute("UPDATE users SET password_hash=? WHERE id=?", (
        generate_password_hash(new), session["user_id"]
    ))
    con.commit()
    con.close()
    flash("تم تغيير كلمة المرور", "success")
    return redirect(url_for("dashboard"))


if __name__ == "__main__":
    init_db()

    try:
        ensure_all_agent_devices()
        apply_agent_wireguard()
        sync_direct_subscriber_routes(force=True)
    except Exception as exc:
        try:
            with (APP_DIR / "sync-debug.log").open("a") as handle:
                handle.write(
                    "%s agent-access-startup-error=%s\n"
                    % (
                        datetime.now().isoformat(
                            timespec="seconds"
                        ),
                        exc,
                    )
                )
        except Exception:
            pass

    refresh_runtime_caches()

    try:
        apply_transparent_webfig_nginx()
    except Exception as exc:
        try:
            with (APP_DIR / "sync-debug.log").open("a") as handle:
                handle.write(
                    "%s transparent-webfig-startup-error=%s\n"
                    % (
                        datetime.now().isoformat(
                            timespec="seconds"
                        ),
                        exc,
                    )
                )
        except Exception:
            pass

    runtime_thread = threading.Thread(
        target=runtime_cache_loop,
        name="wireguard-runtime-cache",
        daemon=True,
    )
    runtime_thread.start()

    ping_thread = threading.Thread(
        target=ping_cache_loop,
        name="router-ping-cache",
        daemon=True,
    )
    ping_thread.start()

    subscriber_thread = threading.Thread(
        target=subscriber_sync_loop,
        name="subscriber-live-sync",
        daemon=True,
    )
    subscriber_thread.start()

    wireguard_thread = threading.Thread(
        target=wireguard_auto_sync_loop,
        name="wireguard-auto-sync",
        daemon=True,
    )
    wireguard_thread.start()

    guard_thread = threading.Thread(
        target=router_guard_maintenance_loop,
        name="router-cloud-self-heal",
        daemon=True,
    )
    guard_thread.start()

    app.run(host="0.0.0.0", port=1994)
